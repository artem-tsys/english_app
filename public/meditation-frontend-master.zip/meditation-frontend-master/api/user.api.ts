import { AxiosResponse } from 'axios';

import { apiHost, apiPrefix } from '../config';
import { setCookieSafe } from '../utils/cookie';
import getAxios from './axios';

interface EmailSignupParams {
  email: string;
  timeZone: string;
  agreementTime: number;
  uuid: string;
}

interface EmailByAdminSignupParams extends EmailSignupParams {
  name?: string;
  age?: number;
  subscriptionMonths: number;
}

interface EmailWithOrderSignupParams extends EmailSignupParams {
  password: string;
  orderHash: string;
}

interface EmailCouponSignupParams extends EmailWithOrderSignupParams {
  coupon: string;
}
export const signupWithEmail = (payload: EmailWithOrderSignupParams): Promise<AxiosResponse> =>
  getAxios().post(`${apiHost}${apiPrefix}/user/email`, payload);

export const signupWithEmailCoupon = (payload: EmailCouponSignupParams): Promise<AxiosResponse> =>
  getAxios().post(`${apiHost}${apiPrefix}/user/email-coupon`, payload);

interface AppleSignupParams {
  code: string;
  timeZone: string;
  agreementTime: number;
  uuid: string;
  orderHash: string;
}

interface AppleCouponSignupParams extends AppleSignupParams {
  coupon: string;
}

export const signupWithApple = (payload: AppleSignupParams): Promise<AxiosResponse> =>
  getAxios().post(`${apiHost}${apiPrefix}/user/apple`, payload);

export const signupWithAppleCoupon = (payload: AppleCouponSignupParams): Promise<AxiosResponse> =>
  getAxios().post(`${apiHost}${apiPrefix}/user/apple-coupon`, payload);

type SignupByAdminResponse = AxiosResponse<{
  userId: number;
}>;
export const signupWithEmailByAdmin = (payload: EmailByAdminSignupParams): Promise<SignupByAdminResponse> =>
  getAxios().post(`${apiHost}${apiPrefix}/user/email-admin`, payload, { withCredentials: true });

interface EmailLoginParams {
  password: string;
  email: string;
  timeZone: string;
  agreementTime: number;
  uuid: string;
}

export const loginUserWithEmail = async (payload: EmailLoginParams): Promise<any> => {
  const response = await getAxios().post(`${apiHost}${apiPrefix}/user/email/login`, payload, {
    withCredentials: true,
  });
  const token = response.data.token;
  const hasActiveSubscription = response.data.hasActiveSubscription;

  setCookieSafe('Authorization', `Bearer ${token}`, 1);
  setCookieSafe('hasActiveSubscription', `${hasActiveSubscription}`, 1);
};

interface AppleLoginParams {
  code: string;
  timeZone: string;
  agreementTime: number;
  uuid: string;
}
export const loginUserWithApple = async (payload: AppleLoginParams): Promise<any> => {
  const response = await getAxios().post(`${apiHost}${apiPrefix}/user/apple/login`, payload, {
    withCredentials: true,
  });
  const token = response.data.token;

  setCookieSafe('Authorization', `Bearer ${token}`, 1);
};

export const unsubscribeUser = async (data = {}): Promise<any> => {
  try {
    const response = await getAxios().patch(`${apiHost}${apiPrefix}/subscription/cancel`, data, {
      withCredentials: true,
    });
    return response;
  } catch (e) {
    if (e?.response?.status === 403) {
      setCookieSafe('Authorization', '', 0);
      setCookieSafe('hasActiveSubscription', '', 0);
    }

    throw e;
  }
};
