import axios, { AxiosInstance } from 'axios';

import clientSideLang from '../utils/next-with-i18n/client-side-lang';

function getAxiosInstance(lng: string = clientSideLang()): AxiosInstance {
  return axios.create({
    headers: { 'Accept-Language': lng },
  });
}

export default getAxiosInstance;
