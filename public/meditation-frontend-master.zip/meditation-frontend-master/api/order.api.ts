import { AxiosResponse } from 'axios';

import { apiHost, apiPrefix } from '../config';
import { PAYMENT_STATUSES, PaymentStatus } from '../constants/order.constants';
import {
  Anxiety,
  Distraction,
  HealthType,
  Insomnia,
  MainGoalsType,
  SleepQualityType,
  StressCauseType,
  Stressed,
} from '../constants/quiz-options.constants';
import getAxios from './axios';

export interface CreateOrderPayload {
  health: HealthType;
  stressCause: StressCauseType[];
  sleepQuality: SleepQualityType;
  mainGoals: MainGoalsType[];
  anxiety: Anxiety;
  stressed: Stressed;
  distraction: Distraction;
  insomnia: Insomnia;
  flowTopic?: string;
  utmData: {
    utm_source: string;
    utm_medium: string;
    utm_campaign: string;
  };
  flowId: number;
}

// FE
export const createOrder = (payload: CreateOrderPayload): Promise<AxiosResponse> =>
  getAxios().post(`${apiHost}${apiPrefix}/order`, payload);

// Backend
export const fetchOrder = (hash: string): Promise<AxiosResponse> =>
  getAxios().get(`${apiHost}${apiPrefix}/order/${hash}`);

interface StartOrderPaymentParams {
  hash: string;
  email: string;
  planId: string;
  isDiscounted: boolean;
  currency: string;
}

//FE ?

export const startOrderPayment = (params: StartOrderPaymentParams): Promise<AxiosResponse> =>
  getAxios().patch(`${apiHost}${apiPrefix}/order/payment?method=paypal|card`, params, {
    withCredentials: true,
  });

// Frontend call
export const validateAppleMerchant = (validationUrl: string): Promise<AxiosResponse> =>
  getAxios().post(`${apiHost}${apiPrefix}/order/apple/verify`, { validationUrl });

// Frontend call
export const payWithApple = ({ orderHash, token }: { orderHash: string; token: string }): Promise<AxiosResponse> =>
  getAxios().post(`${apiHost}${apiPrefix}/order/apple/pay`, { orderHash, token });

// FE call
export const getPaymentStatus = (paymentHash: string): Promise<AxiosResponse> =>
  getAxios().get(`${apiHost}${apiPrefix}/order/status/${paymentHash}`);

const STATUS_POLLLING_INTERVAL = 4000;
const STATUS_POLLLING_LIMIT = 25;
const COMPLETED_STATUSES = [PAYMENT_STATUSES.SUCCESS, PAYMENT_STATUSES.FAILED];
const wait = (milliseconds: number) => new Promise((resolve) => setTimeout(resolve, milliseconds));

export const awaitPaymentComplete = async (paymentHash: string): Promise<PaymentStatus> => {
  const status = PAYMENT_STATUSES.FAILED;
  let iteration = 0;

  while (iteration < STATUS_POLLLING_LIMIT) {
    iteration++;
    try {
      const response = await getPaymentStatus(paymentHash);
      const { status: currentStatus } = response.data;

      if (COMPLETED_STATUSES.indexOf(currentStatus) > -1) {
        return currentStatus;
      }
    } catch (e) {
      return status;
    }

    await wait(STATUS_POLLLING_INTERVAL);
  }

  return status;
};

interface GooglePayTokenData {
  signature: string;
  protocolVersion: string;
  signedMessage: string;
}

export const payWithGoogle = ({
  orderHash,
  tokenData,
}: {
  orderHash: string;
  tokenData: GooglePayTokenData;
}): Promise<AxiosResponse<{ paymentHash: string }>> =>
  getAxios().post(`${apiHost}${apiPrefix}/order/google/pay`, { orderHash, tokenData });

interface UpdateEmailParams {
  hash: string;
  email: string;
  emailConsent: boolean;
}
//FE call
export const updateEmail = (params: UpdateEmailParams): Promise<AxiosResponse> =>
  getAxios().patch(`${apiHost}${apiPrefix}/order/email`, params);

interface ValidateCouponParams {
  code: string;
}
//FE call
export const validateCoupon = (params: ValidateCouponParams): Promise<AxiosResponse> =>
  getAxios().put(`${apiHost}${apiPrefix}/coupon/validate`, params);

interface UpdatePlanIdParams {
  hash: string;
  planId: string;
}
export const updatePlanId = ({ hash, planId }: UpdatePlanIdParams): Promise<AxiosResponse> =>
  getAxios().patch(`${apiHost}${apiPrefix}/order/${hash}/plan`, { planId });

interface UpdateUtmSourceParams {
  hash: string;
  utmCampaign: string;
  utmSource: string;
}

export const updateUtmSource = (params: UpdateUtmSourceParams): Promise<AxiosResponse> =>
  getAxios().patch(`${apiHost}${apiPrefix}/order/utm/update`, params);
