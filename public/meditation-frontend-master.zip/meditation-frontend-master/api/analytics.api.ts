import { AxiosResponse } from 'axios';

import { apiHost, apiPrefix } from '../config';
import {
  getAnalyticsUserEmailCookie,
  getFacebookCookiesFbc,
  getFacebookCookiesFbp,
} from '../utils/cookie-functions.util';
import { notifyOnError } from '../utils/error-tracking';
import getAxios from './axios';

// https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/server-event#action-source
enum FbActionSource {
  Email = 'email',
  Website = 'website',
  App = 'app',
  PhoneCall = 'phone_call',
  Chat = 'chat',
  PhysicalStore = 'physical_store',
  SystemGenerated = 'system_generated',
  Other = 'other',
}
interface FBbctionCustomData {
  value: number;
  currency: string;
}

export const pushEventToBackendDataLayer = (
  eventName: string,
  customData: FBbctionCustomData,
): Promise<AxiosResponse> => {
  const userEmail = getAnalyticsUserEmailCookie();
  const fbp = getFacebookCookiesFbp();
  const fbc = getFacebookCookiesFbc();

  if (!fbp) {
    notifyOnError('[Analytics] _fbp cookie was not found');
    return;
  }

  // https://developers.facebook.com/docs/marketing-api/conversions-api/using-the-api
  const facebook = {
    fbp,
    fbc,
    userEmail,
    eventName,
    userAgent: window?.navigator.userAgent ?? null,
    eventSourceUrl: window?.location.href ?? null,
    actionSource: FbActionSource.Website,
    customData: { ...customData, value: customData.value / 100 },
  };

  const res = getAxios().post(`${apiHost}${apiPrefix}/analytics/data-layer`, { facebook });
  return res;
};
