import { AxiosResponse } from 'axios';

import { flowType, webConstructorApi } from '../config';
import getAxios from './axios';

export enum ConstructorSelectQuestionType {
  SingleSelect = 'single_select',
  MultiSelect = 'multi_select',
}

export enum ConstructorQuestionType {
  MainGoals = 'main_goals',
  SleepQuality = 'sleep_quality',
  StressCause = 'stress_cause',
  Health = 'health',
  Insomnia = 'insomnia',
  Distraction = 'distraction',
  Anxiety = 'anxiety',
  Stress = 'stress',
}

export interface FlowDetailAnswer {
  description: string;
  icon: string;
  id: number;
  order: number;
  questionId: number;
  title: string;
  customizationValue?: string;
}

interface FlowDetail {
  loaders: {
    analythics: string;
    duration: number;
    finish: number;
    id: number;
    start: number;
    text: string;
    title: string;
  } | null;
  questionId: number | null;
  loaderId: number | null;
  predefinedValue: null;
  questions: {
    description: string;
    code: null;
    defaultAnalytics: null;
    answers: FlowDetailAnswer[];
    defaultValue: null;
    eventAction: string;
    questionStyle?: number;
    questionImage?: string;
    id: number;
    maxValue: null;
    minValue: null;
    required: null;
    title: string;
    type: ConstructorSelectQuestionType;
    customizationKey?: string;
  } | null;
  id: number;
  flowId: number;
  requiredId: number | null;
  predefined: number | null;
  order: number;
}

type StyleType =
  | 'answerOptionColor'
  | 'answerOptionHeight'
  | 'logo'
  | 'alternativeLogo'
  | 'answerOptionRadius'
  | 'buttonRadius'
  | 'buttonPadding'
  | 'font'
  | 'neutral900Color'
  | 'neutral800Color'
  | 'neutral700Color'
  | 'neutral600Color'
  | 'neutral500Color'
  | 'neutral400Color'
  | 'neutral300Color'
  | 'neutral200Color'
  | 'neutral100Color'
  | 'blackColor'
  | 'whiteColor'
  | 'background1Color'
  | 'background2Color'
  | 'background3Color'
  | 'primary500Color'
  | 'primary400Color'
  | 'primary300Color'
  | 'primary200Color'
  | 'primary100Color'
  | 'secondary1Color'
  | 'secondary2Color'
  | 'accentRedColor'
  | 'accentGreenColor'
  | 'accentYellowColor'
  | 'accentBlueColor';

export interface Style {
  id: number;
  type: StyleType;
  flowId: number;
  value: string;
}

export interface GeneratedFlowResponse {
  salePage: string;
  upsellPage: string;
  landingPage: string;
  description: string;
  styles: Style[];
  id: number;
  topic: string;
  title: string;
  url: string;
  salesFunnelId: string;
  requiredquestions: {
    predefinedValue: string;
    id: number;
    canBePredefined: number;
    title: string;
    type: ConstructorQuestionType;
    flowId: number;
    predefined: null;
  }[];
  flowdetails: FlowDetail[];
  firstPage: {
    title: string;
    type: 'image' | 'text';
    value: string;
    pageId: number;
  }[];
}

export enum EmailPageFieldTypes {
  Plan = 'Plan',
  ConsentText = 'Email consent text',
  ConsentAgreeButtonText = 'Yes consent button text',
  ConsentNotAgreeButtonText = 'No consent button text',
}

export enum PurchasePageFieldTypes {
  HeaderImage = 'Header image',
  HeaderSvg = 'Header svg',
  MobileHeaderSvg = 'Mobile header svg',
  DesktopHeaderSvg = 'Desktop header svg',
  HeaderText = 'Header text',
  PercentagePlanText = 'Percentage plan text',
  BeforeFemaleImage = 'Before female image',
  AfterFemaleImage = 'After female image',
  BeforeMaleImage = 'Before male image',
  AfterMaleImage = 'After male image',
  FemaleSummaryText = 'Female summary text',
  MaleSummaryText = 'Male summary text',
  ButtonText = 'Button text',

  ShowPersonalSummary = 'Show personal summary',
  PersonalSummaryTitle = 'Personal summary title',
  PersonalSummarySubtitle = 'Personal summary subtitle',

  IsPersonalizedPersonalSummary = 'Personalised Personal summary',

  Factor1Title = 'Factor #1 title',
  Factor1Subtitle = 'Factor #1 subtitle',
  Factor1CustomizationKey = 'Factor #1 customization key',
  Factor2Title = 'Factor #2 title',
  Factor2Subtitle = 'Factor #2 subtitle',
  Factor2CustomizationKey = 'Factor #2 customization key',
  Factor3Title = 'Factor #3 title',
  Factor3Subtitle = 'Factor #3 subtitle',
  Factor3CustomizationKey = 'Factor #3 customization key',
  Factor4Title = 'Factor #4 title',
  Factor4Subtitle = 'Factor #4 subtitle',
  Factor4CustomizationKey = 'Factor #4 customization key',
  Factor5Title = 'Factor #5 title',
  Factor5Subtitle = 'Factor #5 subtitle',
  Factor5CustomizationKey = 'Factor #5 customization key',
  Factor6Title = 'Factor #6 title',
  Factor6Subtitle = 'Factor #6 subtitle',
  Factor6CustomizationKey = 'Factor #6 customization key',
  Factor7Title = 'Factor #7 title',
  Factor7Subtitle = 'Factor #7 subtitle',
  Factor7CustomizationKey = 'Factor #7 customization key',

  // Common Issues (Entity_field_index)
  Issues_title = 'Common issues block title',

  Issue_title_1 = 'Issue #1 title',
  Issue_icon_1 = 'Issue #1 icon',
  Issue_bullets_1 = 'Issue #1 bulleted list',

  Issue_title_2 = 'Issue #2 title',
  Issue_icon_2 = 'Issue #2 icon',
  Issue_bullets_2 = 'Issue #2 bulleted list',

  Issue_title_3 = 'Issue #3 title',
  Issue_icon_3 = 'Issue #3 icon',
  Issue_bullets_3 = 'Issue #3 bulleted list',

  Issue_title_4 = 'Issue #4 title',
  Issue_icon_4 = 'Issue #4 icon',
  Issue_bullets_4 = 'Issue #4 bulleted list',

  // Reasons (Entity_field_index)
  Reasons_title = 'Reasons block title',

  Reason_image_1 = 'Reason #1 image',
  Reason_title_1 = 'Reason #1 title',
  Reason_description_1 = 'Reason #1 description',

  Reason_image_2 = 'Reason #2 image',
  Reason_title_2 = 'Reason #2 title',
  Reason_description_2 = 'Reason #2 description',

  Reason_image_3 = 'Reason #3 image',
  Reason_title_3 = 'Reason #3 title',
  Reason_description_3 = 'Reason #3 description',

  Reason_image_4 = 'Reason #4 image',
  Reason_title_4 = 'Reason #4 title',
  Reason_description_4 = 'Reason #4 description',

  Reason_image_5 = 'Reason #5 image',
  Reason_title_5 = 'Reason #5 title',
  Reason_description_5 = 'Reason #5 description',

  // Results (Entity_field_index)
  Results_title = 'Meditation results block title',
  Results_image = 'Meditation results block image',

  Result_image_1 = 'Result #1 image',
  Result_title_1 = 'Result #1 title',
  Result_subtitle_1 = 'Result #1 subtitle',

  Result_image_2 = 'Result #2 image',
  Result_title_2 = 'Result #2 title',
  Result_subtitle_2 = 'Result #2 subtitle',

  Result_image_3 = 'Result #3 image',
  Result_title_3 = 'Result #3 title',
  Result_subtitle_3 = 'Result #3 subtitle',

  Result_image_4 = 'Result #4 image',
  Result_title_4 = 'Result #4 title',
  Result_subtitle_4 = 'Result #4 subtitle',
}

export interface IPurchasePageReasons {
  title: string;
  items: Array<{
    image: string;
    title: string;
    description: string;
  }>;
}

export interface IPurchasePageIssues {
  title: string;
  items: Array<{
    icon: string;
    title: string;
    bullets: Array<string>;
  }>;
}

export interface IPurchasePageResults {
  title: string;
  image: string;
  items: Array<{
    image: string;
    title: string;
    subtitle: string;
  }>;
}

export enum CheckoutPageFieldTypes {
  Timer = 'Timer',
  CustomizedAreaUrl = 'Url for customized area',
  PlanType = 'Plan type',
  MainFeedbackFemaleImage = 'Feedback main female image',
  MainFeedbackFemaleWeight = 'Feedback main female weight',
  MainFeedbackFemaleName = 'Feedback main female name',
  MainFeedbackMaleImage = 'Feedback main male image',
  MainFeedbackMaleWeight = 'Feedback main male weight',
  LegalText = 'Legal text',
  MainFeedbackMaleName = 'Feedback main male name',
  MainFeedback = 'Feedback main',
  Feedback1 = 'Feedback 1',
  Feedback2 = 'Feedback 2',
  Feedback3 = 'Feedback 3',
  Question1 = 'Questions 1',
  Question1Text = 'Questions 1 text',
  Question2 = 'Questions 2',
  Question2Text = 'Questions 2 text',
  Question3 = 'Questions 3',
  Question3Text = 'Questions 3 text',
  Question4 = 'Questions 4',
  Question4Text = 'Questions 4 text',
  Question5 = 'Questions 5',
  Question5Text = 'Questions 5 text',
  GuaranteeTitle = 'Guarantee',
  GuaranteeText = 'Guarantee text',
  ButtonText = 'Button text',
  DobivashkaPlanName = 'Dobivashka plan name',
  DiscountPopupButtonText = 'Discount popup button',
  DiscountTitle = 'Discount title',
  HeaderImageDesktopMan = 'Header image desktop Man',
  HeaderImageDesktopWoman = 'Header image desktop Woman',
  HeaderImageFemaleBeforeMobile = 'Header image female-before mobile',
  HeaderImageMaleBeforeMobile = 'Header image male-before mobile',
  HeaderImageFemaleAfterMobile = 'Header image female-after mobile',
  HeaderImageMaleAfterMobile = 'Header image male-after mobile',
  TimerTitle = 'Timer title',
  Title = 'Title',
  Subtitle = 'Subtitle',
  WhatYouGetTitle = 'What you get title',
  WhatYouGetImageMan = 'What you get image Man',
  WhatYouGetImageWoman = 'What you get image Woman',
  WhatYouGet1 = 'What you get #1',
  WhatYouGet2 = 'What you get #2',
  WhatYouGet3 = 'What you get #3',
  WhatYouGet4 = 'What you get #4',
  WhatYouGet5 = 'What you get #5',
  WhatYouGet6 = 'What you get #6',
  WhatYouGet7 = 'What you get #7',
  WhatYouGet8 = 'What you get #8',
  WhatYouGet9 = 'What you get #9',
  WhatYouGet10 = 'What you get #10',
  Review1Title = 'Review 1 Title',
  Review1Body = 'Review 1 Body',
  Review1Name = 'Review 1 Name',
  Review1Date = 'Review 1 Date',
  Review2Title = 'Review 2 Title',
  Review2Body = 'Review 2 Body',
  Review2Name = 'Review 2 Name',
  Review2Date = 'Review 2 Date',
  Review3Title = 'Review 3 Title',
  Review3Body = 'Review 3 Body',
  Review3Name = 'Review 3 Name',
  Review3Date = 'Review 3 Date',

  PlanId1 = 'Checkout plan id 1',
  PlanId2 = 'Checkout plan id 2',
  PlanId3 = 'Checkout plan id 3',
  PlanId1Additional = 'Dobivashka plan id 1',
  PlanId2Additional = 'Dobivashka plan id 2',
  PlanId3Additional = 'Dobivashka plan id 3',

  PaymentPopupName = 'Payment popup plan name',
}

export interface EmailPageField {
  title: EmailPageFieldTypes;
  type: string;
  value: string;
}

export interface CheckoutPageField {
  title: CheckoutPageFieldTypes;
  type: string;
  value: string;
}

export interface PurchasePageField {
  title: PurchasePageFieldTypes;
  type: string;
  value: string;
}

export enum PricingType {
  P20 = 'P20',
  P30 = 'P30',
  THREE_PRICES = 'Three prices',
  FREE_TRIAL = 'Free trial',
}

export interface CustomPageField {
  title: 'Page url';
  type: 'text';
  value: string;
}

export interface GeneratedSaleFunnelResponse {
  checkoutPage: CheckoutPageField[] | CustomPageField[];
  emailPage: EmailPageField[] | CustomPageField[];
  pricingType: PricingType;
  purchasePage: PurchasePageField[] | CustomPageField[];
  upsellUrl: string;
}

export const fetchGeneratedFlow = async (flowId: string, lng?: string): Promise<AxiosResponse<GeneratedFlowResponse>> =>
  getAxios(lng).get(`${webConstructorApi}/flows/${flowId}?flowType=${flowType}&withRequiredQuestions=1`);
export const fetchGeneratedSaleFunnel = (
  salesFunnelId: string,
  lng?: string,
): Promise<AxiosResponse<GeneratedSaleFunnelResponse>> =>
  getAxios(lng).get(`${webConstructorApi}/sales-funnels/${salesFunnelId}?flowType=${flowType}`);
