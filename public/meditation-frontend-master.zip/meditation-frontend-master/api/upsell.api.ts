import { AxiosResponse } from 'axios';

import { apiHost, apiPrefix } from '../config';
import { UpsellPlanFriendId, UpsellPlanId } from '../constants/order.constants';
import { UpsellOrder } from '../types/order';
import getAxios from './axios';

interface UpsellPaymentParams {
  planId: UpsellPlanId | UpsellPlanFriendId;
  hash: string;
  isDiscounted: boolean;
  currency: string;
}

type StartUpsellResponse = AxiosResponse<{
  order: UpsellOrder;
  solidIframeUrl: string;
}>;

type UpsellResponse = AxiosResponse<{
  order: UpsellOrder;
}>;

type PayWithTokenResponse = AxiosResponse<{
  order: UpsellOrder;
}>;

export const getUpsellOrder = (parentOrderHash: string): Promise<UpsellResponse> => {
  return getAxios().get(`${apiHost}${apiPrefix}/order/${parentOrderHash}/upsell`);
};

export const startUpsellPayment = (params: UpsellPaymentParams): Promise<StartUpsellResponse> => {
  const { hash } = params;

  return getAxios().post(`${apiHost}${apiPrefix}/order/${hash}/upsell/start-payment`, params);
};

export const payWithTokenUpsell = (params: UpsellPaymentParams): Promise<PayWithTokenResponse> => {
  const { hash } = params;

  return getAxios().post(`${apiHost}${apiPrefix}/order/${hash}/upsell/token/pay`, params, {
    withCredentials: true,
  });
};

export const getPaypalLink = (parentOrderHash: string, upsellHash: string): Promise<AxiosResponse> =>
  getAxios().get(`${apiHost}${apiPrefix}/order/${parentOrderHash}/upsell/paypal/${upsellHash}`);

export function validateAppleMerchant(parentOrderHash, validationUrl): Promise<AxiosResponse> {
  return getAxios().post(`${apiHost}${apiPrefix}/order/${parentOrderHash}/upsell/apple/verify`, { validationUrl });
}

export function payWithApple(
  parentOrderHash,
  { orderHash, token }: { orderHash: string; token: string },
): Promise<AxiosResponse> {
  return getAxios().post(`${apiHost}${apiPrefix}/order/${parentOrderHash}/upsell/apple/pay`, { orderHash, token });
}

interface GooglePayTokenData {
  signature: string;
  protocolVersion: string;
  signedMessage: string;
}

export const payWithGoogle = (
  parentOrderHash,
  { orderHash, tokenData }: { orderHash: string; tokenData: GooglePayTokenData },
): Promise<AxiosResponse<{ paymentHash: string }>> =>
  getAxios().post(`${apiHost}${apiPrefix}/order/${parentOrderHash}/upsell/google/pay`, { orderHash, tokenData });

export const startUpsellPaymentPaypal = (
  parentOrderHash: string,
  params: { upsellHash: string },
): Promise<AxiosResponse> =>
  getAxios().patch(`${apiHost}${apiPrefix}/order/${parentOrderHash}/upsell/start-payment-paypal`, params, {
    withCredentials: true,
  });

// Endpoints to pay for upsell which provides user with coupon
export const startUpsellCouponPayment = (params: UpsellPaymentParams): Promise<StartUpsellResponse> => {
  const { hash } = params;

  return getAxios().post(`${apiHost}${apiPrefix}/order/${hash}/upsell-coupon/start-payment`, params);
};

export const payWithTokenUpsellCoupon = (params: UpsellPaymentParams): Promise<PayWithTokenResponse> => {
  const { hash } = params;

  return getAxios().post(`${apiHost}${apiPrefix}/order/${hash}/upsell-coupon/token/pay`, params, {
    withCredentials: true,
  });
};

export const startUpsellCouponPaymentPaypal = (
  parentOrderHash: string,
  params: { upsellHash: string },
): Promise<AxiosResponse> =>
  getAxios().patch(`${apiHost}${apiPrefix}/order/${parentOrderHash}/upsell-coupon/start-payment-paypal`, params, {
    withCredentials: true,
  });

export const startCombinedPayment = (params: UpsellPaymentParams): Promise<StartUpsellResponse> => {
  const { hash } = params;

  return getAxios().post(`${apiHost}${apiPrefix}/order/${hash}/upsell/payment`, params);
};
