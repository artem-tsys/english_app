module.exports = {
  parser: '@typescript-eslint/parser', // Specifies the ESLint parser
  extends: [
    'plugin:react/recommended', // Uses the recommended rules from @eslint-plugin-react
    'plugin:@typescript-eslint/recommended', // Uses the recommended rules from @typescript-eslint/eslint-plugin
    'plugin:prettier/recommended',
  ],
  globals: {
    __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: true,
  },
  plugins: ['react-hooks', 'simple-import-sort', 'import', 'unused-imports'],
  parserOptions: {
    ecmaVersion: 2018, // Allows for the parsing of modern ECMAScript features
    sourceType: 'module', // Allows for the use of imports
    ecmaFeatures: {
      jsx: true, // Allows for the parsing of JSX
    },
  },
  rules: {
    'react/prop-types': 0,
    '@typescript-eslint/explicit-function-return-type': 'off',
    'no-console': ['error', { allow: ['warn', 'error'] }],
    'arrow-body-style': 'off',
    'react/no-unescaped-entities': 'off',
    'eol-last': 2,
    'unused-imports/no-unused-imports-ts': 'error',
    '@typescript-eslint/no-unused-vars': 'error',
    'no-fallthrough': 2,
    'react-hooks/rules-of-hooks': 'error', // Checks rules of Hooks
    'react-hooks/exhaustive-deps': 'warn', // Checks effect dependencies,
    'react/jsx-curly-brace-presence': 'warn',
    'simple-import-sort/sort': 'error',
    'import/no-unused-modules': [2, { unusedExports: true, missingExports: true }],
  },
  overrides: [
    {
      files: ['*.ts', '*.tsx'],
      extends: [
        'plugin:@typescript-eslint/recommended', // Uses the recommended rules from @typescript-eslint/eslint-plugin
        'plugin:prettier/recommended',
        'plugin:import/typescript',
      ],
      parserOptions: {
        project: ['./tsconfig.json'],
      },
      rules: {
        '@typescript-eslint/no-unused-vars': 'error',
      },
    },
    {
      files: ['*.test.*', '*.spec.*', 'src/pages/**/*', '*.js', 'scripts/**/*'],
      rules: {
        'import/no-unused-modules': 0,
      },
    },
  ],
  settings: {
    react: {
      version: 'detect', // Tells eslint-plugin-react to automatically detect the version of React to use
    },
  },
};
