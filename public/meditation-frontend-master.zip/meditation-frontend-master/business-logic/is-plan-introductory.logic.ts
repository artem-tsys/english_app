import { Plan } from '../constants/order.constants';

export const isPlanIntroductory = (plan: Plan) => {
  return plan?.introductoryPrice > 0;
};
