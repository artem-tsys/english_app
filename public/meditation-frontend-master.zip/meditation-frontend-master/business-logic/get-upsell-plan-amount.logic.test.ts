import { UpsellPlanNoPrice } from '../constants/order.constants';
import addPricesToUpsellPlans from './get-upsell-plan-amount.logic';

describe('get upsell plans amount by main plan amount', () => {
  const dummyPlans = [
    {
      id: '1',
      name: 'Meal Plan + Workout Plan',
    },
    {
      id: '2',
      name: 'Custom Meal Plan',
    },
    {
      id: '3',
      name: 'Fat-Burning Home Workout Plan',
    },
  ];

  const plans = dummyPlans as UpsellPlanNoPrice[];

  test('upsell for 2$ main plan', () => {
    expect(addPricesToUpsellPlans(plans, plans, 2)).toEqual({
      upsellPlans: [
        { amount: 3000, discountedPrice: 1499, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 1500, discountedPrice: 999, id: '2', name: 'Custom Meal Plan' },
        { amount: 1500, discountedPrice: 999, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
      upsellPlansDobivashka: [
        { amount: 3000, discountedPrice: 999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 1500, discountedPrice: 699, id: '2', name: 'Custom Meal Plan' },
        { amount: 1500, discountedPrice: 699, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
    });
  });

  test('upsell for 19.99$ main plan', () => {
    expect(addPricesToUpsellPlans(plans, plans, 1999)).toEqual({
      upsellPlans: [
        { amount: 3000, discountedPrice: 1499, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 1500, discountedPrice: 999, id: '2', name: 'Custom Meal Plan' },
        { amount: 1500, discountedPrice: 999, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
      upsellPlansDobivashka: [
        { amount: 3000, discountedPrice: 999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 1500, discountedPrice: 699, id: '2', name: 'Custom Meal Plan' },
        { amount: 1500, discountedPrice: 699, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
    });
  });

  test('upsell for 21$ main plan', () => {
    expect(addPricesToUpsellPlans(plans, plans, 2100)).toEqual({
      upsellPlans: [
        { amount: 4000, discountedPrice: 1999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 2200, discountedPrice: 1499, id: '2', name: 'Custom Meal Plan' },
        { amount: 2200, discountedPrice: 1499, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
      upsellPlansDobivashka: [
        { amount: 4000, discountedPrice: 1299, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 2200, discountedPrice: 999, id: '2', name: 'Custom Meal Plan' },
        { amount: 2200, discountedPrice: 999, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
    });
  });

  test('upsell for 39.99$ main plan', () => {
    expect(addPricesToUpsellPlans(plans, plans, 3999)).toEqual({
      upsellPlans: [
        { amount: 6000, discountedPrice: 2999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 3000, discountedPrice: 1999, id: '2', name: 'Custom Meal Plan' },
        { amount: 3000, discountedPrice: 1999, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
      upsellPlansDobivashka: [
        { amount: 6000, discountedPrice: 1999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 3000, discountedPrice: 1399, id: '2', name: 'Custom Meal Plan' },
        { amount: 3000, discountedPrice: 1399, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
    });
  });

  test('upsell for 40$ main plan', () => {
    expect(addPricesToUpsellPlans(plans, plans, 4000)).toEqual({
      upsellPlans: [
        { amount: 8000, discountedPrice: 3999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 4500, discountedPrice: 2999, id: '2', name: 'Custom Meal Plan' },
        { amount: 4500, discountedPrice: 2999, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
      upsellPlansDobivashka: [
        { amount: 8000, discountedPrice: 2599, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 4500, discountedPrice: 2099, id: '2', name: 'Custom Meal Plan' },
        { amount: 4500, discountedPrice: 2099, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
    });
  });

  test('upsell for 65$ main plan', () => {
    expect(addPricesToUpsellPlans(plans, plans, 6500)).toEqual({
      upsellPlans: [
        { amount: 8000, discountedPrice: 3999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 4500, discountedPrice: 2999, id: '2', name: 'Custom Meal Plan' },
        { amount: 4500, discountedPrice: 2999, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
      upsellPlansDobivashka: [
        { amount: 8000, discountedPrice: 2599, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 4500, discountedPrice: 2099, id: '2', name: 'Custom Meal Plan' },
        { amount: 4500, discountedPrice: 2099, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
    });
  });

  test('upsell for 80$ main plan', () => {
    expect(addPricesToUpsellPlans(plans, plans, 8000)).toEqual({
      upsellPlans: [
        { amount: 10000, discountedPrice: 4999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 5200, discountedPrice: 3499, id: '2', name: 'Custom Meal Plan' },
        { amount: 5200, discountedPrice: 3499, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
      upsellPlansDobivashka: [
        { amount: 10000, discountedPrice: 3299, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 5200, discountedPrice: 2399, id: '2', name: 'Custom Meal Plan' },
        { amount: 5200, discountedPrice: 2399, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
    });
  });

  test('upsell for 500$ main plan', () => {
    expect(addPricesToUpsellPlans(plans, plans, 50000)).toEqual({
      upsellPlans: [
        { amount: 10000, discountedPrice: 4999, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 5200, discountedPrice: 3499, id: '2', name: 'Custom Meal Plan' },
        { amount: 5200, discountedPrice: 3499, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
      upsellPlansDobivashka: [
        { amount: 10000, discountedPrice: 3299, id: '1', name: 'Meal Plan + Workout Plan' },
        { amount: 5200, discountedPrice: 2399, id: '2', name: 'Custom Meal Plan' },
        { amount: 5200, discountedPrice: 2399, id: '3', name: 'Fat-Burning Home Workout Plan' },
      ],
    });
  });
});
