import { OrderStatus } from '../constants/order.constants';
import { AnyOrder } from '../types/order';

export const checkIsOrderPaid = (order: AnyOrder) => {
  return order && order.status >= OrderStatus.Paid;
};
