import { Plan } from '../constants/order.constants';

export const calculateFirstBillingPeriod = (plan: Plan) => {
  const { days, introductoryDays, trialDays } = plan;

  if (introductoryDays) {
    return introductoryDays;
  }

  if (trialDays) {
    return trialDays;
  }

  return days;
};
