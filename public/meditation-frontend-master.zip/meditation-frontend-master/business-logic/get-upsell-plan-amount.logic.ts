import { UpsellPlan, UpsellPlanNoPrice, UpsellPlans } from '../constants/order.constants';

interface UpsellPlanAmount {
  amount: number;
  discountedPrice: number;
}

const discountPercentage = [50, 33, 33];
const dobivashkaDiscountPercentage = [67, 53, 53];

const getDobivashkaAmount = (upsellDiscountedPrices: number[]): UpsellPlanAmount[] =>
  upsellDiscountedPrices.map((discountedPrice, idx) => {
    const amount = Math.round(discountedPrice / (100 - discountPercentage[idx])) * 100;

    return {
      amount: amount,
      discountedPrice: 100 * Math.round((amount / 100) * (1 - dobivashkaDiscountPercentage[idx] / 100)) - 1,
    };
  });

const getAmountByDiscountedPrices = (upsellDiscountedPrices: number[]): UpsellPlanAmount[] =>
  upsellDiscountedPrices.map((discountedPrice, idx) => ({
    amount: Math.round(discountedPrice / (100 - discountPercentage[idx])) * 100,
    discountedPrice: discountedPrice,
  }));

export const getUpsellPlansAmount = (mainPlanAmount: number): number[] =>
  mainPlanAmount <= 999
    ? [699, 499, 499]
    : mainPlanAmount <= 1999
    ? [1499, 999, 999]
    : mainPlanAmount <= 2999
    ? [1999, 1499, 1499]
    : mainPlanAmount <= 3999
    ? [2999, 1999, 1999]
    : mainPlanAmount <= 6999
    ? [3999, 2999, 2999]
    : [4999, 3499, 3499];

const getPlansWithFullAmount = (
  getAmountFn: (upsellDiscountedPrices: number[]) => UpsellPlanAmount[],
  upsellPlansNoPrice: UpsellPlanNoPrice[],
  mainPlanAmount: number,
) => {
  const upsellPlansDiscountAmounts = getUpsellPlansAmount(mainPlanAmount);

  return getAmountFn(upsellPlansDiscountAmounts).map((value, idx) => ({
    ...upsellPlansNoPrice[idx],
    amount: value.amount,
    discountedPrice: value.discountedPrice,
  }));
};
export const addPricesToUpsellPlansNoDobivashka = (
  upsellPlans: UpsellPlanNoPrice[],
  mainPlanAmount: number,
): UpsellPlan[] => getPlansWithFullAmount(getAmountByDiscountedPrices, upsellPlans, mainPlanAmount);

const addPricesToUpsellPlans = (
  upsellPlans: UpsellPlanNoPrice[],
  upsellPlansDobivashka: UpsellPlanNoPrice[],
  mainPlanAmount: number,
): UpsellPlans => ({
  upsellPlans: getPlansWithFullAmount(getAmountByDiscountedPrices, upsellPlans, mainPlanAmount),
  upsellPlansDobivashka: getPlansWithFullAmount(getDobivashkaAmount, upsellPlansDobivashka, mainPlanAmount),
});

export default addPricesToUpsellPlans;
