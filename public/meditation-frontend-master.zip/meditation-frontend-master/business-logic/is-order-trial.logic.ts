import { AnyOrder } from '../types/order';

export const isOrderTrial = (order: AnyOrder) => {
  if (!order) return false;

  const { planSnapshot } = order;

  if (!planSnapshot) return false;

  const isPlanWithTrialDays = planSnapshot.trialDays > 0;

  return isPlanWithTrialDays;
};
