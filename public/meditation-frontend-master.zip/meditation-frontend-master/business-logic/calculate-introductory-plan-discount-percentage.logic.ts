import { Plan } from '../constants/order.constants';

export const calculateIntroductoryPlanDiscountPercentage = (plan: Plan): number => {
  const { introductoryPrice, discountedPrice } = plan;

  return (discountedPrice - introductoryPrice) / discountedPrice;
};
