import { Plan } from '../constants/order.constants';

export const calculatePlanPriceToCharge = (plan: Plan, isDiscounted: boolean) => {
  const { amount, discountedPrice } = plan;

  return isDiscounted ? discountedPrice : amount;
};
