import { Plan, UpsellPlan } from '../constants/order.constants';

export const calculatePlanDiscountPercentage = (plan: Plan | UpsellPlan): number => {
  const { amount, discountedPrice } = plan;
  let priceToCharge = discountedPrice;

  if ('introductoryPrice' in plan) {
    priceToCharge = plan.introductoryPrice;
  }

  return (amount - priceToCharge) / amount;
};
