import { PlanId, possiblePlans } from '../constants/order.constants';
import { regularPlanToAdditionalDiscountMap } from './get-plan-with-additional-discount.logic';

const regularPlanPriceToAdditionalDiscountPlanMap: Record<number, PlanId> = {
  12000: PlanId.SpecialOfferSixMonth,
  6000: PlanId.SpecialOffer60ThreeMonths,
  4000: PlanId.SpecialOfferOneMonth10,
  2000: PlanId.SpecialOffer20OneWeek,
};

export const getSpecialOfferCustomizedPlan = (planId): PlanId => {
  if (!planId) {
    return PlanId.SpecialOfferOneMonth10;
  }
  const { amount } = possiblePlans.find((plan) => plan.id === planId);

  return regularPlanPriceToAdditionalDiscountPlanMap[amount] || regularPlanToAdditionalDiscountMap[planId] || planId;
};
