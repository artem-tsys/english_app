import { AnyOrder } from '../types/order';

export const isOrderSubscription = (order: AnyOrder) => {
  if (!order) return false;

  const { planSnapshot } = order;

  if (!planSnapshot) return false;

  return Boolean(planSnapshot.requiresRenewal);
};
