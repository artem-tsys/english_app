import { Plan } from '../constants/order.constants';

export const calculatePlanInstantChargePrice = (plan: Plan): number => {
  if (plan.introductoryPrice > 0) return plan.introductoryPrice;

  if (plan.trialDays > 0) return 0;

  return plan.discountedPrice;
};
