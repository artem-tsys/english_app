import { UpsellPlanId } from '../constants/order.constants';

const upsellPlanToUpsellDiscountMap = {};

export const gelUpsellPlanWithAdditionalDiscount = (planId: UpsellPlanId): UpsellPlanId => {
  return upsellPlanToUpsellDiscountMap[planId] || UpsellPlanId.ChakrasSleepAndStress;
};
