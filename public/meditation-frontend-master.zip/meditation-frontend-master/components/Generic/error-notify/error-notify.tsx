import React from 'react';

import ErrorFilledIcon from '../../Shared/Elements/icons/error-filled-icon';
import classes from './error-notify.module.scss';

interface ErrorNotifyProps {
  children: React.ReactNode;
}

const ErrorNotify = ({ children }: ErrorNotifyProps) => (
  <div className={classes.errorNotifyContainer}>
    <ErrorFilledIcon />
    <span className={classes.errorText}>{children}</span>
  </div>
);

export default ErrorNotify;
