import React, { useEffect, useState } from 'react';

import { getCookieSafe } from '../../../utils/cookie';
import Login from '../../Pages/unsubscribe/components/login';

const checkIsLoggedIn = () => {
  const authCookie = getCookieSafe('Authorization');
  if (!authCookie) return false;

  return true;
};

export interface LoginContext {
  isLoggedIn: boolean;
  setIsLoggedIn: (isLoggedIn: boolean) => void;
}

export const loginContext = React.createContext<LoginContext>(null);
const { Provider } = loginContext;

const LoginGuard = ({ children, onLoginReturned }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const isLoggedIn = checkIsLoggedIn();
    setIsLoggedIn(isLoggedIn);
  }, []);

  useEffect(() => {
    if (!isLoggedIn) {
      onLoginReturned();
    }
  }, [isLoggedIn]);

  if (isLoggedIn) {
    return (
      <Provider
        value={{
          isLoggedIn,
          setIsLoggedIn,
        }}
      >
        {children}
      </Provider>
    );
  }

  return (
    <Provider
      value={{
        isLoggedIn,
        setIsLoggedIn,
      }}
    >
      <Login />
    </Provider>
  );
};

export default LoginGuard;
