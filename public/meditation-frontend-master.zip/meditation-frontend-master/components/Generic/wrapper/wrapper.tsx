import { useRouter } from 'next/router';
import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import usePlanFromCookies from '../../../hooks/use-plan-from-cookies';
import { appLoaded } from '../../../redux/general/common.actions';
import FunnelProvider from '../../../utils/funnel-navigation/react/funnel-provider';
import useFunnel from '../../../utils/funnel-navigation/react/use-funnel-hook';
import Styles from '../styles/styles';

const PrefetchWrapper = ({ children }) => {
  const { nextPage } = useFunnel();
  const { prefetch } = useRouter();

  useEffect(() => {
    if (nextPage) {
      prefetch(nextPage);
    }
  }, [nextPage, prefetch]);

  return children;
};

// todo: add typescript stuff
const Wrapper = ({ children }) => {
  usePlanFromCookies();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(appLoaded());
  }, []);

  return (
    <FunnelProvider>
      <PrefetchWrapper>
        <Styles>{children}</Styles>
      </PrefetchWrapper>
    </FunnelProvider>
  );
};

export default Wrapper;
