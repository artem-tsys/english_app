import Bugsnag from '@bugsnag/js';
import BugsnagPluginReact from '@bugsnag/plugin-react';
import React, { ComponentType, ReactElement } from 'react';

import { bugsnagApiKey, isInBrowser, targetEnv } from '../../../config';

let ErrorBoundary: ComponentType = ({ children }: { children: ReactElement }) => children;

if (bugsnagApiKey && isInBrowser) {
  Bugsnag.start({
    apiKey: bugsnagApiKey,
    plugins: [new BugsnagPluginReact()],
    releaseStage: targetEnv,
    enabledReleaseStages: ['prod'],
  });

  ErrorBoundary = Bugsnag.getPlugin('react').createErrorBoundary(React);
}

export default ErrorBoundary;
