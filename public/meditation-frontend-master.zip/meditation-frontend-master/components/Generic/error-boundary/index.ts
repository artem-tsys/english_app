export { default } from './error-boundary';
