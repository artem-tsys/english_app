import React from 'react';
import { useSelector } from 'react-redux';

import useStyles from '../../../hooks/use-styles.hook';
import { generatedStylesSelector } from '../../../redux/generated-quiz/generated-quiz.selectors';
import Head from '../../../utils/next-with-i18n/head';
import classes from './styles.module.scss';

const DEFAULT_FONT = 'Nunito+Sans';

const Styles = ({ children }) => {
  const style = useStyles();
  const generatedStyles = useSelector(generatedStylesSelector);

  const font = generatedStyles?.font || DEFAULT_FONT;

  return (
    <>
      <Head>
        <link
          href={`https://fonts.googleapis.com/css?family=${font}:400,600,700,800&display=swap`}
          rel="stylesheet"
          key="font"
        />
      </Head>
      <main className={classes.container} style={style} id="main">
        {children}
      </main>
    </>
  );
};

export default Styles;
