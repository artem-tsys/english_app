import React from 'react';

import useGeneratedSaleFunnel from '../../../hooks/use-generated-sale-funnel';
import Loader from '../../Shared/Elements/loader/loader';

const SalePageWrapper = ({ children }) => {
  const { isSaleFunnelLoading, isSaleFunnelNotRequested } = useGeneratedSaleFunnel();
  if (isSaleFunnelNotRequested) {
    return null;
  }
  if (isSaleFunnelLoading) {
    return <Loader isShown />;
  }

  return children;
};

export default SalePageWrapper;
