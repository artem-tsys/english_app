import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { openSidebar } from '../../../../redux/general/common.actions';
import {
  generatedLandingPageUrlSelector,
  generatedLogoSetSelector,
} from '../../../../redux/generated-quiz/generated-quiz.selectors';
import Link from '../../../../utils/next-with-i18n/link';
import { ImageSet } from '../../../../utils/src-set';
import BurgerButton from '../../../Shared/Elements/burger-button/burger-button';
import classes from './transparent-absolute-header.module.scss';

interface Props {
  logoSet?: ImageSet;
  burgerColor?: string;
}

function TransparentAbsoluteHeader({ logoSet, burgerColor }: Props) {
  const dispatch = useDispatch();
  const homePage = useSelector(generatedLandingPageUrlSelector);
  const generatedLogoSet = useSelector(generatedLogoSetSelector);
  const logoSetToRender = logoSet || generatedLogoSet;

  const onMenuButtonClick = () => {
    dispatch(openSidebar());
  };

  return (
    <header className={classes.header}>
      {homePage && (
        <Link href={homePage}>
          <a>
            <img className={classes.logo} src={logoSetToRender.src} srcSet={logoSetToRender.srcSet} alt="" />
          </a>
        </Link>
      )}
      <BurgerButton onClick={onMenuButtonClick} color={burgerColor} />
    </header>
  );
}

export default TransparentAbsoluteHeader;
