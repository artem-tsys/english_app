import cn from 'classnames';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { closeSidebar } from '../../../redux/general/common.actions';
import { isSidebarOpenedSelector } from '../../../redux/general/common.selectors';
import Link from '../../../utils/next-with-i18n/link';
import { useRouter } from '../../../utils/next-with-i18n/router';
import useTranslation from '../../../utils/next-with-i18n/use-translation';
import classes from './page.module.scss';

const Sidebar = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const isOpen = useSelector(isSidebarOpenedSelector);
  const router = useRouter();

  const onClose = () => {
    dispatch(closeSidebar());
  };

  useEffect(() => {
    // closing sidebar when a route starts to change
    router.events.on('routeChangeStart', onClose);
    router.events.on('hashChangeStart', onClose);
    return () => {
      router.events.off('routeChangeStart', onClose);
      router.events.off('hashChangeComplete', onClose);
    };
  }, []);

  return (
    <div className={cn(classes.sidebarBackdrop, { [classes.isOpen]: isOpen })}>
      <div className={classes.sidebar}>
        <div className={classes.sidebarCloseButton} onClick={onClose} />
        <Link href="/contact-us">
          <a className={classes.sidebarLink}>{t('sidebar:contactMe', 'Contact Us')}</a>
        </Link>
        <Link href="/faq">
          <a className={classes.sidebarLink}>{t('sidebar:faq', 'FAQ')}</a>
        </Link>
        <Link href="/terms">
          <a className={classes.sidebarLink}>{t('sidebar:terms', 'Terms of Service')}</a>
        </Link>
        <Link href="/privacy-policy">
          <a className={classes.sidebarLink}>{t('sidebar:privacyPolicy', 'Privacy Policy')}</a>
        </Link>
        <Link href="/subscription-policy">
          <a className={classes.sidebarLink}>{t('sidebar:subscriptionPolicy', 'Subscription Policy')}</a>
        </Link>
        <Link href="/money-back-policy">
          <a className={classes.sidebarLink}>{t('sidebar:moneyBackPolicy', 'Money-Back Policy')}</a>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
