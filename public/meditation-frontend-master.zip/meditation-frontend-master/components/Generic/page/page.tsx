import React, { ReactElement } from 'react';

import { HEADER_HEIGHT } from '../../../constants/header.constants';
import useSetBodyColor from '../../../hooks/use-set-body-color-hook';
import { Styles } from '../../../redux/generated-quiz/generated-quiz.types';
import PopupManager from '../popup-manager/popup-manager';
import RegularHeader from './header/header';
import classes from './page.module.scss';
import Sidebar from './sidebar';

interface Props {
  Header?: ReactElement | null;
  pageClassName?: string;
  dataPage?: string;
  bodyColor?: keyof Styles;
}

const Page: React.FunctionComponent<Props> = ({
  children,
  Header = <RegularHeader />,
  pageClassName,
  dataPage = 'general',
  bodyColor = 'background1Color',
}) => {
  useSetBodyColor(bodyColor);
  // padding reserved for header
  const paddingTop = Header === null ? 0 : HEADER_HEIGHT;

  return (
    <div
      className={pageClassName ? pageClassName : classes.container}
      style={{ paddingTop }}
      data-page={dataPage}
      id="page"
    >
      {Header}
      {children}
      <PopupManager />
      <Sidebar />
    </div>
  );
};

export default Page;
