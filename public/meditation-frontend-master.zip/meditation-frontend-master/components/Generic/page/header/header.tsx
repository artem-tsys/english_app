import cn from 'classnames';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { openSidebar } from '../../../../redux/general/common.actions';
import { isHeaderHiddenSelector } from '../../../../redux/general/common.selectors';
import { stepBackGenerated } from '../../../../redux/generated-quiz/generated-quiz.actions';
import {
  generatedLandingPageUrlSelector,
  generatedLogoSetSelector,
  generatedQuestionStepSelector,
  questionsAmountSelector,
} from '../../../../redux/generated-quiz/generated-quiz.selectors';
import Link from '../../../../utils/next-with-i18n/link';
import { ImageSet } from '../../../../utils/src-set';
import ArrowBack from '../../../Shared/Elements/arrow-back';
import BurgerButton from '../../../Shared/Elements/burger-button/burger-button';
import classes from './header.module.scss';

export interface Props {
  className?: string;
  showQuizProgress?: boolean;
  showBurger?: boolean;
  logoSet?: ImageSet;
  burgerColor?: string;
}

const Header: React.FunctionComponent<Props> = ({
  className,
  showQuizProgress = false,
  showBurger = true,
  logoSet,
  burgerColor,
}) => {
  const isHeaderHidden = useSelector(isHeaderHiddenSelector);
  const homePage = useSelector(generatedLandingPageUrlSelector);
  const stepBack = () => dispatch(stepBackGenerated());
  const currentStep = useSelector(generatedQuestionStepSelector);
  const stepAmount = useSelector(questionsAmountSelector);

  const generatedLogoSet = useSelector(generatedLogoSetSelector);
  const headerLogoSet = logoSet || generatedLogoSet;

  const dispatch = useDispatch();
  const onMenuButtonClick = () => {
    dispatch(openSidebar());
  };

  const onBackButtonClick = () => {
    stepBack();
  };

  if (isHeaderHidden) return null;

  return (
    <header className={cn(classes.header, className)}>
      {showQuizProgress && <ArrowBack onClick={onBackButtonClick} />}
      {homePage && (
        <Link href={homePage}>
          <a>
            <img className={classes.logo} src={headerLogoSet?.src} srcSet={headerLogoSet?.srcSet} alt="" />
          </a>
        </Link>
      )}
      {showQuizProgress ? (
        <span className={classes.progress}>
          <span className={classes.currentProgress}>{currentStep}</span>{' '}
          <span className={classes.progressLighter}>/</span> {stepAmount}
        </span>
      ) : (
        showBurger && <BurgerButton onClick={onMenuButtonClick} color={burgerColor} />
      )}
    </header>
  );
};

export default Header;
