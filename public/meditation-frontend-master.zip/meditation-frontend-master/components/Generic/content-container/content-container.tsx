import React, { ReactNode } from 'react';

import classes from './content-container.module.scss';

interface IContentContainerProps {
  children: ReactNode;
}

const ContentContainer: React.FC<IContentContainerProps> = ({ children }) => {
  return <div className={classes.container}>{children}</div>;
};

export default ContentContainer;
