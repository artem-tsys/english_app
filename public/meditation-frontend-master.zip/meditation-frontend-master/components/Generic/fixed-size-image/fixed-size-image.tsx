import React from 'react';

import CloudinaryImage from '../../Shared/Elements/cloudinary-image/image';
import classes from './fixed-size-image.module.css';

interface Props {
  imageName: string;
  width: number;
  height: number;
}

const FixedSizeImage = ({ imageName, width, height }: Props) => {
  const ratio = height / width;
  return (
    <div className={classes.container} style={{ maxWidth: width }}>
      <div className={classes.containerInner} style={{ paddingBottom: `${100 * ratio}%` }}>
        <CloudinaryImage imageName={imageName} className={classes.image} />
      </div>
    </div>
  );
};

export default FixedSizeImage;
