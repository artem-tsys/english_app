import Head from 'next/head';
import React from 'react';

import { instanaKey } from '../../../config';

export default function HeadWithThirdParty() {
  return (
    <>
      <Head>
        <title key="title">BetterMe</title>
        <link rel="preconnect" href="https://fonts.gstatic.com/" crossOrigin="true" />
        <link rel="dns-prefetch" href="https://fonts.gstatic.com/" />
        <link rel="preconnect" href="https://res.cloudinary.com/" crossOrigin="true" />
        <link rel="dns-prefetch" href="https://res.cloudinary.com/" />
        <link rel="icon" type="image/png" sizes="192x192" href="/android-chrome-192x192.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="512x512" href="/android-chrome-512x512.png" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <script defer crossOrigin="anonymous" src="https://eum.instana.io/eum.min.js"></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-5WVFRTZ');`,
          }}
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `  (function(s,t,a,n){s[t]||(s[t]=a,n=s[a]=function(){n.q.push(arguments)},
              n.q=[],n.v=2,n.l=1*new Date)})(window,"InstanaEumObject","ineum");
            
              ineum('reportingUrl', 'https://eum-green-saas.instana.io');
              ineum('key', '${instanaKey}');
              
              ineum('whitelistedOrigins',[/.*\.betterme\.world.*/,/.*\.betterme-apps\.com.*/])
              ineum('trackSessions');`,
          }}
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag() { dataLayer.push(arguments); }

            gtag('js', new Date());

            gtag('config', 'UA-135644723-4', { 'optimize_id': 'GTM-P66BCQ4'});`,
          }}
        />
        <meta key="theme" name="theme-color" content="#f9f9f9" />
        <meta httpEquiv="Accept-CH" content="DPR, Viewport-Width, Width" />
      </Head>
      <noscript
        dangerouslySetInnerHTML={{
          __html: `<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5WVFRTZ"
        height="0" width="0" style="display:none;visibility:hidden"></iframe>`,
        }}
      />
    </>
  );
}
