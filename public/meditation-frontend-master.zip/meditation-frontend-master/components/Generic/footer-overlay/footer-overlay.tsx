import React, { useEffect } from 'react';

import { FOOTER_OVERLAY_HEIGHT } from '../../../constants/footer-overlays.constants';
import classes from './footer-overlay.module.scss';

const FooterOverlay = ({ children }) => {
  useEffect(() => {
    if (children) {
      (window as any).document.body.style['padding-bottom'] = `${FOOTER_OVERLAY_HEIGHT}px`;
    } else {
      (window as any).document.body.style['padding-bottom'] = 0;
    }
    return () => {
      (window as any).document.body.style['padding-bottom'] = 0;
    };
  }, [children]);

  return <div className={classes.container}>{children}</div>;
};

export default FooterOverlay;
