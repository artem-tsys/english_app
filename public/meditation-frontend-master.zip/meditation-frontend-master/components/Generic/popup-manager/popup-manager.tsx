import { useRouter } from 'next/router';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { PopupName } from '../../../constants/popups.constants';
import { hidePopup } from '../../../redux/general/common.actions';
import { shownPopupSelector } from '../../../redux/general/common.selectors';
import classes from '../../../styles/popups.module.scss';
import {
  AdditionalDiscountPopup,
  UpsellAdditionalDiscountPopup,
} from '../../Shared/Elements/popups/additional-discount-popup/additional-discount-popup';
import CongratulationsCouponPopup from '../../Shared/Elements/popups/congratulations-coupon-popup/congratulations-coupon-popup';
import CongratulationsWelcomePopup from '../../Shared/Elements/popups/congratulations-welcome-popup/congratulations-welcome-popup';
import EmailPopup from '../../Shared/Elements/popups/email-popup/email-popup';
import ErrorPopup from '../../Shared/Elements/popups/error-popup/error-popup';
import IntroductoryOfferPaymentPopupWithBreakdown from '../../Shared/Elements/popups/introductory-offer-payment-popup-with-breakdown/introductory-offer-payment-popup-with-breakdown';
import IntroductoryOfferPaymentPopupWithTrial from '../../Shared/Elements/popups/introductory-offer-payment-popup-with-trial/introductory-offer-payment-popup-with-trial';
import IntroductoryOfferPaymentPopup from '../../Shared/Elements/popups/introductory-offer-payment-popup/introductory-offer-payment-popup';
import HorizontalPaymentPopupWithLegalText from '../../Shared/Elements/popups/payment-popup/horizontal-payment-popup-with-legal-text';
import HorizontalPaymentPopupWithVisibleLegalText from '../../Shared/Elements/popups/payment-popup/horizontal-payment-popup-with-visible-legal-text/horizontal-payment-popup-with-legal-text';
import NoPaypalPaymentPopup from '../../Shared/Elements/popups/payment-popup/no-paypal-payment-popup/no-paypal-payment-popup';
import UpsellPaymentPopup from '../../Shared/Elements/popups/payment-popup/upsell-payment-popup';

const popupsConfig: Record<PopupName, any> = {
  HORIZONTAL_PAYMENT_POPUP_WITH_LEGAL_TEXT: HorizontalPaymentPopupWithLegalText,
  ADDITIONAL_DISCOUNT_POPUP: AdditionalDiscountPopup,
  INTRODUCTORY_OFFER_PAYMENT_POPUP: IntroductoryOfferPaymentPopup,
  INTRODUCTORY_OFFER_PAYMENT_POPUP_WITH_BREAKDOWN: IntroductoryOfferPaymentPopupWithBreakdown,
  INTRODUCTORY_OFFER_PAYMENT_POPUP_WITH_BREAKDOWN_NO_DOBIVASHKA: IntroductoryOfferPaymentPopupWithBreakdown,
  PAYMENT_POPUP_WITH_TRIAL: IntroductoryOfferPaymentPopupWithTrial,
  UPSELL_PAYMENT_POPUP: UpsellPaymentPopup,
  UPSELL_ADDITIONAL_DISCOUNT_POPUP: UpsellAdditionalDiscountPopup,
  EMAIL_POPUP: EmailPopup,
  ERROR_POPUP: ErrorPopup,
  CONGRATULATIONS_COUPON_POPUP: CongratulationsCouponPopup,
  CONGRATULATIONS_WELCOME_POPUP: CongratulationsWelcomePopup,
  NO_PAYPAL_PAYMENT_POPUP: NoPaypalPaymentPopup,
  HORIZONTAL_PAYMENT_POPUP_WITH_VISIBLE_LEGAL_TEXT: HorizontalPaymentPopupWithVisibleLegalText,
};

const PopupManager = () => {
  const dispatch = useDispatch();
  const shownPopupName = useSelector(shownPopupSelector);
  const PopupToShow = popupsConfig[shownPopupName];
  const hasPopupToShow = shownPopupName && PopupToShow;
  const { pathname } = useRouter();

  useEffect(() => {
    if (hasPopupToShow) {
      (window as any).document.body.style.overflow = 'hidden';
    } else {
      (window as any).document.body.style.overflow = 'auto';
    }
  }, [hasPopupToShow]);

  useEffect(() => {
    if (hasPopupToShow) {
      dispatch(hidePopup(false));
    }
  }, [pathname]);

  if (!hasPopupToShow) return null;

  const onBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      dispatch(hidePopup());
    }
  };

  return (
    <div onClick={onBackdropClick} className={classes.backdrop} onTouchMove={(e) => e.preventDefault()}>
      <PopupToShow />
    </div>
  );
};

export default PopupManager;
