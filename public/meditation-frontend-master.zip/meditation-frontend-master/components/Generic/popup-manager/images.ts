import createCloudinaryImageSet from '../../../utils/src-set';

export const crossIconSet = createCloudinaryImageSet(`/public/images/cross.svg`);
