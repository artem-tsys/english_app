import cn from 'classnames';
import React from 'react';
import { useDispatch } from 'react-redux';

import { hidePopup } from '../../../redux/general/common.actions';
import classes from '../../../styles/popups.module.scss';
import { crossIconSet } from './images';

interface Props {
  isScrollable?: boolean;
  hideCloseButton?: boolean;
  header?: React.ReactNode;
  className?: string;
  children?: React.ReactNode;
  headerClassName?: string;
}

function Popup({ children, header, className, hideCloseButton, isScrollable = true, headerClassName }, ref) {
  const dispatch = useDispatch();
  const closePopup = () => dispatch(hidePopup());

  return (
    <div className={cn(classes.popup, className)} data-cy="popup">
      {!hideCloseButton && (
        <div role="button" aria-readonly="true" className={classes.closeButton} onClick={closePopup}>
          <img src={crossIconSet.src} srcSet={crossIconSet.srcSet} alt="" />
        </div>
      )}
      <div
        className={cn(classes.popupContent, { [classes.notScrollable]: !isScrollable })}
        ref={ref}
        id="popup-content"
      >
        {header && <div className={cn(classes.popupHeader, headerClassName)}>{header}</div>}
        {children}
      </div>
    </div>
  );
}

export default React.forwardRef<HTMLInputElement, Props>(Popup);
