import React from 'react';

const LoadingIcon = (props) => {
  return (
    <svg width="24" height="24" viewBox="0 0 42 42" aria-label="Loading" {...props}>
      <g transform="translate(3 3)" strokeWidth={5} fill="none" fillRule="evenodd">
        <circle strokeOpacity={0.5} cx={18} cy={18} r={18} />
        <path d="M22.592 35.404c9.61-2.535 15.348-12.385 12.812-21.996" />
      </g>
    </svg>
  );
};

export default LoadingIcon;
