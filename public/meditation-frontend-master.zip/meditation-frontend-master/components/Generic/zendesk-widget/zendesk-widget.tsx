import React, { useEffect, useState } from 'react';

import { isInBrowser } from '../../../config';
import clientSideLang from '../../../utils/next-with-i18n/client-side-lang';
import Head from '../../../utils/next-with-i18n/head';
import { useRouter } from '../../../utils/next-with-i18n/router';
import useTranslation from '../../../utils/next-with-i18n/use-translation';
import ChatIcon from './chat-icon';
import CloseIcon from './close-icon';
import LoadingIcon from './loading-icon';
import classes from './zendesk-widget.module.scss';

const BTN_CONFIG = {
  opened: {
    // i18n:extract t('zendeskWidget:closeBtn', 'Close')
    i18nKey: 'zendeskWidget:closeBtn',
    text: 'Close',
    // eslint-disable-next-line react/display-name
    Icon: (props) => <CloseIcon className={classes.buttonIcon} {...props} />,
  },
  closed: {
    // i18n:extract t('zendeskWidget:chatNow', 'Chat now')
    i18nKey: 'zendeskWidget:chatNow',
    text: 'Chat now',
    // eslint-disable-next-line react/display-name
    Icon: (props) => <ChatIcon className={classes.buttonIcon} {...props} />,
  },
  loading: {
    i18nKey: null,
    text: null,
    // eslint-disable-next-line react/display-name
    Icon: (props) => <LoadingIcon className={classes.spinner} {...props} />,
  },
};

const ZendeskWidget = () => {
  const { asPath } = useRouter();
  const { t } = useTranslation();
  const [shouldLoadWidget, setShouldLoadWidget] = useState(false);
  const [widgetLoaded, setWidgetLoaded] = useState(false);
  const [widgetLoadFail, setWidgetLoadFail] = useState(false);
  const [isOpened, setIsOpened] = useState(false);

  useEffect(() => {
    // start loading script right away if URL contains #support hash route
    if (asPath.indexOf('#support') > -1) {
      setShouldLoadWidget(true);
    }
  }, [asPath]);

  const handleButtonClick = (e) => {
    e.preventDefault();
    if (!shouldLoadWidget) {
      setShouldLoadWidget(true);
      return;
    }

    try {
      (window as any).zE(() => {
        setIsOpened(!isOpened);
        if (isOpened) {
          (window as any).zE('webWidget', 'hide');
        } else {
          (window as any).zE.activate({ hideOnClose: true });
        }
      });
    } catch (e) {}
  };

  useEffect(() => {
    (window as any).zESettings = {
      webWidget: {
        color: {
          theme: '#677D96',
        },
        position: { horizontal: 'right', vertical: 'bottom' },
        offset: {
          horizontal: '0',
          vertical: '75px',
        },
      },
      analytics: true,
    };
  }, []);

  useEffect(() => {
    const zeSnippetScript = document.getElementById('ze-snippet');
    if (shouldLoadWidget && zeSnippetScript) {
      zeSnippetScript.onload = () => {
        try {
          (window as any).zE(() => {
            setWidgetLoaded(true);
            (window as any).zE('webWidget', 'hide');
            (window as any).zE.activate({ hideOnClose: true });
            setIsOpened(true);
            (window as any).zE.setLocale(clientSideLang());

            (window as any).zE('webWidget:on', 'close', function () {
              (window as any).zE('webWidget', 'hide');
              setIsOpened(false);
            });
            (window as any).zE('webWidget:on', 'open', function () {
              setIsOpened(true);
            });
          });
        } catch (e) {}
      };
      zeSnippetScript.onerror = () => setWidgetLoadFail(true);
    }

    return () => {
      try {
        (window as any).zE(() => {
          (window as any).zE('webWidget', 'hide');
        });
      } catch (e) {}
    };
  }, [shouldLoadWidget]);

  if (!isInBrowser || widgetLoadFail) return null;

  const isLoading = shouldLoadWidget && !widgetLoaded;
  const { text, i18nKey, Icon } = isLoading ? BTN_CONFIG.loading : isOpened ? BTN_CONFIG.opened : BTN_CONFIG.closed;
  const label = text && t(i18nKey, text);

  return (
    <>
      <Head>
        {shouldLoadWidget && (
          <script
            key="zendesk"
            id="ze-snippet"
            src="https://static.zdassets.com/ekr/snippet.js?key=d54e39ee-143c-4c7c-9022-a1edac1cd1e8"
          ></script>
        )}
      </Head>
      <div className={classes.container}>
        <button
          className={classes.button}
          onClick={handleButtonClick}
          disabled={isLoading}
          data-button="zendesk-widget-open"
        >
          <Icon aria-label={label} />
          <span className={classes.buttonText}>{label}</span>
        </button>
      </div>
    </>
  );
};

export default ZendeskWidget;
