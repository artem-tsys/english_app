import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { DISCOUNT_TIME, ONE_MINUTE, ONE_SECOND } from '../../../../constants/timer.constants';
import { useInterval } from '../../../../hooks/use-interval.hook';
import { Trans } from '../../../../i18n';
import {
  additionalDiscountCountdownAbandoned,
  additionalDiscountCountdownCompleted,
} from '../../../../redux/order/order.actions';
import {
  additionalDiscountCountdownAbandonedSelector,
  additionalDiscountCountdownPausedSelector,
  additionalDiscountCountdownStartedAtSelector,
  isAdditionalDicountCountdownHiddenSelector,
} from '../../../../redux/order/order.selectors';
import { formatNumber } from '../../../../utils/format-number.util';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import classes from './additional-discount-countdown.module.scss';

interface Classes {
  [key: string]: string;
}

export interface AdditionalDiscountCountdownProps {
  styleClasses?: Classes;
}

export const AdditionalDiscountCountdownDefault = ({ styleClasses = classes }: AdditionalDiscountCountdownProps) => {
  const { t } = useTranslation();

  const dispatch = useDispatch();
  const countdownStartedAt = useSelector(additionalDiscountCountdownStartedAtSelector);
  const isPaused = useSelector(additionalDiscountCountdownPausedSelector);
  const isAbandoned = useSelector(additionalDiscountCountdownAbandonedSelector);
  const initialTime = isAbandoned ? 0 : DISCOUNT_TIME;
  const [timeLeft, setTimeLeft] = useState(initialTime);
  const isAdditionalDicountCountdownHidden = useSelector(isAdditionalDicountCountdownHiddenSelector);
  const isRunning = !isAbandoned && timeLeft > 0 && countdownStartedAt && !isPaused;

  useEffect(() => {
    if (timeLeft === 0) {
      dispatch(additionalDiscountCountdownCompleted());
    }
  }, [timeLeft]);

  useEffect(() => {
    return () => {
      dispatch(additionalDiscountCountdownAbandoned());
    };
  }, []);

  useInterval(
    () => {
      setTimeLeft(timeLeft - ONE_SECOND);
    },
    isRunning ? ONE_SECOND : null,
  );

  if (isAdditionalDicountCountdownHidden) return null;

  const minutesLeft = Math.floor(timeLeft / ONE_MINUTE);
  const secondsLeft = Math.floor((timeLeft - minutesLeft * ONE_MINUTE) / ONE_SECOND);

  return (
    <footer className={styleClasses.container}>
      <div className={styleClasses.text}>
        {/* i18n:extract t('countdown:reservedPrice', `<0>Reserved</0> price for`) */}
        <Trans i18nKey="countdown:reservedPrice" components={[<span className={classes.highlightedText} key="0" />]} />
      </div>
      <div className={styleClasses.timeBlock}>
        <span className={styleClasses.time}>
          <span className={styleClasses.timeItem}>{formatNumber(minutesLeft)}</span>
          <span className={styleClasses.divider}>:</span>
          <span className={styleClasses.timeItem}>{formatNumber(secondsLeft)}</span>
        </span>
        <span className={styleClasses.timeUnits}>{t('discountCountdown:timeUnits', 'minutes seconds')}</span>
      </div>
    </footer>
  );
};

const AdditionalDiscountCountdown = () => <AdditionalDiscountCountdownDefault />;

export default AdditionalDiscountCountdown;
