import * as React from 'react';

interface CheckProps {
  className?: string;
}

const Check = ({ className }: CheckProps) => (
  <svg width={16} height={16} viewBox="0 0 16 16" fill="none" className={className}>
    <g clipPath="url(#prefix__clip0)">
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M13.607 2.385a1.468 1.468 0 011.982 0 1.26 1.26 0 010 1.861l-9.264 8.702a1.446 1.446 0 01-.992.385c-.358 0-.717-.128-.991-.385L.41 9.283a1.26 1.26 0 010-1.86 1.468 1.468 0 011.982 0l2.94 2.734 8.274-7.772z"
        fill="var(--primary400Color)"
      />
    </g>
    <defs>
      <clipPath id="prefix__clip0">
        <path fill="#fff" d="M0 0h16v16H0z" />
      </clipPath>
    </defs>
  </svg>
);

export default Check;
