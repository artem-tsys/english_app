import React from 'react';

const ErrorFilledIcon = (props) => (
  <svg width={24} height={24} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path
      d="M20.49 3.51c-4.682-4.68-12.298-4.68-16.98 0-4.68 4.681-4.68 12.299 0 16.98A11.965 11.965 0 0012 24c3.075 0 6.149-1.17 8.489-3.51 4.681-4.681 4.681-12.299 0-16.98zM12 20.005a1 1 0 110-2.002 1 1 0 010 2.002zM13 15a1 1 0 11-2 0V4.997a1 1 0 112 0V15z"
      fill="#F3AE54"
    />
  </svg>
);

export default ErrorFilledIcon;
