import React, { FC } from 'react';

interface ILeftTriangleArrowIcon {
  className?: string;
}

const LeftTriangleArrowIcon: FC<ILeftTriangleArrowIcon> = ({ className }) => {
  return (
    <svg className={className} viewBox="0 0 72 264" xmlns="http://www.w3.org/2000/svg">
      <path
        opacity="0.8"
        d="M75.9173 4.5851C77.0722 2.53484 75.5907 0 73.2376 0C72.1271 0 71.1028 0.598633 70.5578 1.5662L2.62791 122.164C-0.803947 128.257 -0.804489 135.699 2.6265 141.793L70.5581 262.434C71.1029 263.401 72.127 264 73.2375 264C75.5904 264 77.0715 261.465 75.9164 259.415L9.66213 141.848C6.22783 135.754 6.22707 128.308 9.66013 122.213L75.9173 4.5851Z"
      />
    </svg>
  );
};

export default LeftTriangleArrowIcon;
