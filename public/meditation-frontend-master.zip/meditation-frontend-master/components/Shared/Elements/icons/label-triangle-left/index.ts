export { default } from './label-triangle-left';
