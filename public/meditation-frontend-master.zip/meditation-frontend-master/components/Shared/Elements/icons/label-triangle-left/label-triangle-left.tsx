import React from 'react';

function LabelTriangleLeft({ className }) {
  return (
    <svg
      width="96"
      height="48"
      viewBox="0 0 96 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path d="M15.5669 1.57768C16.3234 0.583597 17.5009 0 18.7501 0H89.5039C92.8176 0 95.5039 2.68629 95.5039 6V42C95.5039 45.3137 92.8176 48 89.5039 48H19.7413C17.8675 48 16.1013 47.1246 14.9666 45.6335L1.26892 27.6335C-0.364796 25.4866 -0.364799 22.5134 1.26892 20.3665L15.5669 1.57768Z" />
    </svg>
  );
}

export default LabelTriangleLeft;
