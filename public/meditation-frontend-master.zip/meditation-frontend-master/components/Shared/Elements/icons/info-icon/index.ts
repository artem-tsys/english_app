export { default } from './info-icon';
