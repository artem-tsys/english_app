import React from 'react';

interface Props {
  className: string;
  onClick?: () => void;
}

function CrossIconNoCircle({ className, onClick }: Props) {
  return (
    <svg
      className={className}
      onClick={onClick}
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M5.70696 5.70717C6.09748 5.31664 6.73064 5.31664 7.12117 5.70717L18.4351 17.0211C18.8256 17.4116 18.8256 18.0447 18.4351 18.4353C18.0445 18.8258 17.4114 18.8258 17.0208 18.4353L5.70696 7.12138C5.31643 6.73086 5.31643 6.09769 5.70696 5.70717Z" />
      <path d="M6.12117 18.7071C5.73064 18.3166 5.73064 17.6834 6.12117 17.2929L17.4351 5.979C17.8256 5.58848 18.4588 5.58848 18.8493 5.979C19.2398 6.36952 19.2398 7.00269 18.8493 7.39321L7.53538 18.7071C7.14486 19.0976 6.51169 19.0976 6.12117 18.7071Z" />
    </svg>
  );
}

export default CrossIconNoCircle;
