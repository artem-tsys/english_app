export { default } from './cross-icon-no-circle';
