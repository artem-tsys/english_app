import React from 'react';

import { creditCardInactiveImageSet, creditCardsImageSet } from './payment-components/images';

export interface CreditCardProps {
  isActive?: boolean;
  className?: string;
}

const CreditCard = ({ isActive = true, className }: CreditCardProps) =>
  isActive ? (
    <img className={className} src={creditCardsImageSet.src} srcSet={creditCardsImageSet.srcSet} />
  ) : (
    <img className={className} src={creditCardInactiveImageSet.src} srcSet={creditCardInactiveImageSet.srcSet} />
  );

export default CreditCard;
