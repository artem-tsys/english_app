import React, { FC, useEffect, useMemo } from 'react';
import { useDispatch } from 'react-redux';

import { useAnimatedWaypoint } from '../../../../hooks/use-animated-waypoint';
import { purchasePageScroll25Action } from '../../../../redux/analytics/analytics.actions';
import { MyFearType } from '../../../../types/my-trauma-purchase';
import calculateMyFear from '../../../../utils/calculate-fear';
import { MyFearCardFooter, MyFearCardHeader, MyFearCardList } from './components';
import classes from './my-fear-card.module.scss';
import { IMyFearCardProps } from './my-fear-card.types';

const MyFearCard: FC<IMyFearCardProps> = ({ riskLevelOfTrauma, traumaIdentifiers }) => {
  const { targetRef, animate } = useAnimatedWaypoint();
  const dispatch = useDispatch();

  const myTypeOfFear = useMemo(() => calculateMyFear(traumaIdentifiers), [traumaIdentifiers]);

  useEffect(() => {
    if (animate) {
      dispatch(purchasePageScroll25Action());
    }
  }, [animate]);

  return (
    <div ref={targetRef} className={classes.root}>
      <div className={classes.headerContainer}>
        <MyFearCardHeader riskLevelOfTrauma={riskLevelOfTrauma} myTypeOfFear={myTypeOfFear} />
      </div>
      <div className={classes.divider} />
      <div className={classes.listContainer}>
        <MyFearCardList myTypeOfFear={myTypeOfFear} />
      </div>
      {myTypeOfFear !== MyFearType.NO_FEAR && <MyFearCardFooter myTypeOfFear={myTypeOfFear} />}
    </div>
  );
};

export default MyFearCard;
