import { TRiskLevelOfTrauma, TTraumaIdentifiers } from '../../../../types/my-trauma-purchase';

export interface IMyFearCardProps {
  riskLevelOfTrauma: TRiskLevelOfTrauma;
  traumaIdentifiers: TTraumaIdentifiers;
}
