export const RISK_LEVEL_VALUES = ['High', 'Medium', 'Mild'];
