import React, { FC } from 'react';

import { MyFearType } from '../../../../../../types/my-trauma-purchase';
import Trans from '../../../../../../utils/next-with-i18n/trans';
import classes from './my-fear-card-footer.module.scss';

interface IMyFearCardFooter {
  myTypeOfFear: MyFearType;
}

const FEARS_DESCRIPTIONS = {
  [MyFearType.REJECTION]: (
    <Trans
      i18nKey="purchase:rejectionDescription"
      defaults="You might have the feeling of <0>{{text}}</0> by people around you, especially your closed ones.<br /><br />People with rejection trauma may isolate themselves in order to be safe or hide their emotions in order not to be rejected."
      components={[<strong key="0" />]}
      values={{ text: 'non-acceptance' }}
    />
  ),
  [MyFearType.BETRAYAL]: (
    <Trans
      i18nKey="purchase:betrayalDescription"
      defaults="People with betrayal trauma often have the feeling of <0>{{text}}</0>. It's difficult for them to trust others.<br /><br />They usually doubt their close relationships thinking that others might not do what is expected.<br /><br />They may tend to control people around them."
      components={[<strong key="0" />]}
      values={{ text: 'anxiety and mistrust' }}
    />
  ),
  [MyFearType.ABANDONMENT]: (
    <Trans
      i18nKey="purchase:abandontmentDescription"
      defaults="People with abandoment trauma tend to be <0>{{text}}</0> or people who sometimes are not healthy choices. <br /><br />They have a hard time accepting that something might end."
      components={[<strong key="0" />]}
      values={{ text: 'emotionally dependent on partners' }}
    />
  ),
  [MyFearType.INJUSTICE]: (
    <Trans
      i18nKey="purchase:injusticeDescription"
      defaults="People with injustice trauma keep <0>{{text}}</0>, and that people will mistreat them. They might isolate themselves in order to feel safe.<br /><br />In their lives, it's possible that they have been mistreated before (bullied, neglected, judged, etc.)"
      components={[<strong key="0" />]}
      values={{ text: 'thinking that the word is unfair and unsafe' }}
    />
  ),
};

const MyFearCardFooter: FC<IMyFearCardFooter> = ({ myTypeOfFear }) => {
  const description = FEARS_DESCRIPTIONS[myTypeOfFear];

  return (
    <div className={classes.root}>
      <p className={classes.text}>{description}</p>
    </div>
  );
};

export default MyFearCardFooter;
