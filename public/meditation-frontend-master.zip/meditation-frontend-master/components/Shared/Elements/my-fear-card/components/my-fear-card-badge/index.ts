export { default } from './my-fear-card-badge';
