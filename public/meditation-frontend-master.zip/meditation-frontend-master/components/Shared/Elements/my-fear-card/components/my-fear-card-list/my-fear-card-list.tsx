import cn from 'classnames';
import React, { FC } from 'react';

import { MyFearType } from '../../../../../../types/my-trauma-purchase';
import Trans from '../../../../../../utils/next-with-i18n/trans';
import { MandalaIcon } from '../../../icons';
import classes from './my-fear-card-list.module.scss';

interface IMyFearCardList {
  myTypeOfFear: MyFearType;
}

const FEARS_LISTS = {
  [MyFearType.REJECTION]: [
    <Trans
      key="0"
      i18nKey="purchase:rejectionListItem1"
      defaults="You might easily make negative assumptions about what others are thinking"
    />,
    <Trans
      key="1"
      i18nKey="purchase:rejectionListItem2"
      defaults="You might compromise more often and more easily than your loved ones do"
    />,
    <Trans
      key="2"
      i18nKey="purchase:rejectionListItem3"
      defaults="You might have a hard time trusting people with your feelings"
    />,
  ],
  [MyFearType.BETRAYAL]: [
    <Trans
      key="0"
      i18nKey="purchase:betrayalListItem1"
      defaults="Trouble recognizing, expressing, or managing emotions"
    />,
    <Trans
      key="1"
      i18nKey="purchase:betrayalListItem2"
      defaults="You might experience physical symptoms (hypervigilance, stomach aches, nightmares, panic attacks)"
    />,
    <Trans
      key="2"
      i18nKey="purchase:betrayalListItem3"
      defaults="You usually are on guard with your closed ones, feeling that they might hurt you"
    />,
  ],
  [MyFearType.ABANDONMENT]: [
    <Trans key="0" i18nKey="purchase:abandonmentListItem1" defaults="Fear of being left behind of abandoned" />,
    <Trans key="1" i18nKey="purchase:abandonmentListItem2" defaults="Low self-esteem and feelings of self-worth" />,
    <Trans key="2" i18nKey="purchase:abandonmentListItem3" defaults="Attaching quickly" />,
    <Trans
      key="3"
      i18nKey="purchase:abandonmentListItem4"
      defaults="Having intense difficulty letting go of a loved one, if/when it does happen"
    />,
  ],
  [MyFearType.INJUSTICE]: [
    <Trans
      key="0"
      i18nKey="purchase:injusticeItem1"
      defaults="You may experience physical symptoms (chronic chest or back pain, fatigue, disorientation)"
    />,
    <Trans key="1" i18nKey="purchase:injusticeItem2" defaults="A strong sense that others may not act fair to you" />,
    <Trans key="2" i18nKey="purchase:injusticeItem3" defaults="Unpredictable and irrational emotions" />,
  ],
  [MyFearType.NO_FEAR]: [
    <Trans
      key="0"
      i18nKey="purchase:noFearItem1"
      defaults="Based on your answers, we've created a plan to work on your problem areas"
    />,
  ],
};

const MyFearCardList: FC<IMyFearCardList> = ({ myTypeOfFear }) => {
  const list = FEARS_LISTS[myTypeOfFear];
  const isOneItemList = list.length === 1;
  return (
    <ul className={classes.root}>
      {list.map((item, i) => (
        <li key={i} className={cn(classes.listItem, { [classes.halfWidthListItem]: !isOneItemList })}>
          <MandalaIcon className={classes.icon} />
          <span className={classes.text}>{item}</span>
        </li>
      ))}
    </ul>
  );
};

export default MyFearCardList;
