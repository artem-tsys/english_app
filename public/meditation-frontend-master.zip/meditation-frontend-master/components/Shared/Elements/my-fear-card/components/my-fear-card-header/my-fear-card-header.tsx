import React, { FC } from 'react';

import { MyFearType, TRiskLevelOfTrauma } from '../../../../../../types/my-trauma-purchase';
import Trans from '../../../../../../utils/next-with-i18n/trans';
import { RISK_LEVEL_VALUES } from '../../my-fear-card.constants';
import MyFearCardBadge from '../my-fear-card-badge';
import classes from './my-fear-card-header.module.scss';

interface IMyFearCardHeader {
  riskLevelOfTrauma: TRiskLevelOfTrauma;
  myTypeOfFear: MyFearType;
}

const MyFearCardHeader: FC<IMyFearCardHeader> = ({ riskLevelOfTrauma, myTypeOfFear }) => {
  const isPropblemIdentified = myTypeOfFear !== MyFearType.NO_FEAR;
  const riskLevelValue = RISK_LEVEL_VALUES[riskLevelOfTrauma];

  return (
    <div className={classes.root}>
      {isPropblemIdentified && (
        <>
          <div className={classes.riskTitle}>
            {/*i18n:extract t('purchase:riskTitle', 'You May Have <0>{{riskLevelValue}}</0> Risk of') */}
            <Trans
              i18nKey="purchase:myFearRiskTitle"
              defaults="You May Have <0>{{riskLevelValue}}</0> Risk of"
              components={[
                <MyFearCardBadge key="0" className={classes[`myFearBadge-${riskLevelValue.toLocaleLowerCase()}`]} />,
              ]}
              values={{ riskLevelValue }}
            />
          </div>
          <MyFearCardBadge className={classes.fearOfBadge}>
            {/*i18n:extract t('purchase:myFearBadge', 'Fear of <0>{{myTypeOfFear}}</0>') */}
            <Trans
              i18nKey="purchase:myFearRiskTitle"
              defaults="Fear of <0>{{myTypeOfFear}}</0>"
              components={[<span key="0" className={classes.fearOfBadgeSpan} />]}
              values={{ myTypeOfFear }}
            />
          </MyFearCardBadge>
          <span className={classes.childhoodTitle}>
            {/*i18n:extract t('purchase:myFearChildhoodTrauma', 'Childhood Trauma') */}
            <Trans i18nKey="purchase:myFearChildhoodTrauma" defaults="Childhood Trauma" />
          </span>
        </>
      )}
      {!isPropblemIdentified && (
        <MyFearCardBadge className={classes.fearOfBadge}>
          {/*i18n:extract t('purchase:myFearNotIdentified', 'We haven\'t identified any type of Childhood Trauma') */}
          <Trans
            i18nKey="purchase:myFearNotIdentified"
            defaults="We haven\'t identified any type of Childhood Trauma"
          />
        </MyFearCardBadge>
      )}
    </div>
  );
};

export default MyFearCardHeader;
