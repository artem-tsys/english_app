import cn from 'classnames';
import React, { FC } from 'react';

import classes from './my-fear-card-badge.module.scss';

interface IMyFearCardBadge {
  className?: string;
}

const MyFearCardBadge: FC<IMyFearCardBadge> = ({ className, children }) => {
  return (
    <span className={cn(classes.root, className)}>
      {children}
      <span className={classes.absoluteBackground} />
      <span className={classes.absoluteBorder} />
    </span>
  );
};

export default MyFearCardBadge;
