import React from 'react';

import classes from './loader.module.scss';

interface Props {
  isShown?: boolean;
  isTransparent?: boolean;
  className?: string;
}

const Loader = ({ isShown, isTransparent = false, className }: Props) => {
  if (!isShown) return null;

  const defaultClassName = isTransparent ? classes.containerTransparent : classes.container;
  const containerClassName = className ? className : defaultClassName;

  return (
    <div className={containerClassName}>
      <div>
        <svg className={classes.spinner} width={50} height={50} viewBox="0 0 42 42" aria-label="loading">
          <g transform="translate(3 3)" strokeWidth={5} fill="none" fillRule="evenodd">
            <circle strokeOpacity={0.5} cx={18} cy={18} r={18} />
            <path d="M22.592 35.404c9.61-2.535 15.348-12.385 12.812-21.996" />
          </g>
        </svg>
      </div>
    </div>
  );
};

export default Loader;
