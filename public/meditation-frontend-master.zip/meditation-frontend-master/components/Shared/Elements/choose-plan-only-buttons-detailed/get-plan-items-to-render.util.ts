import { Plan, PlanId } from '../../../../constants/order.constants';
import { ChoosePlanItem } from './choose-plan-only-buttons-detailed.types';

const ADDITINONAL_DATA_TO_RENDER: Partial<
  Record<PlanId, { oldPricePerDay: number; pricePerDay: number; mostPopular: boolean }>
> = {
  [PlanId.ChildishTraumasMaleOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.ChildishTraumasMaleOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.ChildishTraumasMaleThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.ChildishTraumasMaleOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.ChildishTraumasMaleOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.ChildishTraumasMaleThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },

  [PlanId.ChildishTraumasFemaleOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.ChildishTraumasFemaleOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.ChildishTraumasFemaleThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.ChildishTraumasFemaleOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.ChildishTraumasFemaleOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.ChildishTraumasFemaleThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },
  [PlanId.WeightlossOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.WeightlossOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.WeightlossThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.WeightlossOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.WeightlossOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.WeightlossThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },
  [PlanId.SleepOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.SleepOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.SleepThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.SleepOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.SleepOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.SleepThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },

  [PlanId.NoSmokingOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.NoSmokingOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.NoSmokingThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.NoSmokingOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.NoSmokingOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.NoSmokingThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },

  [PlanId.NoAlcoholOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.NoAlcoholOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.NoAlcoholThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.NoAlcoholOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.NoAlcoholOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.NoAlcoholThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },
  [PlanId.DoesHeLoveOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.DoesHeLoveOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.DoesHeLoveThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.DoesHeLoveOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.DoesHeLoveOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.DoesHeLoveThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },
  [PlanId.FengShuiOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.FengShuiOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.FengShuiThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.FengShuiOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.FengShuiOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.FengShuiThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },
  [PlanId.NoCoffeeOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.NoCoffeeOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.NoCoffeeThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.NoCoffeeOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.NoCoffeeOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.NoCoffeeThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },
  [PlanId.MindForSeniorsOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.MindForSeniorsOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.MindForSeniorsThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.MindForSeniorsOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.MindForSeniorsOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.MindForSeniorsThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },

  [PlanId.Chakras699OneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 200,
  },
  [PlanId.Chakras1999OneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.Chakras2999ThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 71,
  },
  [PlanId.Chakras699OneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 50,
    oldPricePerDay: 200,
  },
  [PlanId.Chakras1999OneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 36,
    oldPricePerDay: 143,
  },
  [PlanId.Chakras2999ThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 18,
    oldPricePerDay: 71,
  },
  [PlanId.DreamsOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.DreamsOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.DreamsThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.DreamsOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.DreamsOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.DreamsThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },
  [PlanId.AstroOneWeek]: {
    mostPopular: false,
    pricePerDay: 100,
    oldPricePerDay: 143,
  },
  [PlanId.AstroOneMonth]: {
    mostPopular: true,
    pricePerDay: 71,
    oldPricePerDay: 102,
  },
  [PlanId.AstroThreeMonth]: {
    mostPopular: false,
    pricePerDay: 36,
    oldPricePerDay: 51,
  },
  [PlanId.AstroOneWeekAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 71,
    oldPricePerDay: 143,
  },
  [PlanId.AstroOneMonthAdditionalDiscount]: {
    mostPopular: true,
    pricePerDay: 54,
    oldPricePerDay: 102,
  },
  [PlanId.AstroThreeMonthAdditionalDiscount]: {
    mostPopular: false,
    pricePerDay: 26,
    oldPricePerDay: 51,
  },

  [PlanId.ChildhoodtraumaOneWeekIntro]: {
    pricePerDay: 100,
    oldPricePerDay: 200,
    mostPopular: false,
  },
  [PlanId.ChildhoodtraumaOneWeekIntroDob]: {
    pricePerDay: 50,
    oldPricePerDay: 200,
    mostPopular: false,
  },
  [PlanId.ChildhoodtraumaOneMonthIntro]: {
    pricePerDay: 71,
    oldPricePerDay: 143,
    mostPopular: true,
  },
  [PlanId.ChildhoodtraumaOneMonthIntroDob]: {
    pricePerDay: 36,
    oldPricePerDay: 143,
    mostPopular: true,
  },
  [PlanId.ChildhoodtraumaThreeMonthsIntro]: {
    pricePerDay: 36,
    oldPricePerDay: 71,
    mostPopular: false,
  },
  [PlanId.ChildhoodtraumaThreeMonthsIntroDob]: {
    pricePerDay: 18,
    oldPricePerDay: 71,
    mostPopular: false,
  },
  [PlanId.ChakrasOneWeekIntro]: {
    pricePerDay: 100,
    oldPricePerDay: 200,
    mostPopular: false,
  },
  [PlanId.ChakrasOneWeekIntroDob]: {
    pricePerDay: 50,
    oldPricePerDay: 200,
    mostPopular: false,
  },
  [PlanId.ChakrasOneMonthIntro]: {
    pricePerDay: 71,
    oldPricePerDay: 143,
    mostPopular: true,
  },
  [PlanId.ChakrasOneMonthIntroDob]: {
    pricePerDay: 36,
    oldPricePerDay: 143,
    mostPopular: true,
  },
  [PlanId.ChakrasThreeMonthsIntro]: {
    pricePerDay: 36,
    oldPricePerDay: 71,
    mostPopular: false,
  },
  [PlanId.ChakrasThreeMonthsIntroDob]: {
    pricePerDay: 18,
    oldPricePerDay: 71,
    mostPopular: false,
  },
  [PlanId.GenericOneWeekIntro]: {
    pricePerDay: 100,
    oldPricePerDay: 200,
    mostPopular: false,
  },
  [PlanId.GenericOneWeekIntroDob]: {
    pricePerDay: 50,
    oldPricePerDay: 200,
    mostPopular: false,
  },
  [PlanId.GenericOneMonthIntro]: {
    pricePerDay: 71,
    oldPricePerDay: 143,
    mostPopular: true,
  },
  [PlanId.GenericOneMonthIntroDob]: {
    pricePerDay: 36,
    oldPricePerDay: 143,
    mostPopular: true,
  },
  [PlanId.GenericThreeMonthsIntro]: {
    pricePerDay: 36,
    oldPricePerDay: 71,
    mostPopular: false,
  },
  [PlanId.GenericThreeMonthsIntroDob]: {
    pricePerDay: 18,
    oldPricePerDay: 71,
    mostPopular: false,
  },
  [PlanId.BChildhoodtraumaOneWeekIntro]: {
    pricePerDay: 39,
    oldPricePerDay: 78,
    mostPopular: false,
  },
  [PlanId.BChildhoodtraumaOneWeekIntroDob]: {
    pricePerDay: 20,
    oldPricePerDay: 78,
    mostPopular: false,
  },
  [PlanId.BChildhoodtraumaOneMonthIntro]: {
    pricePerDay: 29,
    oldPricePerDay: 58,
    mostPopular: true,
  },
  [PlanId.BChildhoodtraumaOneMonthIntroDob]: {
    pricePerDay: 14,
    oldPricePerDay: 58,
    mostPopular: true,
  },
  [PlanId.BChildhoodtraumaThreeMonthsIntro]: {
    pricePerDay: 19,
    oldPricePerDay: 38,
    mostPopular: false,
  },
  [PlanId.BChildhoodtraumaThreeMonthsIntroDob]: {
    pricePerDay: 10,
    oldPricePerDay: 38,
    mostPopular: false,
  },
  [PlanId.CChildhoodtraumaOneWeekIntro]: {
    pricePerDay: 19,
    oldPricePerDay: 38,
    mostPopular: false,
  },
  [PlanId.CChildhoodtraumaOneWeekIntroDob]: {
    pricePerDay: 10,
    oldPricePerDay: 38,
    mostPopular: false,
  },
  [PlanId.CChildhoodtraumaOneMonthIntro]: {
    pricePerDay: 14,
    oldPricePerDay: 28,
    mostPopular: true,
  },
  [PlanId.CChildhoodtraumaOneMonthIntroDob]: {
    pricePerDay: 7,
    oldPricePerDay: 28,
    mostPopular: true,
  },
  [PlanId.CChildhoodtraumaThreeMonthsIntro]: {
    pricePerDay: 11,
    oldPricePerDay: 22,
    mostPopular: false,
  },
  [PlanId.CChildhoodtraumaThreeMonthsIntroDob]: {
    pricePerDay: 6,
    oldPricePerDay: 22,
    mostPopular: false,
  },
  [PlanId.BChakrasOneWeekIntro]: {
    pricePerDay: 39,
    oldPricePerDay: 78,
    mostPopular: false,
  },
  [PlanId.BChakrasOneWeekIntroDob]: {
    pricePerDay: 20,
    oldPricePerDay: 78,
    mostPopular: false,
  },
  [PlanId.BChakrasOneMonthIntro]: {
    pricePerDay: 29,
    oldPricePerDay: 58,
    mostPopular: true,
  },
  [PlanId.BChakrasOneMonthIntroDob]: {
    pricePerDay: 14,
    oldPricePerDay: 58,
    mostPopular: true,
  },
  [PlanId.BChakrasThreeMonthsIntro]: {
    pricePerDay: 19,
    oldPricePerDay: 38,
    mostPopular: false,
  },
  [PlanId.BChakrasThreeMonthsIntroDob]: {
    pricePerDay: 10,
    oldPricePerDay: 38,
    mostPopular: false,
  },
  [PlanId.CChakrasOneWeekIntro]: {
    pricePerDay: 19,
    oldPricePerDay: 38,
    mostPopular: false,
  },
  [PlanId.CChakrasOneWeekIntroDob]: {
    pricePerDay: 10,
    oldPricePerDay: 38,
    mostPopular: false,
  },
  [PlanId.CChakrasOneMonthIntro]: {
    pricePerDay: 14,
    oldPricePerDay: 28,
    mostPopular: true,
  },
  [PlanId.CChakrasOneMonthIntroDob]: {
    pricePerDay: 7,
    oldPricePerDay: 28,
    mostPopular: true,
  },
  [PlanId.CChakrasThreeMonthsIntro]: {
    pricePerDay: 11,
    oldPricePerDay: 22,
    mostPopular: false,
  },
  [PlanId.CChakrasThreeMonthsIntroDob]: {
    pricePerDay: 6,
    oldPricePerDay: 22,
    mostPopular: false,
  },
};

export const getPlanItemsToRender = (plans: Plan[]): ChoosePlanItem[] => {
  return plans.map((plan) => {
    return {
      plan,
      ...ADDITINONAL_DATA_TO_RENDER[plan?.id],
    };
  });
};
