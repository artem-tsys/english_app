import cn from 'classnames';
import React from 'react';
import { useSelector } from 'react-redux';

import { Plan } from '../../../../../constants/order.constants';
import { isDiscountAvailableSelector } from '../../../../../redux/order/order.selectors';
import { formatPrice, getCentsWithoutDollars, getDollars } from '../../../../../utils/format-price.util';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import LabelTriangleLeft from '../../icons/label-triangle-left';
import SelectableCard from '../../selectable-card/selectable-card';
import classes from './plan-item.module.scss';

interface IPlanItemProps {
  plan: Plan;
  isSelected: boolean;
  onSelect: (id: string) => void;
  showMostPopular?: boolean;
  pricePerDay: number;
  oldPricePerDay: number;
}

const currencySymbols = {
  fr: '€',
  de: '€',
  it: '€',
  pt: '€',
  es: '€',
};

const PlanItem: React.FC<IPlanItemProps> = ({
  plan,
  isSelected,
  onSelect,
  showMostPopular,
  pricePerDay,
  oldPricePerDay,
}) => {
  const { t, lang: locale } = useTranslation();
  const isDiscountAvailable = useSelector(isDiscountAvailableSelector);

  const { name, i18nKey, id, introductoryPrice, amount } = plan;

  const priceIncludingDiscount = isDiscountAvailable ? introductoryPrice : amount;

  const pricePerDayParts = {
    dollars: getDollars(pricePerDay),
    cents: getCentsWithoutDollars(pricePerDay),
  };
  const oldPricePerDayParts = {
    dollars: getDollars(oldPricePerDay),
    cents: getCentsWithoutDollars(oldPricePerDay),
  };
  const priceParts = isDiscountAvailable ? pricePerDayParts : oldPricePerDayParts;

  const handleClick = () => {
    onSelect(id);
  };

  return (
    <div
      onClick={handleClick}
      data-plan={plan.id}
      className={cn(classes.plan, { [classes.isSelected]: isSelected, [classes.isMostPopular]: showMostPopular })}
      data-price={introductoryPrice}
      data-selected={isSelected}
    >
      <SelectableCard isSelected={isSelected} className={classes.planCard} selectedClassName={classes.selectedPlanCard}>
        {showMostPopular && (
          <div className={classes.mostPopularLabel}>{t('planItemIntroductory:mostPopularLabel', 'MOST POPULAR')}</div>
        )}
        <div className={classes.mainContentItemContainer}>
          <div className={classes.planMainInfo}>
            <div className={classes.pricingDetails}>
              <div className={classes.pricingDetailsLeft}>
                <div className={classes.planName}>{t(i18nKey, name)}</div>
                <div className={classes.fullPrice}>
                  {isDiscountAvailable && (
                    <span className={classes.fullPriceAmount}>{formatPrice(amount, { locale })}</span>
                  )}
                  {formatPrice(priceIncludingDiscount, { locale })}
                </div>
              </div>
              <div className={classes.pricingDetailsRight}>
                {isDiscountAvailable && (
                  <div className={classes.oldPrice}>{formatPrice(oldPricePerDay, { locale })}</div>
                )}
              </div>
            </div>
          </div>
          <div className={classes.planPerDay}>
            <LabelTriangleLeft className={classes.priceLabel} />
            <div className={classes.price}>
              <span className={classes.currency}>{currencySymbols[locale] || '$'}</span>
              <span className={classes.dollars}>{priceParts.dollars}</span>
              <span className={classes.row}>
                <span className={classes.cents}>{priceParts.cents}</span>
                <span className={classes.period}>{t('planItemIntroductory:perDay', 'per day')}</span>
              </span>
            </div>
          </div>
        </div>
      </SelectableCard>
    </div>
  );
};

export default PlanItem;
