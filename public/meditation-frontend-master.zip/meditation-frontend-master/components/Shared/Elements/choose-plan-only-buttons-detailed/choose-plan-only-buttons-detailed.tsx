import { Button } from '@betterme-dev/web-ui-kit';
import React, { cloneElement, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { PlanId } from '../../../../constants/order.constants';
import { useTranslation } from '../../../../i18n';
import { checkoutPageButtonTextSelector } from '../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { planSelected } from '../../../../redux/order/order.actions';
import { selectedPlanIdSelector } from '../../../../redux/order/order.selectors';
import LegalCheckout from '../legal/legal-checkout';
import SafeCheckoutAdvanced from '../safe-checkout-advanced/safe-checkout-advanced';
import classes from './choose-plan-only-buttons-detailed.module.scss';
import { ChoosePlanItem } from './choose-plan-only-buttons-detailed.types';
import { cardsImageSet } from './images';
import PlanItem from './plan-item/plan-item';

interface IChoosePlanOnlyButtonsDetailedProps {
  plans: ChoosePlanItem[];
  onGetMyPlanClick(): void;
  includePriceBreakdown?: boolean;
  hideTitle?: boolean;
  PaymentButton?: JSX.Element;
}

function DefaultPaymentButton(props) {
  const buttonText = useSelector(checkoutPageButtonTextSelector);

  return <Button label={buttonText} onClick={props.onClick} isPulsing />;
}

const ChoosePlanOnlyButtonsDetailed: React.FC<IChoosePlanOnlyButtonsDetailedProps> = ({
  plans,
  onGetMyPlanClick,
  PaymentButton = <DefaultPaymentButton />,
}: IChoosePlanOnlyButtonsDetailedProps): JSX.Element => {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const selectedPlanId = useSelector(selectedPlanIdSelector);

  const selectPlan = useCallback((id: PlanId) => {
    dispatch(planSelected(id));
  }, []);

  return (
    <div className={classes.plans}>
      <h3 className={classes.choosePlanHeader}>{t('choosePlan:title', 'Choose Your Plan')}</h3>

      <div className={classes.planListContainer}>
        {plans.map((planItem) => {
          return (
            <PlanItem
              key={planItem.plan.id}
              plan={planItem.plan}
              isSelected={selectedPlanId === planItem.plan.id}
              onSelect={selectPlan}
              showMostPopular={planItem.mostPopular}
              pricePerDay={planItem.pricePerDay}
              oldPricePerDay={planItem.oldPricePerDay}
            />
          );
        })}
      </div>

      <div className={classes.buttonContainer}>
        {cloneElement(PaymentButton, { onClick: onGetMyPlanClick, dataButton: 'checkout-get-plan' })}
      </div>

      {selectedPlanId && (
        <div className={classes.legalContainer}>
          <LegalCheckout />
        </div>
      )}
      <SafeCheckoutAdvanced cardsImageSet={cardsImageSet} textClassName={classes.safeCheckoutText} />
    </div>
  );
};

export default ChoosePlanOnlyButtonsDetailed;
