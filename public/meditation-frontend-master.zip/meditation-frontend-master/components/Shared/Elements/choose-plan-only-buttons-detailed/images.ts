import { createCloudinaryImageSetWithLimitedWidth } from '../../../../utils/src-set';

export const cardsImageSet = createCloudinaryImageSetWithLimitedWidth(
  `/public/images/guaranteed-checkout-color_mxwlq3.png`,
  720,
);
