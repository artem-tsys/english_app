import { Plan } from '../../../../constants/order.constants';

export interface ChoosePlanItem {
  plan: Plan;
  mostPopular?: boolean;
  pricePerDay: number;
  oldPricePerDay: number;
}
