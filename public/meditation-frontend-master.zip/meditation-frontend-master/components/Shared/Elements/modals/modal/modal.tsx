import React, { ReactNode, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

import useOutsideClick from '../../../../../hooks/use-outside-click';
import CrossIconNoCircle from '../../icons/cross-icon-no-circle';
import classes from './modal.module.scss';

interface Props {
  isOpen: boolean;
  onClose?: () => void;
  children: ReactNode;
}

const Modal = ({ isOpen, onClose, children }: Props) => {
  const [element, setElement] = useState(null);
  const modalContentRef = useRef(null);
  // If onClose handler is not passed the close button will not be rendered
  // and user will not be able to close popup on outside click
  useOutsideClick(modalContentRef, onClose);

  useEffect(() => {
    if (element && isOpen) {
      const body = document.body;
      const page = document.getElementById('page');
      // Get original body position
      const originalPositionStyle = window.getComputedStyle(body).position;

      // Preventing page scrolling
      // overflow: hidden makes scroll possible on iOS Safari
      // single position: fixed causes the body scroll to reset
      // that's why we use a little bit hacky solution from https://css-tricks.com/prevent-page-scrolling-when-a-modal-is-open/
      body.style.top = `-${window.scrollY}px`;
      body.style.position = 'fixed';
      body.style.left = '0';
      body.style.right = '0';

      // We can't blur any wrapper in which modal is included because in that case modal will be blurred too,
      // so we are blurring content of Page wrapper because it is on the same level in DOM as our modal
      page.style.filter = 'blur(7px)';

      return () => {
        const scrollY = body.style.top;

        // Un-blurring Page wrapper
        page.style.filter = 'none';

        // Re-enable scrolling and scroll to same place
        body.style.position = originalPositionStyle;
        body.style.left = 'auto';
        body.style.right = 'auto';
        body.style.top = 'auto';
        window.scrollTo(0, parseInt(scrollY || '0') * -1);
      };
    }
  }, [element, isOpen]);

  useEffect(() => {
    if (document) {
      // Putting modal in Styles wrapper to be able to use style variables inside modal
      setElement(document.getElementById('main'));
    }
  }, []);

  return element && isOpen
    ? createPortal(
        <div className={classes.container}>
          <div className={classes.content} ref={modalContentRef}>
            <div className={classes.scrollableContent}>{children}</div>

            {onClose && (
              <button className={classes.closeButton} onClick={onClose}>
                <CrossIconNoCircle className={classes.closeIcon} />
              </button>
            )}
          </div>
        </div>,
        element,
      )
    : null;
};

export default Modal;
