import React from 'react';
import { useSelector } from 'react-redux';

import { generatedLandingPageUrlSelector } from '../../../../redux/generated-quiz/generated-quiz.selectors';
import Link from '../../../../utils/next-with-i18n/link';

const HomepageLink: React.FC = ({ children }) => {
  const homePage = useSelector(generatedLandingPageUrlSelector);

  return <Link href={homePage}>{children}</Link>;
};

export default HomepageLink;
