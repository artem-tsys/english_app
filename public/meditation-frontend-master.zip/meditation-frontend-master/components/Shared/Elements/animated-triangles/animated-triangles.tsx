import cn from 'classnames';
import React, { FC, useEffect, useState } from 'react';

import { LeftTriangleArrowIcon } from '../icons';
import classes from './animated-triangles.module.scss';

const TRIANGLES_ARRAY = new Array(4).fill(null);

interface IAnimatedTriangles {
  firstPaintDelay?: number;
}

const AnimatedTriangles: FC<IAnimatedTriangles> = ({ firstPaintDelay = 0 }) => {
  const [isTrianglesVisible, setIsTrianglesVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      setIsTrianglesVisible(true);
    }, firstPaintDelay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={classes.root}>
      {isTrianglesVisible
        ? TRIANGLES_ARRAY.map((_, i) => (
            <LeftTriangleArrowIcon key={i} className={cn(classes.triangle, classes[`triangle-${i}`])} />
          ))
        : null}
    </div>
  );
};

export default AnimatedTriangles;
