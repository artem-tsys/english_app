export { default } from './animated-triangles';
