import cn from 'classnames';
import React from 'react';

import Trans from '../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import { ImageSet } from '../../../../utils/src-set';
import { giftSet } from '../../../Pages/checkout/generated/additional-discount-generated/additional-discount-generated-banner/images';
import classes from './additional-discount-banner-with-big-image.module.scss';

const AdditionalDiscountBannerWithBigImage = ({ imageSet }: { imageSet: ImageSet }) => {
  const { t } = useTranslation();

  return (
    <>
      <div className={classes.container}>
        <div className={classes.topBannerRow}>
          <div className={classes.topBannerColLeft}>
            <div className={classes.topBannerText}>
              <h1 className={classes.topBannerTitle}>
                {/*i18n:extract t('checkoutAdditionalDiscountBanner:smallTitle', 'Previous discount: <0>{{percent}}%</0>') */}
                <small>
                  <Trans
                    i18nKey="checkoutAdditionalDiscountBanner:smallTitle"
                    components={[<strong key="0" />]}
                    values={{ percent: 30 }}
                  />
                </small>
                {/*i18n:extract t('checkoutAdditionalDiscountBanner:title', 'Get your personal plan with up to <0>{{percent}}%</0> discount')*/}
                <Trans
                  i18nKey="checkoutAdditionalDiscountBanner:title"
                  components={[<strong key="0" />]}
                  values={{ percent: 50 }}
                />
              </h1>
            </div>
          </div>
          <div className={cn(classes.topBannerColRight, classes.desktopOnly)}>
            <img
              className={classes.topBannerImg}
              src={imageSet.src}
              srcSet={imageSet.srcSet}
              alt={t('checkoutGenerated:topBanner', 'Top banner')}
            />
          </div>
          <div className={classes.mobileOnly}>
            <img className={classes.topBannerImageSmall} src={giftSet.src} srcSet={giftSet.srcSet} />
          </div>
        </div>
      </div>
    </>
  );
};

export default AdditionalDiscountBannerWithBigImage;
