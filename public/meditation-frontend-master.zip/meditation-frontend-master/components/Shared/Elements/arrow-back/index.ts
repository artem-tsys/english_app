export { default } from './arrow-back';
