import { Image, Placeholder, Transformation } from 'cloudinary-react';
import React from 'react';

interface Props {
  imageName: string;
  className?: string;
  fetchAuto?: boolean;
  onLoad?: () => void;
  pixelate?: boolean;
}

const CloudinaryImage = ({ imageName, className, fetchAuto = true, onLoad, pixelate = true }: Props) => {
  return (
    <Image
      cloudName="drhg6wpcy"
      className={className}
      public-id={imageName}
      secure="true"
      quality="auto:eco"
      dpr="auto"
      responsive={true}
      onLoad={onLoad}
    >
      {fetchAuto && <Transformation fetchFormat="auto" />}
      {pixelate && <Placeholder type="pixelate" />}
    </Image>
  );
};

export default CloudinaryImage;
