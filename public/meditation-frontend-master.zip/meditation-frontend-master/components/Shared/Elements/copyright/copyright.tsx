import LinkWithoutLanguage from 'next/link';
import React from 'react';

import { getLocalizedLegalUrls } from '../../../../utils/lefalLangToClientLang.utils';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import classes from './copyright.module.scss';

function Copyright() {
  const { t, lang } = useTranslation();
  const currYear = new Date().getFullYear();
  const divider = ' | ';

  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <div className={classes.copyright}>
      <span className={classes.copyrightRow}>
        {currYear} © {t('copyright:row', 'All Rights Reserved. By continuing you agree to our')}
      </span>
      <span className={classes.copyrightRow}>
        <LinkWithoutLanguage href="https://bttrm-v3.com/info/terms-eng.html">
          <a>{t('copyright:terms', 'Terms of Service')}</a>
        </LinkWithoutLanguage>
        {divider}
        <LinkWithoutLanguage href="https://bttrm-v3.com/info/privacy-policy-eng.html">
          <a>{t('copyright:privacy', 'Privacy Policy')}</a>
        </LinkWithoutLanguage>
        {divider}
        <LinkWithoutLanguage href={legalUrls.subscriptionPolicyUrl}>
          <a>{t('copyright:subscription', 'Subscription Policy')}</a>
        </LinkWithoutLanguage>
        {divider}
        <LinkWithoutLanguage href={legalUrls.moneyBackPolicyUrl}>
          <a>{t('copyright:moneyBack', 'Money-Back Policy')}</a>
        </LinkWithoutLanguage>
      </span>
    </div>
  );
}

export default Copyright;
