export { default } from './horizontal-divider';
