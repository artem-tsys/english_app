import React from 'react';

import classes from './horizontal-divider.module.scss';

const HorizontalDivider: React.FC = ({ children }) => {
  return (
    <div className={classes.container}>
      <div className={classes.line} />
      {children && <div className={classes.text}>{children}</div>}
      <div className={classes.line} />
    </div>
  );
};

export default HorizontalDivider;
