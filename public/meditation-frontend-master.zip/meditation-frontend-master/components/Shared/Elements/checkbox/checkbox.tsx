import React from 'react';

import classes from './checkbox.module.scss';

interface Props {
  isChecked: boolean;
  className?: string;
  dataCheckbox?: string;
}

const Checkbox = ({ isChecked, className, dataCheckbox = 'general' }: Props) => {
  return (
    <span className={className}>
      <input className={classes.checkbox} readOnly type="checkbox" checked={isChecked} data-checkbox={dataCheckbox} />
      <label />
    </span>
  );
};

export default Checkbox;
