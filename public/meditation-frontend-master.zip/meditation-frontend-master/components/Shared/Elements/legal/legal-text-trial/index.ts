export { default } from './legal-text-trial';
