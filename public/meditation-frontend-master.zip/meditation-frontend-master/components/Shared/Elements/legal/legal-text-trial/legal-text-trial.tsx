import LinkWithoutLanguage from 'next/link';
import React from 'react';
import { useSelector } from 'react-redux';

import { localeConfigs } from '../../../../../constants/locale-configs.constants';
import { selectedPlanSelector } from '../../../../../redux/order/order.selectors';
import { formatPrice } from '../../../../../utils/format-price.util';
import Trans from '../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import BoldTextShortcode from '../../../../../utils/shortcodes/bold-text-shortcode/bold-text-shortcode';
import LinkShortcode from '../../../../../utils/shortcodes/link-shortcode/link-shortcode';
import shortcodeToTags from '../../../../../utils/shortcodes/shortcode-to-tags.util';
import classes from './legal-text-trial.module.scss';

interface LinkProps {
  children?: React.ReactNode;
  href: string;
}

const Link = ({ children, href }: LinkProps) => {
  return (
    <LinkWithoutLanguage href={href}>
      <a className={classes.link}>{children}</a>
    </LinkWithoutLanguage>
  );
};

interface TrialLegalProps {
  text?: string;
}

const LocalLinkShortcode = (props) => <LinkShortcode {...props} className={classes.link} />;
const localShortcodeConfig = [
  {
    Component: LocalLinkShortcode,
    tag: 'link',
    default: true,
  },
  {
    Component: BoldTextShortcode,
    tag: 'b',
    default: false,
  },
];

const LegalTextTrial = ({ text }: TrialLegalProps) => {
  const { lang, t } = useTranslation();
  const selectedPlan = useSelector(selectedPlanSelector);

  const OutputText = () =>
    text ? (
      <span className={classes.text}>{shortcodeToTags(text, localShortcodeConfig)}</span>
    ) : (
      <Trans
        i18nKey="legal:trialText"
        components={[
          <strong key="el:l" />,
          <strong key="1" />,
          <strong key="2">{formatPrice(selectedPlan.discountedPrice, { locale: lang })}</strong>,
          <strong key="3">{t(selectedPlan.planTimeSaleLabelI18nKey, selectedPlan.planTimeSaleLabel)}</strong>,
          <strong key="4" />,
          <strong key="5" />,
          <span key="6" />,
          <Link href="https://bttrm-v3.com/info/terms-eng.html" key="7" />,
          <span key="8">{localeConfigs[lang]?.currency}</span>,
        ]}
      />
    );

  return (
    <>
      {/* i18n:extract t('legal:trialText', `Unless you cancel at least <0>24 hours before</0> the end of the <1>7-day trial</1>,
        you will be automatically charged <2/> for a <3/> subscription.
        Further the <3/> subscription renews automatically at the end of each period until you
        cancel. To avoid being charged cancel your subscription by <5>contacting our support at least 24 hours before</5> the end of then-current period. If you are
        unsure how to cancel, <6>visit our</6> <7>Subscription Terms</7>. You may wish to make a screenshot of this information for your reference.`) */}
      <div className={classes.content}>
        <OutputText />
      </div>
    </>
  );
};

export default LegalTextTrial;
