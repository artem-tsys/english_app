export { default } from './legal-exclusive-offer';
