import React from 'react';

import { formatPrice } from '../../../../../utils/format-price.util';
import Trans from '../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import { PeriodShort, WrappedPeriod } from '../../period/period';
import classes from './legal-exclusive-offer.module.scss';

type TLegalExclusiveOffer = {
  discountedPrice: number;
  days: number;
  buttonText: string;
};

type TLegalTextExclusiveOffer = TLegalExclusiveOffer & { locale: string };

const LegalTextExclusiveOffer: React.FC<TLegalTextExclusiveOffer> = ({ days, discountedPrice, buttonText, locale }) => {
  return (
    <span className={classes.legalText}>
      {/* i18n:extract t('legal:legalTextExclusiveOffer', `By clicking {{buttonText}}, 
      I agree that in addition to my plan subscription, 
      my account will be charged <0>{{amount}}</0> for the add-on I have selected and it will automatically renew each <1/> until I cancel, 
      BetterMe will automatically charge my payment method <0>{{amount}}</0> every <2/>. 
      I can cancel by visiting cancel <3>subscription page</3> in Help section in the mobile app or by contacting support to avoid being charged for the next billing cycle.`) */}
      <Trans
        i18nKey="legal:legalTextExclusiveOffer"
        values={{
          buttonText,
          amount: formatPrice(discountedPrice, { locale }),
        }}
        components={[
          <b key="0" />,
          <PeriodShort days={days} key="1" />,
          <WrappedPeriod days={days} key="2" />,
          <a href={`/${locale}/unsubscribe-web`} target="_blank" rel="noopener noreferrer" key="3" />,
        ]}
      />
    </span>
  );
};

const LegalExclusiveOffer: React.FC<TLegalExclusiveOffer> = ({ buttonText, ...props }) => {
  const { lang } = useTranslation();

  const buttonTextUpperCase = buttonText.toUpperCase();

  return <LegalTextExclusiveOffer buttonText={buttonTextUpperCase} locale={lang} {...props} />;
};

export default LegalExclusiveOffer;
