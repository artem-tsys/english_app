import React from 'react';

import { getLocalizedLegalUrls } from '../../../../../utils/lefalLangToClientLang.utils';
import Trans from '../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import CheckboxIcon from '../../icons/checkbox-icon';
import classes from './legal-checkbox.module.scss';

const LegalCheckbox = () => {
  const { lang } = useTranslation();
  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <div className={classes.legalCheckbox}>
      <CheckboxIcon className={classes.legalCheckboxImage} />
      <p className={classes.legalCheckboxText}>
        {/* i18n:extract t('legalCheckbox:text', 'I agree to the <0>Terms and Conditions</0>, <1>Privacy policy</1>, <2>Subscription policy</2> and the <3>Refund and Cancellation policy</3>') */}
        <Trans
          i18nKey="legalCheckbox:text"
          components={[
            <a href="https://bttrm-v3.com/info/terms-eng.html" target="_blank" rel="noopener noreferrer" key="1" />,
            <a
              href="https://bttrm-v3.com/info/privacy-policy-eng.html"
              target="_blank"
              rel="noopener noreferrer"
              key="2"
            />,
            <a href={legalUrls.subscriptionPolicyUrl} target="_blank" rel="noopener noreferrer" key="3" />,
            <a href={legalUrls.moneyBackPolicyUrl} target="_blank" rel="noopener noreferrer" key="4" />,
          ]}
        />
      </p>
    </div>
  );
};

export default LegalCheckbox;
