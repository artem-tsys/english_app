import React from 'react';
import { useSelector } from 'react-redux';

import { isPlanIntroductory } from '../../../../../business-logic/is-plan-introductory.logic';
import { MONTH_DAYS, WEEK_DAYS } from '../../../../../constants/quiz-options.constants';
import { selectedPlanSelector } from '../../../../../redux/order/order.selectors';
import { formatPrice } from '../../../../../utils/format-price.util';
import { getLocalizedLegalUrls } from '../../../../../utils/lefalLangToClientLang.utils';
import Trans from '../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import { PeriodShort } from '../../period/period';
import classes from './legal-text-introductory-short-us.module.scss';

const LegalTextIntroductory7daysShortUS = ({ introductoryDays, price }) => {
  const { lang } = useTranslation();
  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <span className={classes.text}>
      {/* i18n:extract t('legal:introductory7daysShort', `Unless cancelled online in your profile, you agree that
      after the end of the <0/> introductory plan, it will convert to a monthly auto-renewing subscription at the full
      price and you will be charged <1>{{price}}</1> every month. <2>Subscription Terms</2>`) */}
      <Trans
        i18nKey="legal:introductory7daysShort"
        components={[
          <PeriodShort days={introductoryDays} key="0" />,
          <span key="1" />,
          <a href={legalUrls.subscriptionPolicyUrl} target="_blank" rel="noopener noreferrer" key="2" />,
        ]}
        values={{ price: formatPrice(price, { locale: lang }) }}
      />
    </span>
  );
};

const LegalTextIntroductory1monthShortUS = ({ price }) => {
  const { lang } = useTranslation();
  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <span className={classes.text}>
      {/* i18n:extract t('legal:introductory1monthShort', `To avoid any disruption, you agree that the plan you
      selected will automatically be extended at the full price for successive renewal periods and you will be charged
      <0>{{price}}</0> every month. Cancel online in your profile. <1>Subscription Terms</1>`) */}
      <Trans
        i18nKey="legal:introductory1monthShort"
        components={[
          <span key="0" />,
          <a href={legalUrls.subscriptionPolicyUrl} target="_blank" rel="noopener noreferrer" key="1" />,
        ]}
        values={{ price: formatPrice(price, { locale: lang }) }}
      />
    </span>
  );
};

const LegalTextIntroductory3monthShortUS = ({ introductoryDays, price }) => {
  const { lang } = useTranslation();
  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <span className={classes.text}>
      {/* i18n:extract t('legal:introductory3monthShort', `To avoid any disruption, you agree that the plan you
      selected will automatically be extended at the full price for successive renewal periods and you will be charged
      <0>{{price}}</0> every <1/>. Cancel online in your profile. <2>Subscription Terms</2>`) */}
      <Trans
        i18nKey="legal:introductory3monthShort"
        components={[
          <span key="0" />,
          <PeriodShort days={introductoryDays} key="1" />,
          <a href={legalUrls.subscriptionPolicyUrl} target="_blank" rel="noopener noreferrer" key="2" />,
        ]}
        values={{ price: formatPrice(price, { locale: lang }) }}
      />
    </span>
  );
};

const LegalTextIntroductoryShortUS = () => {
  const selectedPlan = useSelector(selectedPlanSelector);

  if (!isPlanIntroductory(selectedPlan)) return null;

  const { introductoryDays, discountedPrice } = selectedPlan;

  if (introductoryDays <= WEEK_DAYS) {
    return <LegalTextIntroductory7daysShortUS introductoryDays={introductoryDays} price={discountedPrice} />;
  }

  if (introductoryDays <= MONTH_DAYS) {
    return <LegalTextIntroductory1monthShortUS price={discountedPrice} />;
  }

  return <LegalTextIntroductory3monthShortUS introductoryDays={introductoryDays} price={discountedPrice} />;
};

export default LegalTextIntroductoryShortUS;
