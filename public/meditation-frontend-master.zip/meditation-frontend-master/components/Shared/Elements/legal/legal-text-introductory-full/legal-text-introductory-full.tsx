import React from 'react';
import { useSelector } from 'react-redux';

import { isPlanIntroductory } from '../../../../../business-logic/is-plan-introductory.logic';
import { MONTH_DAYS, WEEK_DAYS } from '../../../../../constants/quiz-options.constants';
import { selectedPlanSelector } from '../../../../../redux/order/order.selectors';
import { formatPrice } from '../../../../../utils/format-price.util';
import { getLocalizedLegalUrls } from '../../../../../utils/lefalLangToClientLang.utils';
import Trans from '../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import { PeriodShort } from '../../period/period';

const LegalTextIntroductory7daysFull = ({ introductoryDays, days, price }) => {
  const { lang } = useTranslation();
  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <span>
      {/* i18n:extract t('legal:introductory7daysFull', `<0>PLEASE NOTE:</0> After your <1/> introductory offer,
      unless you cancel online in your profile before the end of then-current period, your plan will automatically
      convert to our <2/> subscription plan at a non-discounted price and you will be charged <0>{{price}}</0> each
      month before you cancel. Subscriptions renew automatically at the end of each period unless you cancel online in
      your profile. If you are unsure how to cancel, visit our <3>Subscription Terms</3>. Prepayment of total plan cost
      required. You will need an Android or iOS mobile phone to access the full version of the product. You may want to
      take a screenshot of this information and save it.`) */}
      <Trans
        i18nKey="legal:introductory7daysFull"
        values={{
          price: formatPrice(price, { locale: lang }),
        }}
        components={[
          <b key="0" />,
          <PeriodShort days={introductoryDays} key="1" />,
          <PeriodShort days={days} key="2" />,
          <a href={legalUrls.subscriptionPolicyUrl} target="_blank" rel="noopener noreferrer" key="3" />,
        ]}
      />
    </span>
  );
};

const LegalTextIntroductory1monthFull = ({ introductoryDays, price }) => {
  const { lang } = useTranslation();
  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <span>
      {/* i18n:extract t('legal:introductory1monthFull', `<0>PLEASE NOTE:</0> After your <1/> introductory offer, unless
      you cancel online before the end of then-current period, your subscription will renew automatically and you will
      be charged <0>{{price}}</0>, the full not discounted price each month before you cancel. Subscriptions renew
      automatically at the end of each period unless you cancel online in your profile. If you are unsure how to cancel,
      visit our <2>Subscription Terms</2>. Prepayment of total plan cost required. You will need an Android or iOS
      mobile phone to access the full version of the product. You may want to take a screenshot of this information and
      save it.`) */}
      <Trans
        i18nKey="legal:introductory1monthFull"
        values={{
          price: formatPrice(price, { locale: lang }),
        }}
        components={[
          <b key="0" />,
          <PeriodShort days={introductoryDays} key="1" />,
          <a href={legalUrls.subscriptionPolicyUrl} target="_blank" rel="noopener noreferrer" key="2" />,
        ]}
      />
    </span>
  );
};

const LegalTextIntroductory3monthFull = ({ introductoryDays, price }) => {
  const { lang } = useTranslation();
  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <span>
      {/* i18n:extract t('legal:introductory3monthFull', `<0>PLEASE NOTE:</0> After your <1/> introductory offer, unless
      you cancel online in your profile before the end of then-current period, your subscription will renew automatically
      and you will be charged <0>{{price}}</0>, the full not discounted price each period before you cancel.
      Subscriptions renew automatically at the end of each period unless you cancel online in your profile. If you are
      unsure how to cancel, visit our <2>Subscription Terms</2>. Prepayment of total plan cost required. You will need
      an Android or iOS mobile phone to access the full version of the product. You may want to take a screenshot of
      this information and save it.`) */}
      <Trans
        i18nKey="legal:introductory3monthFull"
        values={{
          price: formatPrice(price, { locale: lang }),
        }}
        components={[
          <b key="0" />,
          <PeriodShort days={introductoryDays} key="1" />,
          <a href={legalUrls.subscriptionPolicyUrl} target="_blank" rel="noopener noreferrer" key="2" />,
        ]}
      />
    </span>
  );
};

const LegalTextIntroductoryFull = () => {
  const selectedPlan = useSelector(selectedPlanSelector);

  if (!isPlanIntroductory(selectedPlan)) return null;

  const { introductoryDays, discountedPrice, days } = selectedPlan;

  if (introductoryDays <= WEEK_DAYS) {
    return <LegalTextIntroductory7daysFull introductoryDays={introductoryDays} days={days} price={discountedPrice} />;
  }

  if (introductoryDays >= MONTH_DAYS * 3) {
    return <LegalTextIntroductory3monthFull introductoryDays={introductoryDays} price={discountedPrice} />;
  }

  return <LegalTextIntroductory1monthFull introductoryDays={introductoryDays} price={discountedPrice} />;
};

export default LegalTextIntroductoryFull;
