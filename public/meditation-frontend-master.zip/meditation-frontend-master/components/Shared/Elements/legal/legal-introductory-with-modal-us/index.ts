export { default } from './legal-introductory-with-modal-us';
