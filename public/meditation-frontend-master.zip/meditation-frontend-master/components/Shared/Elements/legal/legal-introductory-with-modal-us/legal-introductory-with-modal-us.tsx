import React, { useState } from 'react';

import InfoIcon from '../../icons/info-icon/info-icon';
import Modal from '../../modals/modal/modal';
import LegalTextIntroductoryFull from '../legal-text-introductory-full/legal-text-introductory-full';
import LegalTextIntroductoryShortUS from '../legal-text-introductory-short-us/legal-text-introductory-short-us';
import classes from './legal-introductory-with-modal-us.module.scss';

const LegalIntroductoryWithModalUS: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <div className={classes.legal}>
        <button onClick={() => setIsModalOpen(true)} className={classes.infoButton}>
          <InfoIcon className={classes.infoIcon} />
        </button>
        <LegalTextIntroductoryShortUS />
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <div className={classes.legalFull}>
          <LegalTextIntroductoryFull />
        </div>
      </Modal>
    </>
  );
};

export default LegalIntroductoryWithModalUS;
