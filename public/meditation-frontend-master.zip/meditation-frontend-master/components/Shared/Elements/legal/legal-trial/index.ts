export { default } from './legal-trial';
