import React from 'react';
import { useSelector } from 'react-redux';

import { Plan } from '../../../../../constants/order.constants';
import { checkoutPageButtonTextSelector } from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { selectedPlanSelector } from '../../../../../redux/order/order.selectors';
import { formatPrice } from '../../../../../utils/format-price.util';
import Trans from '../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import { PeriodShort, WrappedPeriod } from '../../period/period';

type TLegalTextTrial = Plan & { buttonText: string; locale: string };

const LegalTextTrial: React.FC<TLegalTextTrial> = ({ days, buttonText, locale, introductoryDays, discountedPrice }) => {
  return (
    <span>
      {/* i18n:extract t('legal:legalTextCheckoutFeelings', `By clicking {{buttonText}}, 
      I agree that if I do not cancel before the end of the <1/> trial period, 
      BetterMe will automatically charge my payment method <0>{{price}}</0> every <2/> thereafter until I cancel. 
      I can cancel by visiting cancel <3>subscription page</3>, in Help section in the mobile app or by contacting support to avoid being charged for the next billing cycle.`) */}
      <Trans
        i18nKey="legal:legalTextCheckoutFeelings"
        values={{
          buttonText,
          price: formatPrice(discountedPrice, { locale }),
        }}
        components={[
          <b key="0" />,
          <PeriodShort days={introductoryDays} key="1" />,
          <WrappedPeriod days={days} key="2" />,
          <a href={`/${locale}/unsubscribe-web`} target="_blank" rel="noopener noreferrer" key="3" />,
        ]}
      />
    </span>
  );
};

const LegalTrial: React.FC = () => {
  const { lang, t } = useTranslation();

  const selectedPlan = useSelector(selectedPlanSelector);

  const checkoutPageButtonText = useSelector(checkoutPageButtonTextSelector);
  const buttonText = checkoutPageButtonText || t('checkout:getPlanBtnUpperCase', 'GET MY PLAN');

  return <LegalTextTrial buttonText={buttonText} locale={lang} {...selectedPlan} />;
};

export default LegalTrial;
