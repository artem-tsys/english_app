import React from 'react';
import { useSelector } from 'react-redux';

import { Plan } from '../../../../../constants/order.constants';
import { checkoutPageButtonTextSelector } from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { isDiscountAvailableSelector, selectedPlanSelector } from '../../../../../redux/order/order.selectors';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import LegalTextLongIntroductoryPeriodDiscounted from './legal-text-variants/legal-text-long-introductory-period-discounted';
import LegalTextLongIntroductoryPeriodNotDiscounted from './legal-text-variants/legal-text-long-introductory-period-not-discounted';
import LegalTextShortIntroductoryPeriod from './legal-text-variants/legal-text-short-introductory-period';

export interface ILegalText extends Plan {
  locale: string;
  buttonText: string;
  isDiscountAvailable?: boolean;
}

const LegalCheckout: React.FC = () => {
  const selectedPlan = useSelector(selectedPlanSelector);
  const isDiscountAvailable = useSelector(isDiscountAvailableSelector);

  const { lang, t } = useTranslation();

  const checkoutPageButtonText = useSelector(checkoutPageButtonTextSelector);
  const buttonText = checkoutPageButtonText || t('checkout:getPlanBtnUpperCase', 'GET MY PLAN');

  const isIntroductoryDaysMoreTheOneWeek = selectedPlan.introductoryDays > 7;

  if (isIntroductoryDaysMoreTheOneWeek) {
    if (isDiscountAvailable) {
      return <LegalTextLongIntroductoryPeriodDiscounted buttonText={buttonText} locale={lang} {...selectedPlan} />;
    }
    return <LegalTextLongIntroductoryPeriodNotDiscounted buttonText={buttonText} locale={lang} {...selectedPlan} />;
  }

  return (
    <LegalTextShortIntroductoryPeriod
      isDiscountAvailable={isDiscountAvailable}
      buttonText={buttonText}
      locale={lang}
      {...selectedPlan}
    />
  );
};

export default LegalCheckout;
