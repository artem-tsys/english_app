import React from 'react';

import { formatPrice } from '../../../../../../utils/format-price.util';
import Trans from '../../../../../../utils/next-with-i18n/trans';
import { PeriodShort, WrappedPeriod } from '../../../period/period';
import { ILegalText } from '../legal-checkout';
import classes from '../legal-checkout.module.scss';

const LegalTextShortIntroductoryPeriod: React.FC<ILegalText> = ({
  introductoryPrice,
  introductoryDays,
  discountedPrice,
  days,
  amount,
  buttonText,
  locale,
  isDiscountAvailable,
}) => {
  const priceIncludingDiscount = isDiscountAvailable ? introductoryPrice : amount;
  return (
    <span className={classes.legalText}>
      {/* i18n:extract t('legal:legalText7daysBeforeAndAfterTimeEnd', `By clicking {{buttonText}}, 
      I agree to pay <0>{{price}}</0> for my plan and that if I do not cancel before the end of the <1/> introductory plan, 
      it will convert to <2/> subscription and BetterMe will automatically charge my payment method the regular price <0>{{amount}}</0> every <3/> thereafter until I cancel. 
      I can cancel by visiting cancel <4>subscription page</4> in Help section in the mobile app or by contacting support to avoid being charged for the next billing cycle.`) */}
      <Trans
        i18nKey="legal:legalText7daysBeforeAndAfterTimeEnd"
        values={{
          buttonText,
          price: formatPrice(priceIncludingDiscount, { locale }),
          amount: formatPrice(discountedPrice, { locale }),
        }}
        components={[
          <b key="0" />,
          <PeriodShort days={introductoryDays} key="1" />,
          <PeriodShort days={days} key="2" />,
          <WrappedPeriod days={days} key="3" />,
          <a href={`/${locale}/unsubscribe-web`} target="_blank" rel="noopener noreferrer" key="4" />,
        ]}
      />
    </span>
  );
};

export default LegalTextShortIntroductoryPeriod;
