export { default } from './legal-checkout';
