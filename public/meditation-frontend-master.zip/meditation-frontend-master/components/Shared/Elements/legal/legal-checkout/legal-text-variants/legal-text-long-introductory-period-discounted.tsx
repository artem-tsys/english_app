import React from 'react';

import { formatPrice } from '../../../../../../utils/format-price.util';
import Trans from '../../../../../../utils/next-with-i18n/trans';
import { PeriodShort, WrappedPeriod } from '../../../period/period';
import { ILegalText } from '../legal-checkout';
import classes from '../legal-checkout.module.scss';

const LegalTextLongIntroductoryPeriodDiscounted: React.FC<ILegalText> = ({
  days,
  introductoryPrice,
  introductoryDays,
  amount,
  buttonText,
  locale,
}) => {
  return (
    <span className={classes.legalText}>
      {/* i18n:extract t('legal:legalTextForMonthBeforeTimeEnd', `By clicking {{buttonText}}, 
      I agree to pay <0>{{price}}</0> for my plan and that if I do not cancel before the end of the <1/> introductory plan, 
      BetterMe will automatically charge my payment method the regular price <0>{{amount}}</0> every <2/> thereafter until I cancel. 
      I can cancel by visiting cancel <3>subscription page</3> in Help section in the mobile app or by contacting support to avoid being charged for the next billing cycle.`) */}
      <Trans
        i18nKey="legal:legalTextForMonthBeforeTimeEnd"
        values={{
          buttonText,
          price: formatPrice(introductoryPrice, { locale }),
          amount: formatPrice(amount, { locale }),
        }}
        components={[
          <b key="0" />,
          <PeriodShort days={introductoryDays} key="1" />,
          <WrappedPeriod days={days} key="2" />,
          <a href={`/${locale}/unsubscribe-web`} target="_blank" rel="noopener noreferrer" key="3" />,
        ]}
      />
    </span>
  );
};

export default LegalTextLongIntroductoryPeriodDiscounted;
