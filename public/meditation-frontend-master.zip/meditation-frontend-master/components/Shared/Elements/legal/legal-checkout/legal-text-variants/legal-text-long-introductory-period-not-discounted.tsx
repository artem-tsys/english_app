import React from 'react';

import { formatPrice } from '../../../../../../utils/format-price.util';
import Trans from '../../../../../../utils/next-with-i18n/trans';
import { WrappedPeriod } from '../../../period/period';
import { ILegalText } from '../legal-checkout';
import classes from '../legal-checkout.module.scss';

const LegalTextLongIntroductoryPeriodNotDiscounted: React.FC<ILegalText> = ({ days, amount, buttonText, locale }) => {
  return (
    <span className={classes.legalText}>
      {/* i18n:extract t('legal:legalTextForMonthAfterTimeEnd', `By clicking {{buttonText}}, 
      I agree that the plan I have selected will automatically renew until I cancel, 
      BetterMe will automatically charge my payment method <0>{{amount}}</0> every <1/>. 
      I can cancel by visiting cancel <2>subscription page</2> in Help section in the mobile app or by contacting support to avoid being charged for the next billing cycle.`) */}
      <Trans
        i18nKey="legal:legalTextForMonthAfterTimeEnd"
        values={{
          buttonText,
          amount: formatPrice(amount, { locale }),
        }}
        components={[
          <b key="0" />,
          <WrappedPeriod days={days} key="1" />,
          <a href={`/${locale}/unsubscribe-web`} target="_blank" rel="noopener noreferrer" key="2" />,
        ]}
      />
    </span>
  );
};

export default LegalTextLongIntroductoryPeriodNotDiscounted;
