import { MyAgeCategory, MyFearType } from '../../../../types/my-trauma-purchase';
import { AimIcon, GoalIcon, ShineIcon } from '../icons';

export const AFTER_SENIOR_WOMAN_CLOUDINARY_IMG_ID = 'bl68oxeozdiktf3k4orp';
export const AFTER_YOUNG_WOMAN_CLOUDINARY_IMG_ID = 'y4cdxvciqy4a3fu7rixd';

export const AGE_IMAGE = {
  [MyAgeCategory.YOUNG]: AFTER_YOUNG_WOMAN_CLOUDINARY_IMG_ID,
  [MyAgeCategory.SENIOR]: AFTER_SENIOR_WOMAN_CLOUDINARY_IMG_ID,
};

export const HIGHLIT_ITEMS_LIST = [
  {
    key: 'goal',
    title: 'Goal',
    IconComponent: GoalIcon,
  },
  {
    key: 'focus',
    title: 'Focused on healing',
    IconComponent: ShineIcon,
  },
  {
    key: 'areaToImprove',
    title: 'Main area to improve',
    IconComponent: AimIcon,
  },
];

export const FOCUS_HIGHLIGHT_LISTS = {
  [MyFearType.ABANDONMENT]: ['Loneliness', 'Worry and self-doubt'],
  [MyFearType.BETRAYAL]: ['Trust issues', 'Fear to end up alone', 'Obsessive thoughts'],
  [MyFearType.INJUSTICE]: ['Unpredictable emotions', 'Mistrust'],
  [MyFearType.REJECTION]: ['Pulling away from others', 'Feeling of being undesirable', 'Negative self-talk'],
  [MyFearType.NO_FEAR]: ['Overthinking', 'Loneliness', 'Negative self-talk'],
};
