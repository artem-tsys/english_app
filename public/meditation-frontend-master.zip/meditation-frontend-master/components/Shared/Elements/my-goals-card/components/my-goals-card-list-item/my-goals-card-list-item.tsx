import React, { FC } from 'react';

import { TriangleToRightIcon } from '../../../icons';
import { IMyGoalsCardListItemProps } from '../../my-goals-card.types';
import classes from './my-goals-card-list-item.module.scss';

const MyGoalsCardListItem: FC<IMyGoalsCardListItemProps> = ({ title, items, IconComponent }) => (
  <div className={classes.root}>
    <div className={classes.iconRow}>
      <IconComponent className={classes.icon} />
      <div className={classes.content}>
        <span className={classes.title}>{title}</span>
        <ul className={classes.list}>
          {items.map((item) => (
            <li key={item} className={classes.listItem}>
              <TriangleToRightIcon className={classes.listIcon} />
              {item}
            </li>
          ))}
        </ul>
      </div>
    </div>
  </div>
);

export default MyGoalsCardListItem;
