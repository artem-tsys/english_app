export { default } from './my-goals-card-footer';
