import React, { FC } from 'react';

import Trans from '../../../../../../utils/next-with-i18n/trans';
import classes from './my-goals-card-footer.module.scss';

const MyGoalsCardFooter: FC = () => {
  return (
    <div className={classes.root}>
      <p className={classes.text}>
        <Trans
          i18nKey="purchase:myGoalsCardFooterText"
          defaults="Customized according to your <0>{{text}}</0>"
          components={[<strong key="0" />]}
          values={{ text: 'Goals and main areas to improve' }}
        />
      </p>
    </div>
  );
};

export default MyGoalsCardFooter;
