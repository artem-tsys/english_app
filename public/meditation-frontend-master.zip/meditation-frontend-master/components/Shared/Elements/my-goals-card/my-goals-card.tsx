import React, { FC, useEffect, useMemo, useRef } from 'react';
import { useDispatch } from 'react-redux';

import { AnimatedTriangles } from '../';
import { useAnimatedWaypoint } from '../../../../hooks/use-animated-waypoint';
import { purchasePageScroll75Action } from '../../../../redux/analytics/analytics.actions';
import calculateMyFear from '../../../../utils/calculate-fear';
import createCloudinaryImageSet from '../../../../utils/src-set';
import { MyGoalsCardFooter, MyGoalsCardListItem } from './components';
import { AGE_IMAGE, FOCUS_HIGHLIGHT_LISTS, HIGHLIT_ITEMS_LIST } from './my-goals-card.constants';
import classes from './my-goals-card.module.scss';
import { IMyGoalsCardProps } from './my-goals-card.types';

const MyGoalsCard: FC<IMyGoalsCardProps> = ({ ageCategory, traumaIdentifiers, goal, areaToImprove }) => {
  const { targetRef, animate } = useAnimatedWaypoint();
  const ageImageRef = useRef<HTMLImageElement>();
  const dispatch = useDispatch();

  const ageImageSet = useMemo(() => createCloudinaryImageSet(AGE_IMAGE[ageCategory]), [ageCategory]);
  // TODO: move to shared (MyGoalsCard, MyFearCard)
  const myTypeOfFear = useMemo(() => calculateMyFear(traumaIdentifiers), [traumaIdentifiers]);

  const listsOfStrings = {
    goal,
    areaToImprove,
    focus: FOCUS_HIGHLIGHT_LISTS[myTypeOfFear],
  };

  useEffect(() => {
    if (animate && ageImageRef.current) {
      ageImageRef.current.classList.add(classes.ageImageAnimate);
      dispatch(purchasePageScroll75Action());
    }
  }, [animate]);

  return (
    <div ref={targetRef} className={classes.root}>
      <div className={classes.content}>
        <div className={classes.list}>
          {HIGHLIT_ITEMS_LIST.map((item) => (
            <MyGoalsCardListItem
              key={item.key}
              items={listsOfStrings[item.key]}
              title={item.title}
              IconComponent={item.IconComponent}
            />
          ))}
        </div>
      </div>
      <MyGoalsCardFooter />
      <img className={classes.ageImage} ref={ageImageRef} src={ageImageSet.src} srcSet={ageImageSet.srcSet} alt="" />
      {animate && (
        <div className={classes.animatedTriangles}>
          <AnimatedTriangles firstPaintDelay={2000} />
        </div>
      )}
    </div>
  );
};

export default MyGoalsCard;
