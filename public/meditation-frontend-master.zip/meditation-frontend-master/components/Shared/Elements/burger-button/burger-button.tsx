import React from 'react';

import classes from './burger-button.module.scss';

interface Props {
  onClick: () => void;
  color?: string;
}

const BurgerButton = ({ onClick, color }: Props) => {
  const dashStyle = { backgroundColor: color ? color : 'var(--neutral500Color)' };

  return (
    <button className={classes.container} onClick={onClick} data-button="burger-menu">
      <span className={classes.dash} style={dashStyle} />
      <span className={classes.dash} style={dashStyle} />
      <span className={classes.dash} style={dashStyle} />
    </button>
  );
};

export default BurgerButton;
