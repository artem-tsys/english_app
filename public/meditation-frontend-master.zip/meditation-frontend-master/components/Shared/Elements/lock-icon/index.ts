export { default } from './lock-icon';
