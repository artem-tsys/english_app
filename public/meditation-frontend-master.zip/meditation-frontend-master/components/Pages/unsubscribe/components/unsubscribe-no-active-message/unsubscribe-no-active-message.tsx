import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import { errorYouDontHaveActiveSubscriptionsAction } from '../../../../../redux/analytics/analytics.actions';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import { womanSet } from '../../images';
import classes from '../../unsubscribe.module.scss';

const UnsubscribeNoActive = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  useEffect(() => {
    try {
      window.scrollTo(0, 0);
    } catch (e) {}
  }, []);

  useEffect(() => {
    dispatch(errorYouDontHaveActiveSubscriptionsAction());
  }, []);

  return (
    <div className={classes.messageContainer}>
      <div className={classes.imageCircle}>
        <img className={classes.image} src={womanSet.src} srcSet={womanSet.srcSet} />
      </div>
      <h1 className={classes.messageHeader}>{t('unsubscribe:oops', 'Oops!')}</h1>
      <p className={classes.textParagraph}>
        You don't have an active <br /> auto-renewing subscription
      </p>
    </div>
  );
};

export default UnsubscribeNoActive;
