import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import { errorSomethingWentWrongAction } from '../../../../../redux/analytics/analytics.actions';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import Button from '../../../../Shared/Elements/button/button';
import { errorSignSet } from '../../images';
import classes from '../../unsubscribe.module.scss';

interface Props {
  onRetry: () => void;
}

const UnsusbscribeErrorMessage = ({ onRetry }: Props) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(errorSomethingWentWrongAction());
  }, []);

  return (
    <div className={classes.messageContainer}>
      <div className={classes.imageCircle}>
        <img className={classes.image} src={errorSignSet.src} srcSet={errorSignSet.srcSet} />
      </div>
      <h1 className={classes.messageHeader}>{t('unsubscribe:oops', 'Oops!')}</h1>
      <p className={classes.textParagraph}>
        Something went wrong on our end. <br />
        Please try again
      </p>
      <Button className={classes.retryButton} onClick={onRetry}>
        {t('unsubscribe:tryAgainButton', 'Try again')}
      </Button>
    </div>
  );
};

export default UnsusbscribeErrorMessage;
