import React, { useEffect } from 'react';

import { notifyOnError } from '../../../../../utils/error-tracking';
import Header from '../../../../Generic/page/header/header';
import EmailLogin from './email-login';
import classes from './login.module.scss';

const Login = () => {
  useEffect(() => {
    try {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth',
      });
    } catch (e) {
      notifyOnError('[Login] No scrollTo method on window object');
    }
  }, []);

  return (
    <>
      <Header className={classes.header} />
      <div className={classes.loginPage}>
        <main className={classes.container}>
          <article>
            <div className={classes.header}>Log in</div>
            <EmailLogin />
          </article>
        </main>
      </div>
    </>
  );
};

export default Login;
