import cn from 'classnames';
import React, { useContext, useState } from 'react';
import { useSelector } from 'react-redux';

import { loginUserWithEmail } from '../../../../../api/user.api';
import { isSignupInProgressSelector } from '../../../../../redux/signup/signup.selectors';
import { generateGDPRValuesAndSetToLS } from '../../../../../redux/signup/signup.utils';
import uClasses from '../../../../../styles/utilities.module.scss';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import ErrorNotify from '../../../../Generic/error-notify';
import { loginContext } from '../../../../Generic/login-guard/login-guard';
import Loader from '../../../../Shared/Elements/loader/loader';
import { I18N_KEY_TO_VALUE, validateEmail, validatePassword } from './login-validate';
import classes from './login.module.scss';

const isFormValid = (errors) => {
  return Object.keys(errors).filter((fieldName) => !!errors[fieldName]).length === 0;
};

const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

const EmailLogin = () => {
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { setIsLoggedIn } = useContext(loginContext);
  const isSignupInProgress = useSelector(isSignupInProgressSelector);

  const requestEmailLogin = async () => {
    const GDPRvalues = generateGDPRValuesAndSetToLS();
    const { uuid, agreementTime } = GDPRvalues;
    try {
      setIsLoading(true);
      setError(null);
      await loginUserWithEmail({
        timeZone,
        email,
        password,
        uuid,
        agreementTime,
      });
      setIsLoggedIn(true);
    } catch (e) {
      setError(`Email and password combination not found.`);
    }
    setIsLoading(false);
  };

  const [validationErrors, setValidationErrors] = useState({
    emailError: null,
    passwordError: null,
  });

  function validateAndSetErrors({ email, password }) {
    const emailError = validateEmail(email);
    const passwordError = validatePassword(password);
    const errors = { emailError, passwordError };

    setValidationErrors(errors);

    return errors;
  }

  const onEmailChange = (e) => {
    setValidationErrors({ ...validationErrors, emailError: null });
    setEmail(e.target.value);
  };

  const onPasswordChange = (e) => {
    setValidationErrors({ ...validationErrors, passwordError: null });
    setPassword(e.target.value);
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const errors = validateAndSetErrors({ email, password });

    if (isFormValid(errors)) {
      requestEmailLogin();
    }
  };

  const { t } = useTranslation();

  const { emailError, passwordError } = validationErrors;

  const isBtnDisabled = isSignupInProgress || emailError || passwordError || !email || !password;

  return (
    <>
      <Loader isShown={isLoading} />
      <form onSubmit={onSubmit} className={classes.form}>
        <p className={classes.instruction}>
          Use your e-mail
          <br /> and password to log in
        </p>
        <div className={classes.inputRow}>
          <input
            className={cn(uClasses.uInput, { [uClasses.isInvalid]: !!emailError })}
            value={email}
            type="email"
            name="email"
            onChange={onEmailChange}
            placeholder={t('signUp:enterEmailV2', 'Enter your email')}
            data-input="email-login-email"
          />
          {emailError && <div className={classes.error}>{t(emailError, I18N_KEY_TO_VALUE[emailError])}</div>}
        </div>
        <div className={classes.inputRow}>
          <input
            className={cn(uClasses.uInput, { [uClasses.isInvalid]: !!passwordError })}
            value={password}
            onChange={onPasswordChange}
            type="password"
            placeholder={t('signUp:enterPassword', 'Password')}
            data-input="email-login-password"
          />
          {passwordError && <div className={classes.error}>{t(passwordError, I18N_KEY_TO_VALUE[passwordError])}</div>}
        </div>

        <div className={classes.btn}>
          <button
            className={uClasses.uGreenWideButton}
            type="submit"
            disabled={isBtnDisabled}
            data-button="email-signup-submit"
          >
            Log in
          </button>

          {error && (
            <div className={classes.errorNotifyContainer}>
              <ErrorNotify>
                <span>{error}</span>
              </ErrorNotify>
            </div>
          )}
        </div>
      </form>
    </>
  );
};

export default EmailLogin;
