export const I18N_KEY_TO_VALUE = {
  // i18n:extract t('signUpValidate:empty', `This field shouldn't be empty`)
  'signUpValidate:empty': `This field shouldn't be empty`,
};

export const validateEmail = (email) => {
  return !!email ? null : 'signUpValidate:empty';
};

export const validatePassword = (password) => {
  return !!password ? null : 'signUpValidate:empty';
};
