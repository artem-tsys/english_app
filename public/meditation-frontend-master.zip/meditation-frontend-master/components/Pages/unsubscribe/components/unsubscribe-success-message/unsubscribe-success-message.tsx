import Link from 'next/link';
import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import { successUnsubscribePageAction } from '../../../../../redux/analytics/analytics.actions';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import Button from '../../../../Shared/Elements/button/button';
import { sadFaceSet } from '../../images';
import classes from '../../unsubscribe.module.scss';

const UnsusbscribeSuccessMessage = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(successUnsubscribePageAction());
  }, []);

  return (
    <div className={classes.messageContainer}>
      <div className={classes.imageCircle}>
        <img
          className={classes.image}
          src={sadFaceSet.src}
          srcSet={sadFaceSet.srcSet}
          alt={t('unsubscribe:sadFace', 'Sad face')}
        />
      </div>
      <h1 className={classes.messageHeader}>
        {t('unsubscribe:weHaveCanceledSubs', 'We’ve canceled your subscription')}
      </h1>
      <p className={classes.textParagraph}>
        {t('unsubscribe:noFutureCharge', 'You will not be charged in the future.')}
        <br />
        <br />
        {t('unsubscribe:subsNoDate', 'You can still access all of Meditations until your current subscription ends')}
      </p>
      <Link href="/">
        <Button>{t('unsubscribe:gotItButton', 'Got it')}</Button>
      </Link>
    </div>
  );
};

export default UnsusbscribeSuccessMessage;
