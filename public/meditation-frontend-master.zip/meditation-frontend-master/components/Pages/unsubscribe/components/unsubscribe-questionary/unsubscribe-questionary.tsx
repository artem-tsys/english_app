import cn from 'classnames';
import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import { questionarePageAction } from '../../../../../redux/analytics/analytics.actions';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import Checkbox from '../../../../Shared/Elements/checkbox/checkbox';
import Loader from '../../../../Shared/Elements/loader/loader';
import SelectableCard from '../../../../Shared/Elements/selectable-card/selectable-card';
import classes from '../../unsubscribe.module.scss';

const OPTIONS = [
  {
    id: 'deeperPractice',
    // i18n:extract t('unsubscribe:deeperPractice', 'I want deeper practice')
    i18nKey: 'unsubscribe:deeperPractice',
    i18nDefaultValue: 'I want deeper practice',
  },
  {
    id: 'notWhatExpected',
    // i18n:extract t('unsubscribe:notWhatExpected', 'Meditations are not what I expected')
    i18nKey: 'unsubscribe:notWhatExpected',
    i18nDefaultValue: 'Meditations are not what I expected',
  },
  {
    id: 'noVariety',
    // i18n:extract t('unsubscribe:noVariety', 'Not enough variety')
    i18nKey: 'unsubscribe:noVariety',
    i18nDefaultValue: 'Not enough variety',
  },
  {
    id: 'differentApp',
    // i18n:extract t('unsubscribe:differentApp', 'I found a different app')
    i18nKey: 'unsubscribe:differentApp',
    i18nDefaultValue: 'I found a different app',
  },
  {
    id: 'personalization',
    // i18n:extract t('unsubscribe:personalization', 'I want personalized guidance')
    i18nKey: 'unsubscribe:personalization',
    i18nDefaultValue: 'I want personalized guidance',
  },
  {
    id: 'expensive',
    // i18n:extract t('unsubscribe:expensive', 'Too expensive')
    i18nKey: 'unsubscribe:expensive',
    i18nDefaultValue: 'Too expensive',
  },
  {
    id: 'notUse',
    // i18n:extract t('unsubscribe:notUse', 'I don’t use Meditations enough')
    i18nKey: 'unsubscribe:notUse',
    i18nDefaultValue: 'I don’t use Meditations enough',
  },
];

interface Props {
  isLoading: boolean;
  selectedOption: string;
  onSelect: (optionId: string) => void;
}

const UnsubscribeQuestionary = ({ isLoading, selectedOption, onSelect }: Props) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  useEffect(() => {
    try {
      window.scrollTo(0, 0);
    } catch (e) {}
  }, []);

  useEffect(() => {
    dispatch(questionarePageAction());
  }, []);

  const onCardClick = (e) => {
    const optionId = e.currentTarget.dataset.cardId;
    onSelect(optionId);
  };

  return (
    <>
      <Loader isShown={isLoading} />

      <h1 className={classes.questionaryHeader}>
        {t('unsubscribe:questionTitle', 'We’re sad to see you go! What made you decide to cancel your subscription?')}
      </h1>
      <div>
        {OPTIONS.map(({ id, i18nKey, i18nDefaultValue }) => {
          const isSelected = selectedOption === id;

          return (
            <SelectableCard
              key={id}
              className={cn(classes.answerCard, { [classes.answerCardSelected]: isSelected })}
              isSelected={isSelected}
              dataCardId={id}
              onClick={onCardClick}
            >
              {t(i18nKey, i18nDefaultValue)}
              <Checkbox
                isChecked={isSelected}
                className={cn(classes.checkbox, { [classes.isTransparent]: !isSelected })}
              />
            </SelectableCard>
          );
        })}
      </div>
    </>
  );
};

export default UnsubscribeQuestionary;
