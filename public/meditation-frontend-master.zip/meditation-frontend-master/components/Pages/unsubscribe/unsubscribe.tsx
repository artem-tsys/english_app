import React, { useContext, useEffect, useRef, useState } from 'react';
import { useDispatch } from 'react-redux';

import { unsubscribeUser } from '../../../api/user.api';
import {
  errorSomethingWentWrongAction,
  errorYouDontHaveActiveSubscriptionsAction,
  questionarePageAction,
  successUnsubscribePageAction,
  unsubscribeReasonPageAction,
} from '../../../redux/analytics/analytics.actions';
import { RequestState } from '../../../types/request-state';
import { getCookieSafe, setCookieSafe } from '../../../utils/cookie';
import { loginContext } from '../../Generic/login-guard/login-guard';
import Header from '../../Generic/page/header/header';
import UnsusbscribeErrorMessage from './components/unsubscribe-error-message';
import UnsubscribeNoActive from './components/unsubscribe-no-active-message';
import UnsubscribeQuestionary from './components/unsubscribe-questionary';
import UnsusbscribeSuccessMessage from './components/unsubscribe-success-message';
import classes from './unsubscribe.module.scss';

const ACTIONS_BY_STATUS: Record<RequestState, () => void> = {
  [RequestState.Idle]: questionarePageAction,
  [RequestState.Loading]: unsubscribeReasonPageAction,
  [RequestState.Error]: errorSomethingWentWrongAction,
  [RequestState.Success]: successUnsubscribePageAction,
};

const checkIsHasActiveSubscription = () => {
  return getCookieSafe('hasActiveSubscription') === 'true' ? true : false;
};

const useAnalytics = (hasActiveSubscription, requestState) => {
  const dispatch = useDispatch();

  useEffect(() => {
    if (hasActiveSubscription) {
      dispatch(ACTIONS_BY_STATUS[requestState]());
    }
  }, [requestState, hasActiveSubscription, dispatch]);

  useEffect(() => {
    if (!hasActiveSubscription) {
      dispatch(errorYouDontHaveActiveSubscriptionsAction());
    }
  }, [hasActiveSubscription]);
};

const Unsubscribe = () => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [requestState, setRequestState] = useState(RequestState.Idle);
  const timeout = useRef(null);
  const { setIsLoggedIn } = useContext(loginContext);

  const unsubscribe = async (unsubscribeReason) => {
    try {
      setRequestState(RequestState.Loading);
      await unsubscribeUser({
        reason: unsubscribeReason,
      });

      setRequestState(RequestState.Success);
      setCookieSafe('hasActiveSubscription', 'false', 1);
    } catch (e) {
      if (e?.response?.status === 403) {
        setIsLoggedIn(false);
      }
      setRequestState(RequestState.Error);
    }
  };

  const onSelectOption = (optionId: string) => {
    clearTimeout(timeout.current);
    setSelectedOption(optionId);
    timeout.current = setTimeout(() => {
      unsubscribe(optionId);
    }, 800);
  };

  const onRetry = () => {
    unsubscribe(selectedOption);
  };

  const isLoading = requestState === RequestState.Loading;
  const isSuccess = requestState === RequestState.Success;
  const isIdle = requestState === RequestState.Idle;
  const isError = requestState === RequestState.Error;

  const hasActiveSubscription = checkIsHasActiveSubscription();

  useAnalytics(hasActiveSubscription, requestState);

  if (!checkIsHasActiveSubscription()) {
    return (
      <div className={classes.cardContainer}>
        <Header className={classes.header} />
        <main className={classes.cardNoBackground}>
          <UnsubscribeNoActive />
        </main>
      </div>
    );
  }

  if (isError) {
    return (
      <div className={classes.cardContainer}>
        <Header className={classes.header} />
        <main className={classes.cardNoBackground}>
          <UnsusbscribeErrorMessage onRetry={onRetry} />
        </main>
      </div>
    );
  }

  return (
    <div className={classes.cardContainer}>
      <Header className={classes.header} />
      <main className={classes.card}>
        {(isIdle || isLoading) && (
          <UnsubscribeQuestionary selectedOption={selectedOption} isLoading={isLoading} onSelect={onSelectOption} />
        )}
        {isSuccess && <UnsusbscribeSuccessMessage />}
      </main>
    </div>
  );
};

export default Unsubscribe;
