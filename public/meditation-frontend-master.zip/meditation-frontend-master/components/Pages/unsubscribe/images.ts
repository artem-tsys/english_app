import createCloudinaryImageSet from '../../../utils/src-set';

export const sadFaceSet = createCloudinaryImageSet('emojis/Bad_news_y30l3q');

export const errorSignSet = createCloudinaryImageSet('emojis/u274C_1_cyizyi');

export const womanSet = createCloudinaryImageSet('u274C_1_wmlug3');
