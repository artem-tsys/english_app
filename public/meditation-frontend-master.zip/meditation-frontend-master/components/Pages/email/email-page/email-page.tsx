import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { requestUpdateEmail } from '../../../../redux/order/order.actions';
import {
  isEEACountrySelector,
  isPaymentEmailUpdatingSelector,
  orderCountrySelector,
  updatePaymentEmailErrorSelector,
} from '../../../../redux/order/order.selectors';
import Loader from '../../../Shared/Elements/loader/loader';
import EmailConsent from '../email-consent/email-consent';
import EmailForm from '../email-form/email-form';
import classes from './email-page.module.scss';

enum Routes {
  EmailPage,
  ConsentPage,
}

const EmailPage = () => {
  const dispatch = useDispatch();

  const isPaymentEmailUpdating = useSelector(isPaymentEmailUpdatingSelector);

  const paymentEmailError = useSelector(updatePaymentEmailErrorSelector);
  const isEEACountry = useSelector(isEEACountrySelector);
  const country = useSelector(orderCountrySelector);
  // show Email Consent screen for EEA countries. For other countries mark consent as agreed and submit email
  const shouldShowConsentPage = (isEEACountry || !country) && !paymentEmailError;

  const showLoader = isPaymentEmailUpdating;

  const [currentRoute, setCurrentRoute] = useState<Routes>(Routes.EmailPage);

  let currentRouteJSX: React.ReactElement = null;
  switch (currentRoute) {
    case Routes.ConsentPage: {
      currentRouteJSX = <EmailConsent />;
      break;
    }
    case Routes.EmailPage:
    default: {
      currentRouteJSX = (
        <EmailForm
          onSubmit={() => {
            if (shouldShowConsentPage) {
              setCurrentRoute(Routes.ConsentPage);
            } else {
              dispatch(requestUpdateEmail());
            }
          }}
        />
      );
      break;
    }
  }

  useEffect(() => {
    // if there's some errors while updating email, redirect user back to email form so user could fix possible typo in theirs email
    if (paymentEmailError) {
      setCurrentRoute(Routes.EmailPage);
    }
  }, [paymentEmailError]);

  return (
    <>
      <main className={classes.container}>{currentRouteJSX}</main>
      <Loader isShown={showLoader} isTransparent />
    </>
  );
};

export default EmailPage;
