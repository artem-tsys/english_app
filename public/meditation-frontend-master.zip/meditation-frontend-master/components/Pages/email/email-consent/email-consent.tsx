import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { emailConsentAction } from '../../../../redux/analytics/analytics.actions';
import {
  emailPageConsentAgreeButtonTextSelector,
  emailPageConsentNotAgreeButtonTextSelector,
  emailPageConsentTextSelector,
} from '../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { requestUpdateEmail, setEmailConsent } from '../../../../redux/order/order.actions';
import { shortcodesConfig } from '../../../../utils/shortcodes';
import shortcodeToTags from '../../../../utils/shortcodes/shortcode-to-tags.util';
import Button from '../../../Shared/Elements/button/button';
import classes from './email-consent.module.scss';

const EmailConsent = () => {
  const dispatch = useDispatch();

  const emailPageConsentText = useSelector(emailPageConsentTextSelector);
  const emailPageConsentAgreeButtonText = useSelector(emailPageConsentAgreeButtonTextSelector);
  const emailPageConsentNotAgreeButtonText = useSelector(emailPageConsentNotAgreeButtonTextSelector);

  useEffect(() => {
    dispatch(emailConsentAction());
  }, []);

  const handleAnswerClicked = (e, consent) => {
    e.preventDefault();
    dispatch(setEmailConsent(consent));
    dispatch(requestUpdateEmail());
  };

  return (
    <form onSubmit={(e) => handleAnswerClicked(e, true)} className={classes.form}>
      <div className={classes.title} key="0">
        {shortcodeToTags(emailPageConsentText, shortcodesConfig)}
      </div>
      <div>
        <Button type="submit" fullWidth dataButton="email-form-submit">
          {shortcodeToTags(emailPageConsentAgreeButtonText, shortcodesConfig)}
        </Button>
        <button
          className={classes.textButton}
          onClick={(e) => handleAnswerClicked(e, false)}
          data-button="email-form-submit"
        >
          {shortcodeToTags(emailPageConsentNotAgreeButtonText, shortcodesConfig)}
        </button>
      </div>
    </form>
  );
};

export default EmailConsent;
