import cn from 'classnames';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import reactStringReplace from 'react-string-replace';

import { emailInputAction } from '../../../../redux/analytics/analytics.actions';
import { emailPagePlanTitleSelector } from '../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { editEmail } from '../../../../redux/order/order.actions';
import { orderEmailSelector, updatePaymentEmailErrorSelector } from '../../../../redux/order/order.selectors';
import uClasses from '../../../../styles/utilities.module.scss';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import Button from '../../../Shared/Elements/button/button';
import LockIcon from '../../../Shared/Elements/lock-icon';
import { I18N_KEY_TO_VALUE, validateEmail } from '../../signup/sign-up/sign-up-validate';
import classes from './email-form.module.scss';

const isFormValid = (errors) => {
  return Object.keys(errors).filter((fieldName) => errors[fieldName]).length === 0;
};

const bRegExp = /<b>(.*?)<\/b>/g;

interface IEmailFormProps {
  onSubmit: () => void;
}

function EmailForm({ onSubmit }: IEmailFormProps): React.ReactElement {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const orderEmail = useSelector(orderEmailSelector);
  const [email, setEmail] = useState('');
  const paymentEmailError = useSelector(updatePaymentEmailErrorSelector);
  const emailPagePlanTitle = useSelector(emailPagePlanTitleSelector);

  const [validationErrors, setValidationErrors] = useState({
    emailError: null,
  });

  useEffect(() => {
    dispatch(emailInputAction('purchasing'));
  }, []);

  useEffect(() => {
    if (orderEmail && !email) {
      setEmail(orderEmail);
    }
  }, [orderEmail]);

  function validateAndSetErrors({ paymentEmail }) {
    const emailError = validateEmail(paymentEmail);
    const errors = { emailError };

    setValidationErrors({ emailError });

    return errors;
  }

  const onEmailChange = (e) => {
    setValidationErrors({ ...validationErrors, emailError: null });
    setEmail(e.target.value);
  };

  const onFormSubmit = (e) => {
    e.preventDefault();
    const errors = validateAndSetErrors({ paymentEmail: email });

    if (isFormValid(errors)) {
      dispatch(editEmail(email));
      onSubmit();
    }
  };

  const { emailError } = validationErrors;
  const emailPagePlanTitleFormatted = reactStringReplace(emailPagePlanTitle, bRegExp, (match, i) => (
    <b key={match + i}>{match}</b>
  ));
  return (
    <form onSubmit={onFormSubmit} className={classes.form}>
      <div>
        <p className={classes.title}>
          {t('emailForm:title', 'Enter your email to learn how to')} {emailPagePlanTitleFormatted}
        </p>
        <div className={classes.inputRow}>
          <input
            className={cn(uClasses.uInput, { [uClasses.isInvalid]: !!emailError })}
            value={email}
            type="email"
            name="email"
            onChange={onEmailChange}
            placeholder={t('emailForm:enterEmail', 'Enter your email to get your plan')}
          />
          {emailError && <div className={classes.error}>{t(emailError, I18N_KEY_TO_VALUE[emailError])}</div>}
        </div>
        <div className={classes.tip}>
          <LockIcon />
          <span className={classes.tipText}>
            {t(
              'emailForm:tip',
              `BetterMe doesn't sell or rent your personal information to anyone. We'll email you a copy of your results for convenient access.`,
            )}
          </span>
        </div>
      </div>
      <div>
        <Button type="submit">{t('signUp:buttonContinue', 'Continue')}</Button>
        {paymentEmailError && (
          <div className={classes.mainError}>{t(paymentEmailError.key, paymentEmailError.value)}</div>
        )}
      </div>
    </form>
  );
}

export default EmailForm;
