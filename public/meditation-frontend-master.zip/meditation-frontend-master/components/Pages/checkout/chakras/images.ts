import createCloudinaryImageSet from '../../../../utils/src-set';

export const topBannerFemaleSet = createCloudinaryImageSet('meditation/chakras/checkout-banner-female_pb59er');

export const topBannerFemaleLgSet = createCloudinaryImageSet('meditation/chakras/checkout-banner-female-lg_mrqk8b');
