import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { checkoutGetMyPlanTopClickAction } from '../../../../../redux/analytics/analytics.actions';
import { checkoutPageButtonTextSelector } from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { initialPlanSelected, requestPaymentPopup } from '../../../../../redux/order/order.actions';
import Button from '../../../../Shared/Elements/button/button';
import classes from '../checkout-chakras-common.module.scss';
import FeaturedIn from '../components/featured-in/featured-in';
import PlanInfoOnePrice from '../components/plan-info-one-price';
import SafeCheckout from '../components/safe-checkout/safe-checkout';
import WhatYouWillGet from '../components/what-you-will-get/what-you-will-get';
import { topBannerFemaleLgSet, topBannerFemaleSet } from '../images';
import localClasses from './checkout-chakras-customized-area.module.scss';

function CheckoutChakrasCustomizedArea({ plan }) {
  const dispatch = useDispatch();
  const buttonText = useSelector(checkoutPageButtonTextSelector);

  useEffect(() => {
    dispatch(initialPlanSelected(plan));
  }, [dispatch]);

  const onGetPlanClick = () => {
    dispatch(checkoutGetMyPlanTopClickAction());
    dispatch(requestPaymentPopup('HORIZONTAL_PAYMENT_POPUP_WITH_LEGAL_TEXT'));
  };

  return (
    <section className={classes.checkoutCustomized}>
      <div className={localClasses.topBanner}>
        <div className={localClasses.desktopOnly}>
          <img
            className={classes.topBannerImg}
            src={topBannerFemaleLgSet.src}
            srcSet={topBannerFemaleLgSet.srcSet}
            alt=""
          />
        </div>
        <div className={localClasses.mobileOnly}>
          <img
            className={classes.topBannerImg}
            src={topBannerFemaleSet.src}
            srcSet={topBannerFemaleSet.srcSet}
            alt=""
          />
        </div>
      </div>

      <div className={localClasses.benefitsBanner}>
        <div className={classes.container}>
          <div className={localClasses.benefitsBannerRow}>
            <div className={localClasses.infoBlock}>
              <div className={localClasses.planInfo}>
                <PlanInfoOnePrice />
              </div>

              <div className={localClasses.mobileOnly}>
                <div className={localClasses.benefitsBannerWhatYouWillGet}>
                  <WhatYouWillGet />
                </div>
              </div>

              <div className={localClasses.buttonBlock}>
                <Button fullWidth onClick={onGetPlanClick}>
                  {buttonText}
                </Button>
              </div>
            </div>

            <div className={localClasses.actionBlock}>
              <div className={localClasses.desktopOnly}>
                <WhatYouWillGet />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className={classes.safeCheckout}>
        <div className={classes.container}>
          <SafeCheckout />
        </div>
      </div>

      <div className={classes.featuredIn}>
        <div className={classes.container}>
          <FeaturedIn />
        </div>
      </div>
    </section>
  );
}

export default CheckoutChakrasCustomizedArea;
