export { default } from './plan-info-one-price';
