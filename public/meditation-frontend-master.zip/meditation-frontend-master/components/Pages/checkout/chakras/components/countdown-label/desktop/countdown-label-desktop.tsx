import React from 'react';

import Trans from '../../../../../../../utils/next-with-i18n/trans';

function CountdownLabelDesktop() {
  {
    /* i18n:extract t('checkoutWithIntroductory:countdownLabelDynamic', 'Reserved <0>discount</0> for:') */
  }
  return <Trans i18nKey="checkoutWithIntroductory:countdownLabelDynamic" components={[<span key="0" />]} />;
}

export default CountdownLabelDesktop;
