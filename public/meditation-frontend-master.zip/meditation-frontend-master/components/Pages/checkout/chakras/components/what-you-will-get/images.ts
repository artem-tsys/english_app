import createCloudinaryImageSet from '../../../../../../utils/src-set';

export const heartIconSet = createCloudinaryImageSet('meditation/chakras/what-you-will-get/heart_a26igr');

export const stressIconSet = createCloudinaryImageSet('meditation/chakras/what-you-will-get/stress_bz5gfl');

export const sleepIconSet = createCloudinaryImageSet('meditation/chakras/what-you-will-get/sleep_tvqmxh');
