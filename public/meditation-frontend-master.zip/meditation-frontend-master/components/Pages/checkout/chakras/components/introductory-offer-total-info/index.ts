export { default } from './introductory-offer-total-info';
