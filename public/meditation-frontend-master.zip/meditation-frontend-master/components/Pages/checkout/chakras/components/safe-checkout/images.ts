import createCloudinaryImageSet from '../../../../../../utils/src-set';

export const paymentSystemsImageSet = createCloudinaryImageSet('meditation/safe-checkout/payment-systems_tlfvov');
