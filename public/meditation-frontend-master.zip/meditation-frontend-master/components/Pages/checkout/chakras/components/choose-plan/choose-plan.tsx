import React, { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { CHACKRAS_OFFER_PLANS, Plan, PlanId } from '../../../../../../constants/order.constants';
import { planSelected } from '../../../../../../redux/order/order.actions';
import { isVatApplicableSelector, selectedPlanIdSelector } from '../../../../../../redux/order/order.selectors';
import getMonthsFromDays from '../../../../../../utils/get-months-from-days';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import PulsingButton from '../../../../../Shared/Elements/pulsing-button/pulsing-button';
import { VatExplanation } from '../vat-explanation/vat-explanation';
import classes from './choose-plan.module.scss';
import PlanItemDetailed from './plain-item-detailed/plan-item';
import PlanItem from './plan-item/plan-item';

export interface ChoosePlanProps {
  plan: Plan;
  customDiscount?: string;
}

export interface ChoosePlanItem {
  plan: Plan;
  mostPopular?: boolean;
  pricePerDay: number;
  oldPricePerDay: number;
}
interface Props {
  plans: unknown;
  hideTitle?: boolean;
  onSelect: () => void;
  dataButton: string;
  showOneTimePaymentNote?: boolean;
  underButtonElement: JSX.Element;
  style?: string;
}

const ChoosePlan = ({
  hideTitle = false,
  plans = CHACKRAS_OFFER_PLANS,
  onSelect,
  dataButton = 'choose-plan-get-plan',
  showOneTimePaymentNote = true,
  underButtonElement = null,
  style = 'DEFAULT',
}: Props) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const selectedPlan = useSelector(selectedPlanIdSelector);
  const selectedPlanId = useSelector(selectedPlanIdSelector);
  const isVatApplicable = useSelector(isVatApplicableSelector);
  const isDefault = style === 'DEFAULT';
  const selectPlan = useCallback(
    (id: PlanId) => {
      dispatch(planSelected(id));
    },
    [dispatch],
  );

  return (
    <div className={classes.container}>
      {!hideTitle && <h3 className={classes.title}>{t('choosePlan:title', 'Choose Your Plan')}</h3>}
      <div className={classes.planListContainer}>
        {isDefault
          ? (plans as ChoosePlanProps[]).map((planItem) => (
              <PlanItem
                plan={planItem.plan}
                key={planItem.plan.id}
                isSelected={selectedPlan === planItem.plan.id}
                onSelect={selectPlan}
                bestOfferMonths={getMonthsFromDays(plans[0].plan.days)}
                customDiscount={planItem.customDiscount}
              />
            ))
          : (plans as ChoosePlanItem[]).map((planItem) => (
              <PlanItemDetailed
                key={planItem.plan.id}
                plan={planItem.plan}
                isSelected={selectedPlanId === planItem.plan.id}
                onSelect={selectPlan}
                showMostPopular={planItem.mostPopular}
                pricePerDay={planItem.pricePerDay}
                oldPricePerDay={planItem.oldPricePerDay}
              />
            ))}
      </div>

      {isDefault && (
        <p className={classes.legalNote}>
          {t('choosePlan:comparedToPerWeek', '*Compared to the per week price of 1-Week Plan')}
        </p>
      )}

      {isVatApplicable && (
        <div className={classes.vatContainer}>
          <VatExplanation />
        </div>
      )}
      <div className={classes.getPlanButton}>
        <PulsingButton onClick={onSelect} dataButton={dataButton}>
          {t('choosePlan:buttonGetMyPlan', 'Get my plan')}
        </PulsingButton>
      </div>

      {underButtonElement}

      {showOneTimePaymentNote && (
        <div className={classes.planNote}>{t('choosePlan:note', 'One-time payment | No hidden fees')}</div>
      )}
    </div>
  );
};

export default ChoosePlan;
