import cn from 'classnames';
import React from 'react';
import { useSelector } from 'react-redux';

import { calculatePlanDiscountPercentage as calculatePlanDiscount } from '../../../../../../../business-logic/calculate-plan-discount-percentage.logic';
import { Plan } from '../../../../../../../constants/order.constants';
import { MONTH_DAYS } from '../../../../../../../constants/quiz-options.constants';
import { isDiscountAvailableSelector, priceToChargeSelector } from '../../../../../../../redux/order/order.selectors';
import { State } from '../../../../../../../redux/store';
import { formatPrice } from '../../../../../../../utils/format-price.util';
import Trans from '../../../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../../../utils/next-with-i18n/use-translation';
import LikeIcon from '../../../../../../Shared/Elements/icons/like-icon';
import StarIcon from '../../../../../../Shared/Elements/icons/star-icon';
import SelectableCard from '../../../../../../Shared/Elements/selectable-card/selectable-card';
import classes from './plan-item.module.scss';

const Notification = () => {
  const { t } = useTranslation();

  return (
    <div className={classes.notificationContainer}>
      <SelectableCard isSelected className={classes.planNotification} selectedClassName={classes.planNotification}>
        <div className={classes.notificationText}>
          <strong className={classes.notificationDescriptionAccent}>{t('notification:title', 'Important!')}</strong>
        </div>
        <div className={classes.notificationText}>
          {/* i18n:extract t('notification:youCanSaveMostWithLifetime', `You can <0>save the most</0> with <0>Lifetime plan</0>`) */}
          <Trans
            i18nKey="notification:youCanSaveMostWithLifetime"
            components={[<strong className={classes.notificationDescriptionAccent} key="0" />]}
          />
        </div>
      </SelectableCard>
    </div>
  );
};

const PlanMainInfo = ({ name, pricePerDay, price, strikedPrice, days, isBestValue, isMostPopular }) => {
  const { t } = useTranslation();

  return (
    <div className={classes.planMainInfo}>
      <div className={classes.planMainInfoNameRow}>
        <span className={classes.planName}>{name}</span>
        {isBestValue && (
          <span className={classes.planBadge}>
            <StarIcon className={classes.planBadgeIcon} />
            {t('planItemConstructor:bestValue', 'Best value')}
          </span>
        )}
        {isMostPopular && (
          <span className={classes.planBadge}>
            <LikeIcon className={classes.planBadgeIcon} />
            {t('planItemConstructor:mostPopular', 'Most popular')}
          </span>
        )}
      </div>

      <div className={classes.planMainInfoPricePerDayRow}>
        <span className={classes.planPricePerDay}>
          {/* i18n:extract t('planItemConstructor:pricePerDay', `<0>{{currencySymbol}}</0><1>{{pricePerDay}}</1> per day`) */}
          <Trans
            i18nKey="planItemConstructor:pricePerDay"
            components={[
              <span className={classes.planPricePerDayCurrency} key="0" />,
              <span className={classes.planPricePerDayAmount} key="1" />,
            ]}
            values={{
              currencySymbol: pricePerDay.substring(0, 1),
              pricePerDay: pricePerDay.substring(1),
            }}
          />
        </span>
      </div>

      <div className={classes.planMainInfoPriceRow}>
        <span className={classes.planPrice}>
          <span className={classes.planPriceStriked}>{strikedPrice}</span> {price}{' '}
          <span className={classes.planPricePeriod}>
            {days >= 200 * MONTH_DAYS
              ? t('planItemConstructor:oneTimePayment', 'one-time payment')
              : t('planItemConstructor:perMonth', 'per month')}
          </span>
        </span>
      </div>
    </div>
  );
};

interface Props {
  plan: Plan;
  isSelected: boolean;
  onSelect: (id: string) => void;
  pricePerDay: number;
  isBestValue?: boolean;
  isMostPopular?: boolean;
}

const PlanItem = ({ plan, isSelected, onSelect, pricePerDay, isBestValue, isMostPopular }: Props) => {
  const { t, lang: locale } = useTranslation();
  const { amount, name, i18nKey, id, days } = plan;

  const isDiscountAvailable = useSelector(isDiscountAvailableSelector);
  const discount = isDiscountAvailable ? calculatePlanDiscount(plan) : 0;
  const isDiscountShown = discount > 0;

  const onClick = () => {
    onSelect(id);
  };

  const priceToCharge = useSelector((state: State) => priceToChargeSelector(state, { plan }));

  return (
    <div onClick={onClick} className={cn(classes.plan, { [classes.isSelected]: isSelected })}>
      <SelectableCard isSelected={isSelected} className={classes.planCard} selectedClassName={classes.selectedPlanCard}>
        <PlanMainInfo
          name={t(i18nKey, name)}
          pricePerDay={formatPrice(pricePerDay)}
          price={formatPrice(priceToCharge, { locale })}
          strikedPrice={isDiscountShown && formatPrice(amount, { locale, fractionDigits: 0 })}
          days={days}
          isBestValue={isBestValue}
          isMostPopular={isMostPopular}
        />

        {isDiscountShown && (
          <span className={classes.planSaveLabel}>
            {t('discountLabel:save', 'Save')} {Math.round(discount * 100)}%
          </span>
        )}
      </SelectableCard>

      {isSelected && <Notification />}
    </div>
  );
};

export default PlanItem;
