import cn from 'classnames';
import Link from 'next/link';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';

import { openSidebar } from '../../../../../../redux/general/common.actions';
import { createCloudinaryImageSet } from '../../../../../../utils/src-set';
import BurgerButton from '../../../../../Shared/Elements/burger-button/burger-button';
import classes from './header-with-countdown-desktop.module.scss';

interface Props {
  isCountdownHidden?: boolean;
  Countdown?: JSX.Element | null;
}

function HeaderWithCountdownDesktop({ isCountdownHidden = false, Countdown }: Props) {
  const [isPageScrolled, setIsPageScrolled] = useState(window.pageYOffset > 0);
  const homePage = '/';
  const logoSet = createCloudinaryImageSet('fbqvmxchcw8afssfdw39');
  const dispatch = useDispatch();

  const onMenuButtonClick = () => {
    dispatch(openSidebar());
  };

  const handleScroll = () => {
    setIsPageScrolled(window.pageYOffset > 0);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={cn(classes.header, { [classes.headerShadowed]: isPageScrolled })}>
      {homePage && (
        <div className={classes.logo}>
          <Link href={homePage}>
            <a>
              <img className={classes.logoImage} src={logoSet.src} srcSet={logoSet.srcSet} />
            </a>
          </Link>
        </div>
      )}

      <div className={classes.container}>
        {!isCountdownHidden && Countdown && <div className={classes.countdown}>{Countdown}</div>}
      </div>

      <div className={classes.burgerButton}>
        <BurgerButton onClick={onMenuButtonClick} />
      </div>
    </header>
  );
}

export default HeaderWithCountdownDesktop;
