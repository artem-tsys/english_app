import React from 'react';
import { useSelector } from 'react-redux';

import {
  firstBillingPeriodSelector,
  orderAmountSelector,
  selectedPlanSelector,
} from '../../../../../../redux/order/order.selectors';
import { formatPrice } from '../../../../../../utils/format-price.util';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import { PeriodShort } from '../../../../../Shared/Elements/period/period';
import classes from './introductory-offer-total-info.module.scss';

const IntroductoryOfferTotalInfo: React.FC<{ showPeriod?: boolean }> = ({ showPeriod }) => {
  const { t, lang: locale } = useTranslation();
  const amount = useSelector(orderAmountSelector);
  const plan = useSelector(selectedPlanSelector);
  const firstBillingPeriod = useSelector(firstBillingPeriodSelector);

  return (
    <div>
      <div className={classes.orderInfoRow} data-total-price={amount}>
        <span className={classes.totalLabel}>{t('orderInfo:total', 'Total')}:</span>
        <span className={classes.totalAmount}>
          {plan && (
            <>
              <span className={classes.price}>{formatPrice(plan.introductoryPrice, { locale })} </span>{' '}
              {showPeriod && (
                <span className={classes.period}>
                  {t('orderInfo:per', 'per')} <PeriodShort days={firstBillingPeriod} delimeter={' '} />
                </span>
              )}
            </>
          )}
        </span>
      </div>
    </div>
  );
};

export default IntroductoryOfferTotalInfo;
