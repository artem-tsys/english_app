import React from 'react';

import { Trans } from '../../../../../../i18n';
import { paymentSystemsImageSet } from './images';
import classes from './safe-checkout.module.scss';

function SafeCheckout() {
  return (
    <div className={classes.container}>
      <span className={classes.title}>
        {
          //i18n:extract t('safeCheckout:title','Guaranteed <0>Safe</0> Checkout')
        }
        <Trans i18nKey="safeCheckout:title" components={[<b key="0" />]} />
      </span>
      <div className={classes.paymentSystemsBox}>
        <img
          className={classes.paymentSystemsImg}
          src={paymentSystemsImageSet.src}
          srcSet={paymentSystemsImageSet.srcSet}
          alt=""
        />
      </div>
    </div>
  );
}

export default SafeCheckout;
