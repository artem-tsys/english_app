export { default } from './countdown-label-desktop';
