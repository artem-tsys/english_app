import React from 'react';

import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import classes from './featured-in.module.scss';
import Forbes from './forbes';
import Mashable from './mashable';
import NewYorkTimes from './new-york-times';
import UsaToday from './usaToday';
import WSJ from './WSJ';

function FeaturedIn() {
  const { t } = useTranslation();

  return (
    <div className={classes.container}>
      <h4 className={classes.title}>{t('quizMinified:featuredIn', 'As featured in')}</h4>
      <div className={classes.row}>
        <UsaToday className={classes.logo} />
        <Forbes className={classes.logo} />
        <WSJ className={classes.logo} />
      </div>
      <div className={classes.row}>
        <NewYorkTimes className={classes.logo} />
        <Mashable className={classes.logo} />
      </div>
    </div>
  );
}

export default FeaturedIn;
