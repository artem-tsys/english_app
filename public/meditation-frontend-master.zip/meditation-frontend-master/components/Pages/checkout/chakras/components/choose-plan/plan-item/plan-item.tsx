import cn from 'classnames';
import React from 'react';
import { useSelector } from 'react-redux';

import { calculatePlanDiscountPercentage as calculatePlanDiscount } from '../../../../../../../business-logic/calculate-plan-discount-percentage.logic';
import { Plan } from '../../../../../../../constants/order.constants';
import { MONTH_DAYS } from '../../../../../../../constants/quiz-options.constants';
import {
  isDiscountAvailableSelector,
  pricePerWeekSelector,
  priceToChargeSelector,
} from '../../../../../../../redux/order/order.selectors';
import { State } from '../../../../../../../redux/store';
import { formatPrice } from '../../../../../../../utils/format-price.util';
import Trans from '../../../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../../../utils/next-with-i18n/use-translation';
import SelectableCard from '../../../../../../Shared/Elements/selectable-card/selectable-card';
import classes from './plan-item.module.scss';

const PricePerWeek = ({ value }) => {
  const { t } = useTranslation();
  return (
    <aside className={classes.planPerWeek}>
      <span className={classes.planPerWeekValue}>{value}</span>
      <span>{t('pricePerWeek:price', 'per week')}</span>
    </aside>
  );
};

const Notification = ({ bestOfferMonths }) => {
  const { t } = useTranslation();
  return (
    <div className={classes.notificationContainer}>
      <SelectableCard isSelected className={classes.planNotification} selectedClassName={classes.planNotification}>
        <div className={classes.notificationText}>
          <p className={classes.notificationTitle}> {t('notification:title', 'Important!')}</p>
          <strong className={classes.notificationDescriptionAccent}>
            {bestOfferMonths}
            {t('notification:month', '-months')}
          </strong>{' '}
          {t('notification:notificationDescriptionAccent', 'plan gives you the')}{' '}
          <strong className={classes.notificationDescriptionAccent}>
            {t('notification:notificationDescriptionAccent2part', 'best deal')}
          </strong>
        </div>
      </SelectableCard>
    </div>
  );
};

const PlanMainInfo = ({ name, price, strikedPrice, planInfo, planInfoI18nKey, days }) => {
  const { t } = useTranslation();

  const billingPeriodWord =
    days >= 6 * MONTH_DAYS
      ? t('planMainInfo:semiannually', 'semiannually')
      : days >= 1 * MONTH_DAYS
      ? t('planMainInfo:monthly', 'monthly')
      : t('planMainInfo:weekly', 'weekly');

  return (
    <div className={classes.planMainInfo}>
      <div className={classes.planName}>{name}</div>
      {/* i18n:extract t('planMainInfo:billingPeriodAndPrice', `Billed {{billingPeriodWord}} {{price}} <0>{{strikedPrice}}</0>`) */}
      <div className={classes.planDescription}>
        {planInfo && planInfoI18nKey ? (
          `${t(planInfoI18nKey, planInfo)} ${price}`
        ) : (
          <Trans
            i18nKey="planMainInfo:billingPeriodAndPrice"
            components={[<span className={classes.planPriceStriked} key="0" />]}
            values={{
              billingPeriodWord,
              price,
              strikedPrice,
            }}
          />
        )}
      </div>
    </div>
  );
};

interface Props {
  plan: Plan;
  isSelected: boolean;
  onSelect: (id: string) => void;
  bestOfferMonths: number;
  customDiscount: string;
}

const PlanItem = ({ plan, isSelected, onSelect, bestOfferMonths, customDiscount }: Props) => {
  const { t, lang: locale } = useTranslation();
  const { amount, name, i18nKey, id, pricePerWeek, planInfo, planInfoI18nKey, days } = plan;

  const isDiscountAvailable = useSelector(isDiscountAvailableSelector);
  const discount = isDiscountAvailable ? calculatePlanDiscount(plan) : 0;
  const isDiscountShown = discount > 0;
  const strikedPrice = isDiscountShown ? formatPrice(amount, { locale, fractionDigits: 0 }) : null;

  const handleClick = () => {
    onSelect(id);
  };

  const priceToCharge = useSelector((state: State) => priceToChargeSelector(state, { plan }));
  const pricePerWeekCalculated = useSelector((state: State) => pricePerWeekSelector(state, { plan }));
  const perWeek = pricePerWeek || pricePerWeekCalculated;
  return (
    <div onClick={handleClick} className={cn(classes.plan, { [classes.isSelected]: isSelected })}>
      <SelectableCard isSelected={isSelected} className={classes.planCard} selectedClassName={classes.selectedPlanCard}>
        {(customDiscount || isDiscountShown) && (
          <span className={classes.planSaveLabel}>
            {t('discountLabel:save', 'Save')} {customDiscount || `${Math.round(discount * 100)}%`}
          </span>
        )}
        <PlanMainInfo
          name={t(i18nKey, name)}
          price={formatPrice(priceToCharge, { locale })}
          strikedPrice={strikedPrice}
          planInfo={planInfo}
          planInfoI18nKey={planInfoI18nKey}
          days={days}
        />
        <PricePerWeek value={formatPrice(perWeek, { locale, fractionDigits: 2 })} />
      </SelectableCard>

      {isSelected && <Notification bestOfferMonths={bestOfferMonths} />}
    </div>
  );
};

export default PlanItem;
