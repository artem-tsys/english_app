import cn from 'classnames';
import React from 'react';
import { useSelector } from 'react-redux';

import { isVatApplicableSelector } from '../../../../../../redux/order/order.selectors';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import classes from './vat-explanation.module.scss';

interface Props {
  className?: string;
}

export const VatExplanation = ({ className }: Props) => {
  const { t } = useTranslation();
  const isVatApplicable = useSelector(isVatApplicableSelector);

  if (!isVatApplicable) return null;

  return (
    <div className={cn(classes.vatExplanation, className)}>
      {t('vatExplanation:excludingVat', 'The price is excluding VAT')}
    </div>
  );
};
