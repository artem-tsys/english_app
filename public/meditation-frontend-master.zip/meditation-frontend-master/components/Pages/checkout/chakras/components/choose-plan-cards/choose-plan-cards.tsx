import React, { cloneElement, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Plan, PlanId } from '../../../../../../constants/order.constants';
import { checkoutPageButtonTextSelector } from '../../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { planSelected } from '../../../../../../redux/order/order.actions';
import { isVatApplicableSelector, selectedPlanIdSelector } from '../../../../../../redux/order/order.selectors';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import Button from '../../../../../Shared/Elements/button/button';
import { VatExplanation } from '../vat-explanation/vat-explanation';
import classes from './choose-plan-cards.module.scss';
import PlanItem from './plan-item/plan-item';

export interface ChoosePlanCardsProps {
  plan: Plan;
  pricePerDay: number;
  isBestValue?: boolean;
  isMostPopular?: boolean;
}

interface Props {
  plans: ChoosePlanCardsProps[];
  onSelect: () => void;
  dataButton?: string;
  underButtonElement?: JSX.Element;
  PaymentButton?: JSX.Element;
}

function DefaultPaymentButton(props) {
  const buttonText = useSelector(checkoutPageButtonTextSelector);

  return (
    <Button fullWidth {...props}>
      {buttonText}
    </Button>
  );
}

const ChoosePlanCards = ({
  plans,
  onSelect,
  dataButton = 'choose-plan-get-plan',
  underButtonElement = null,
  PaymentButton = <DefaultPaymentButton />,
}: Props) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const selectedPlan = useSelector(selectedPlanIdSelector);
  const isVatApplicable = useSelector(isVatApplicableSelector);

  const selectPlan = useCallback(
    (id: PlanId) => {
      dispatch(planSelected(id));
    },
    [dispatch],
  );

  return (
    <div className={classes.container}>
      <h3 className={classes.title}>{t('choosePlan:title', 'Choose Your Plan')}</h3>
      <div className={classes.planListContainer}>
        {plans.map((planItem) => (
          <PlanItem
            key={planItem.plan.id}
            plan={planItem.plan}
            isSelected={selectedPlan === planItem.plan.id}
            onSelect={selectPlan}
            pricePerDay={planItem.pricePerDay}
            isBestValue={planItem.isBestValue}
            isMostPopular={planItem.isMostPopular}
          />
        ))}
      </div>

      {isVatApplicable && (
        <div className={classes.vatContainer}>
          <VatExplanation />
        </div>
      )}

      {PaymentButton && cloneElement(PaymentButton, { onClick: onSelect, dataButton })}

      {underButtonElement}
    </div>
  );
};

export default ChoosePlanCards;
