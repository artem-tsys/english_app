import React from 'react';

import useTranslation from '../../../../../../../utils/next-with-i18n/use-translation';

function CountdownLabel() {
  const { t } = useTranslation();
  return <>{t('checkoutGenerated:reservedPrice', 'Reserved price for:')}</>;
}

export default CountdownLabel;
