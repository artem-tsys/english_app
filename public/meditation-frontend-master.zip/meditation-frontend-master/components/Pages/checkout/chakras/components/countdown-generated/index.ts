export { default } from './countdown-generated';
