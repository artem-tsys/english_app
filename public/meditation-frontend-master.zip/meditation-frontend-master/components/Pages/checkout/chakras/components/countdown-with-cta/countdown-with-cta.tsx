import React, { useContext } from 'react';

import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import PulsingButton, { PulsingButtonMode } from '../../../../../Shared/Elements/pulsing-button/pulsing-button';
import { CountdownContext } from '../../../generated/checkout-generated/sticky-countdown/countdown-provider';
import CountdownLabel from '../countdown-label/mobile';
import classes from './countdown-with-cta.module.scss';

interface Props {
  label?: JSX.Element;
  onCtaClick?(): void;
  ctaMode?: PulsingButtonMode;
}

function CountdownWithCta({ label = <CountdownLabel />, onCtaClick, ctaMode = PulsingButtonMode.Primary }: Props) {
  const { t } = useTranslation();
  const time = useContext(CountdownContext);

  if (!time) {
    return null;
  }

  return (
    <div className={classes.container}>
      <p className={classes.text}>{label}</p>

      <div className={classes.time}>
        <div className={classes.timeNumbers}>
          <span className={classes.timeNumber}>{time.minutes}</span>
          <span className={classes.timeDivider}>:</span>
          <span className={classes.timeNumber}>{time.seconds}</span>
        </div>

        <div className={classes.timeUnits}>
          <span className={classes.timeUnit}>{t('checkout:minutes', 'minutes')}</span>
          <span className={classes.timeUnit}>{t('checkout:seconds', 'seconds')}</span>
        </div>
      </div>
      <div className={classes.ctaContainer}>
        <PulsingButton
          onClick={onCtaClick}
          dataButton="countdown-button"
          className={classes.pulsingButton}
          mode={ctaMode}
        >
          {t('checkout:getPlanBtn', 'Get my plan')}
        </PulsingButton>
      </div>
    </div>
  );
}

export default CountdownWithCta;
