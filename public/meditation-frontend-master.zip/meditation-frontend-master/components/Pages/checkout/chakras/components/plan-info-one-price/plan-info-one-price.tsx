import React from 'react';
import { useSelector } from 'react-redux';

import { calculatePlanDiscountPercentage } from '../../../../../../business-logic/calculate-plan-discount-percentage.logic';
import { Trans } from '../../../../../../i18n';
import { selectedPlanSelector } from '../../../../../../redux/order/order.selectors';
import { formatPrice } from '../../../../../../utils/format-price.util';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import classes from './plan-info-one-price.module.scss';

function PlanInfoOnePrice() {
  const { lang: locale, t } = useTranslation();
  const selectedPlan = useSelector(selectedPlanSelector);

  if (!selectedPlan) {
    return null;
  }
  //Todo: Add Trans
  return (
    <div className={classes.container}>
      <div className={classes.text}>
        <div className={classes.planSaveLabel}>
          <div className={classes.planSaveText}>
            {t('planInfoOnePrice:planSaveText', 'SPECIAL OFFER - SAVE')}{' '}
            {Math.round(calculatePlanDiscountPercentage(selectedPlan) * 100)}%
          </div>
        </div>

        <span className={classes.title}>
          {
            //i18n:extract t('planInfoOnePrice:title','Get Your <0>Personalized</0> Plan')
          }
          <Trans i18nKey="planInfoOnePrice:title" components={[<b key="0" />]} />
        </span>
      </div>

      <div className={classes.price}>
        <div className={classes.priceToCharge}>{formatPrice(selectedPlan.discountedPrice, { locale })}</div>

        <div className={classes.priceStriked}>{formatPrice(selectedPlan.amount, { locale, fractionDigits: 0 })}</div>
      </div>
    </div>
  );
}

export default PlanInfoOnePrice;
