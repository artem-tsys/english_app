import React, { useContext } from 'react';
import useIsInViewport from 'use-is-in-viewport';

import { HEADER_HEIGHT } from '../../../../../../constants/header.constants';
import { PulsingButtonMode } from '../../../../../Shared/Elements/pulsing-button/pulsing-button';
import { CountdownContext } from '../../../generated/checkout-generated/sticky-countdown/countdown-provider';
import CountdownLabel from '../countdown-label/mobile';
import CountdownWithCta from '../countdown-with-cta/countdown-with-cta';
import classes from './sticky-countdown-with-cta.module.scss';

interface CountdownProps {
  label?: JSX.Element;
}

const Countdown = ({ label = <CountdownLabel /> }: CountdownProps) => {
  const time = useContext(CountdownContext);

  if (!time) {
    return null;
  }

  return (
    <div className={classes.containerXs}>
      <div className={classes.countdownText}>
        {label}{' '}
        <span className={classes.countdownTimeUnit}>
          <span className={classes.countdownTimeNumber}>{time.minutes}</span>
          <span className={classes.countdownTimeNumber}>:</span>
          <span className={classes.countdownTimeNumber}>{time.seconds}</span>
        </span>
      </div>
    </div>
  );
};

interface FixedCountdownWithCtaProps {
  label?: JSX.Element;
  onCtaClick?(): void;
  ctaMode?: PulsingButtonMode;
}

export const FixedCountdownWithCta = ({ label, onCtaClick, ctaMode }: FixedCountdownWithCtaProps) => {
  return (
    <div className={classes.fixedCountdown}>
      <CountdownWithCta ctaMode={ctaMode} label={label} onCtaClick={onCtaClick} />
    </div>
  );
};

const StickyCountdownWithCta = ({ label, onCtaClick, ctaMode }: FixedCountdownWithCtaProps) => {
  const [isInViewport, ref] = useIsInViewport({
    modTop: `-${HEADER_HEIGHT}px`,
  });

  return (
    <>
      <div ref={ref} className={classes.countdown}>
        <Countdown label={label} />
      </div>
      {!isInViewport && <FixedCountdownWithCta label={label} onCtaClick={onCtaClick} ctaMode={ctaMode} />}
    </>
  );
};

export default StickyCountdownWithCta;
