import React from 'react';
import { useSelector } from 'react-redux';

import useDeviceMode from '../../../../../../hooks/use-device-mode.hook';
import { Trans } from '../../../../../../i18n';
import { isAdditionalDiscountAppliedSelector } from '../../../../../../redux/order/order.selectors';
import { PulsingButtonMode } from '../../../../../Shared/Elements/pulsing-button/pulsing-button';
import CountdownLabelDesktop from '../countdown-label/desktop';
import CountdownLabel from '../countdown-label/mobile';
import CountdownWithCta from '../countdown-with-cta/countdown-with-cta';
import StickyCountdownWithCta, { FixedCountdownWithCta } from '../sticky-countdown-with-cta/sticky-countdown-with-cta';

interface Props {
  onCtaClick?: () => void;
}

function CountdownGenerated({ onCtaClick }: Props) {
  const mode = useDeviceMode();
  const isDesktop = mode === 'desktop';
  const isAdditionalDiscountApplied = useSelector(isAdditionalDiscountAppliedSelector);

  if (isAdditionalDiscountApplied) {
    return isDesktop ? (
      <CountdownWithCta
        ctaMode={PulsingButtonMode.Secondary}
        onCtaClick={onCtaClick}
        label={
          <>
            {/* i18n:extract t('checkoutWithIntroductory:countdownLabelCustomizable', 'Reserved <0>{{percent}}% discount</0> for:') */}
            <Trans
              i18nKey="checkoutWithIntroductory:countdownLabelCustomizable"
              components={[<b style={{ color: 'var(--accentRedColor)' }} key="0" />]}
              values={{ percent: 50 }}
            />
          </>
        }
      />
    ) : (
      <FixedCountdownWithCta ctaMode={PulsingButtonMode.Secondary} label={<CountdownLabel />} />
    );
  } else {
    return isDesktop ? (
      <CountdownWithCta
        onCtaClick={onCtaClick}
        ctaMode={PulsingButtonMode.Secondary}
        label={<CountdownLabelDesktop />}
      />
    ) : (
      <StickyCountdownWithCta
        onCtaClick={onCtaClick}
        ctaMode={PulsingButtonMode.Secondary}
        label={<CountdownLabel />}
      />
    );
  }
}

export default CountdownGenerated;
