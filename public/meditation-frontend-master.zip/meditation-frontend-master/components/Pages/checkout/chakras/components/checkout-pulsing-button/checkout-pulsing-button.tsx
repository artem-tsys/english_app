import React from 'react';

import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import PulsingButton from '../../../../../Shared/Elements/pulsing-button';

interface Props {
  onClick?: () => void;
  dataButton?: string;
}

function CheckoutPulsingButton({ onClick, dataButton = 'checkout-get-plan' }: Props) {
  const { t } = useTranslation();

  return (
    <PulsingButton onClick={onClick} dataButton={dataButton}>
      {t('choosePlan:buttonGetMyPlan', 'Get my plan')}
    </PulsingButton>
  );
}

export default CheckoutPulsingButton;
