import cn from 'classnames';
import React from 'react';

import { Plan } from '../../../../../../../constants/order.constants';
import { formatPrice, getCentsWithoutDollars, getDollars } from '../../../../../../../utils/format-price.util';
import Trans from '../../../../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../../../../utils/next-with-i18n/use-translation';
import LabelTriangleLeft from '../../../../../../Shared/Elements/icons/label-triangle-left/label-triangle-left';
import SelectableCard from '../../../../../../Shared/Elements/selectable-card/selectable-card';
import classes from './plan-item.module.scss';

interface Props {
  plan: Plan;
  isSelected: boolean;
  onSelect: (id: string) => void;
  showMostPopular?: boolean;
  pricePerDay: number;
  oldPricePerDay: number;
}

const currencySymbols = {
  fr: '€',
  de: '€',
  it: '€',
};

const PlanItemDetailed = ({ plan, isSelected, onSelect, showMostPopular, pricePerDay, oldPricePerDay }: Props) => {
  const { t, lang: locale } = useTranslation();

  const { name, i18nKey, id, introductoryPrice } = plan;
  const pricePerDayParts = {
    dollars: getDollars(pricePerDay),
    cents: getCentsWithoutDollars(pricePerDay),
  };

  const onClick = () => {
    onSelect(id);
  };

  return (
    <div
      onClick={onClick}
      data-plan={plan.id}
      className={cn(classes.plan, { [classes.isSelected]: isSelected, [classes.isMostPopular]: showMostPopular })}
      data-price={introductoryPrice}
      data-selected={isSelected}
    >
      <SelectableCard isSelected={isSelected} className={classes.planCard} selectedClassName={classes.selectedPlanCard}>
        {showMostPopular && (
          <div className={classes.mostPopularLabel}>
            {/* i18n:extract t('planItemIntroductory:mostPopularLabel', 'MOST POPULAR') */}
            <Trans i18nKey="planItemIntroductory:mostPopularLabel" />
          </div>
        )}
        <div className={classes.mainContentItemContainer}>
          <div className={classes.planMainInfo}>
            <div className={classes.pricingDetails}>
              <div className={classes.pricingDetailsLeft}>
                <div className={classes.planName}>{t(i18nKey, name)}</div>
              </div>
              <div className={classes.pricingDetailsRight}>
                <div className={classes.oldPrice}>{formatPrice(oldPricePerDay, { locale })}</div>
              </div>
            </div>
          </div>
          <div className={classes.planPerDay}>
            <LabelTriangleLeft className={classes.priceLabel} />
            <div className={classes.price}>
              <span className={classes.currency}>{currencySymbols[locale] || '$'}</span>
              <span className={classes.dollars}>{pricePerDayParts.dollars}</span>
              <span className={classes.row}>
                <span className={classes.cents}>{pricePerDayParts.cents}</span>
                <span className={classes.period}>{t('planItemIntroductory:perDay', 'per day')}</span>
              </span>
            </div>
          </div>
        </div>
      </SelectableCard>
    </div>
  );
};

export default PlanItemDetailed;
