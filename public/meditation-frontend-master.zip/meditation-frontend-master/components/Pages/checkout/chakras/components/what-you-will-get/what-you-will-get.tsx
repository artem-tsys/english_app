import React from 'react';

import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import { ImageSet } from '../../../../../../utils/src-set';
import { heartIconSet, sleepIconSet, stressIconSet } from './images';
import classes from './what-you-will-get.module.scss';

interface WhatYOuWillGetItem {
  imageSet: ImageSet;
  title: { key: string; value: string };
  subtitle: { key: string; value: string };
}
interface Props {
  wideOnDesktop?: boolean;
}

function WhatYouWillGet({ wideOnDesktop = false }: Props) {
  const { t } = useTranslation();

  const WHAT_YOU_WILL_GET_DATA: WhatYOuWillGetItem[] = [
    {
      imageSet: heartIconSet,
      title: {
        key: 'whatYouWillGet:item1Title',
        value: t('whatYouWillGet:item1Title', '70+ chakra-opening meditations'),
      },
      subtitle: {
        key: 'whatYouWillGet:item1Subtitle',
        value: t('whatYouWillGet:item1Subtitle', 'root, eye, heart chakras and more'),
      },
    },
    {
      imageSet: stressIconSet,
      title: {
        key: 'whatYouWillGet:item2Title',
        value: t('whatYouWillGet:item2Title', 'Reduce stress in minutes, anywhere'),
      },
      subtitle: {
        key: 'whatYouWillGet:item2Subtitle',
        value: t('whatYouWillGet:item2Subtitle', 'Decrease stress, reduce anxiety and cope with the world'),
      },
    },
    {
      imageSet: sleepIconSet,
      title: {
        key: 'whatYouWillGet:item3Title',
        value: t('whatYouWillGet:item3Title', 'Fall asleep in 5 minutes'),
      },
      subtitle: {
        key: 'whatYouWillGet:item3Subtitle',
        value: t(
          'whatYouWillGet:item3Subtitle',
          'Relax and unwind with sounds, breathing exercises, and sleep stories',
        ),
      },
    },
  ];

  return (
    <div className={wideOnDesktop ? classes.containerWideOnDesktop : classes.container}>
      <h3 className={classes.title}>{t('whatYouWillGet:title', 'What you will get')}</h3>
      <ul className={classes.featureList}>
        {WHAT_YOU_WILL_GET_DATA.map((item, index) => {
          const {
            imageSet,
            title: { key: titleKey, value: titleValue },
            subtitle: { key: subtitleKey, value: subtitleValue },
          } = item;
          return (
            <li className={classes.featureItem} key={`feature-${index}`}>
              <img className={classes.featureImg} src={imageSet.src} srcSet={imageSet.srcSet} alt="" />
              <div className={classes.featureText}>
                <span className={classes.featureTitle}>{t(titleKey, titleValue)}</span>
                <span className={classes.featureSubtitle}>{t(subtitleKey, subtitleValue)}</span>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

export default WhatYouWillGet;
