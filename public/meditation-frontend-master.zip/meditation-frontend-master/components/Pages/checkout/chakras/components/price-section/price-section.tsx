import React from 'react';
import { useSelector } from 'react-redux';

import { calculatePlanDiscountPercentage } from '../../../../../../business-logic/calculate-plan-discount-percentage.logic';
import { selectedPlanSelector } from '../../../../../../redux/order/order.selectors';
import { formatPrice } from '../../../../../../utils/format-price.util';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import { VatExplanation } from '../vat-explanation/vat-explanation';
import classes from './price-section.module.scss';

const PriceSection = () => {
  const { t, lang } = useTranslation();
  const plan = useSelector(selectedPlanSelector);
  const discount = Math.round(calculatePlanDiscountPercentage(plan) * 100);

  return (
    <>
      <div className={classes.container}>
        <div className={classes.priceRow}>
          <div className={classes.priceItem}>
            <div className={classes.price}>
              <div className={classes.priceDescription}>{t('priceSection:oldPrice', 'Old Price')}</div>
              <div className={classes.oldPriceValue}>{formatPrice(plan.amount, { locale: lang })}</div>
            </div>
          </div>
          <div className={classes.priceItemNew}>
            <div className={classes.newPrice}>
              <span className={classes.saveLabel}>Save {discount}%</span>
              <div className={classes.priceDescription}>{t('priceSection:newPrice', 'New Price')}</div>
              <div className={classes.priceValue}>{formatPrice(plan.discountedPrice, { locale: lang })}</div>
            </div>
          </div>
        </div>
      </div>
      <VatExplanation />
    </>
  );
};

export default PriceSection;
