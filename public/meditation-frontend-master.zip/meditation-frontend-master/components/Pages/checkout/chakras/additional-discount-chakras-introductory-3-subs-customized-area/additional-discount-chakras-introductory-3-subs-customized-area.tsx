import cn from 'classnames';
import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import { ADDITIONAL_DISCOUNT_CHACKRAS_INTRODUCTORY_OFFER_PLANS } from '../../../../../constants/order.constants';
import useDeviceMode from '../../../../../hooks/use-device-mode.hook';
import { initialPlanSelected, requestPaymentPopup } from '../../../../../redux/order/order.actions';
import { createCloudinaryImageSetWithLimitedWidth } from '../../../../../utils/src-set';
import LegalIntroductoryWithModalUS from '../../../../Shared/Elements/legal/legal-introductory-with-modal-us';
import SafeCheckoutAdvanced from '../../../../Shared/Elements/safe-checkout-advanced/safe-checkout-advanced';
import classes from '../checkout-chakras-common.module.scss';
import ChoosePlan from '../components/choose-plan/choose-plan';
import CountdownGenerated from '../components/countdown-generated';
import FeaturedIn from '../components/featured-in/featured-in';
import WhatYouWillGet from '../components/what-you-will-get/what-you-will-get';
import localClasses from './additional-discount-chakras-introductory-3-subs-customized-area.module.scss';

function AdditionalDiscountChakrasIntroductory3SubsCustomizedArea() {
  const dispatch = useDispatch();
  const mode = useDeviceMode();
  const isDesktop = mode === 'desktop';
  useEffect(() => {
    dispatch(initialPlanSelected(ADDITIONAL_DISCOUNT_CHACKRAS_INTRODUCTORY_OFFER_PLANS[1].plan.id));
  }, [dispatch]);

  const onGetPlanClick = () => {
    dispatch(requestPaymentPopup('INTRODUCTORY_OFFER_PAYMENT_POPUP'));
  };

  const cardsImageSet = createCloudinaryImageSetWithLimitedWidth(
    `/public/images/guaranteed-checkout-color_mxwlq3.png`,
    720,
  );
  const IntroductoryUnderButtonElement = (
    <>
      <div className={classes.legalContainer}>
        <LegalIntroductoryWithModalUS />
      </div>
      <SafeCheckoutAdvanced cardsImageSet={cardsImageSet} textClassName={classes.safeCheckoutText} />
    </>
  );

  return (
    <>
      {!isDesktop && <CountdownGenerated />}
      <section className={classes.checkoutCustomized}>
        <div className={cn(localClasses.desktopOnly, localClasses.whatYouWillGet)}>
          <div className={classes.container}>
            <WhatYouWillGet wideOnDesktop={true} />
          </div>
        </div>

        <div className={classes.choosePlan}>
          <div className={cn(classes.choosePlanIntroductory, classes.container)}>
            <ChoosePlan
              hideTitle={!isDesktop}
              plans={ADDITIONAL_DISCOUNT_CHACKRAS_INTRODUCTORY_OFFER_PLANS}
              onSelect={onGetPlanClick}
              showOneTimePaymentNote={false}
              dataButton="checkout-get-plan"
              underButtonElement={IntroductoryUnderButtonElement}
              style="ADVANCED"
            />
          </div>
        </div>
        <div className={cn(localClasses.mobileOnly, localClasses.whatYouWillGet)}>
          <div className={classes.container}>
            <WhatYouWillGet wideOnDesktop={true} />
          </div>
        </div>
        <div className={classes.featuredIn}>
          <div className={classes.container}>
            <FeaturedIn />
          </div>
        </div>
      </section>
    </>
  );
}

export default AdditionalDiscountChakrasIntroductory3SubsCustomizedArea;
