import { createCloudinaryImageSetWithLimitedWidth } from '../../../../../utils/src-set';

export const topBannerImageSet = createCloudinaryImageSetWithLimitedWidth('meditation/chakras/Group_3127_lvmy5w', 496);
