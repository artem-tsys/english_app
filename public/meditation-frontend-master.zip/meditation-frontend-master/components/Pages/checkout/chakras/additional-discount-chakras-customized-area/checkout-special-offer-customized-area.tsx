import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { getSpecialOfferCustomizedPlan } from '../../../../../business-logic/get-special-offer-customized-plan.logic';
import { checkoutAction } from '../../../../../redux/analytics/analytics.actions';
import { checkoutPageButtonTextSelector } from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import {
  additionalDiscountNoCountdownAccepted,
  planSelected,
  requestPaymentPopup,
  requestUpdateUtmData,
} from '../../../../../redux/order/order.actions';
import { isOrderPaidSelector, orderPlanIdSelector } from '../../../../../redux/order/order.selectors';
import { useRouter } from '../../../../../utils/next-with-i18n/router';
import Button from '../../../../Shared/Elements/button/button';
import classes from '../checkout-chakras-common.module.scss';
import FeaturedIn from '../components/featured-in/featured-in';
import PriceSection from '../components/price-section/price-section';
import SafeCheckout from '../components/safe-checkout/safe-checkout';
import WhatYouWillGet from '../components/what-you-will-get/what-you-will-get';
import { topBannerFemaleSet } from '../images';
import localClasses from './additional-discount-chakras-customized-area.module.scss';

function AdditionalDiscountChakrasSpecialOfferCustomizedArea() {
  const dispatch = useDispatch();
  const buttonText = useSelector(checkoutPageButtonTextSelector);
  const orderPlanId = useSelector(orderPlanIdSelector);
  const isOrderPaid = useSelector(isOrderPaidSelector);
  const router = useRouter();

  const onGetPlanClick = () => {
    dispatch(
      requestPaymentPopup('HORIZONTAL_PAYMENT_POPUP_WITH_LEGAL_TEXT', {
        disableDobivashka: true,
        isDiscountAvailable: true,
      }),
    );
  };

  useEffect(() => {
    dispatch(checkoutAction('purchasing'));
  }, [dispatch]);

  useEffect(() => {
    dispatch(additionalDiscountNoCountdownAccepted());
    if (!isOrderPaid) {
      const { utm_campaign, utm_source = 'esputnik_remarketing' } = router.query;
      dispatch(requestUpdateUtmData(utm_source, utm_campaign));
    }
  }, [dispatch]);

  useEffect(() => {
    dispatch(planSelected(getSpecialOfferCustomizedPlan(orderPlanId)));
  }, []);

  return (
    <section className={classes.checkoutCustomized}>
      <div className={localClasses.topBanner}>
        <div className={classes.topBannerRow}>
          <div className={localClasses.topBannerImageBlock}>
            <img
              className={classes.topBannerImg}
              src={topBannerFemaleSet.src}
              srcSet={topBannerFemaleSet.srcSet}
              alt=""
            />
          </div>

          <div className={localClasses.topBannerFeaturesBlock}>
            <div className={localClasses.topBannerPrice}>
              <div className={classes.containerNoDesktopPadding}>
                <PriceSection />
              </div>
            </div>

            <div className={localClasses.topBannerButton}>
              <div className={classes.containerNoDesktopPadding}>
                <Button fullWidth onClick={onGetPlanClick} dataButton="checkout-flatter-belly-challenge-get-plan">
                  {buttonText}
                </Button>
              </div>
            </div>

            <div className={classes.topBannerSafeCheckout}>
              <SafeCheckout />
            </div>
          </div>
        </div>
      </div>

      <div className={localClasses.whatYouWillGet}>
        <div className={classes.container}>
          <WhatYouWillGet wideOnDesktop={true} />
        </div>
      </div>

      <div className={classes.safeCheckout}>
        <div className={classes.container}>
          <SafeCheckout />
        </div>
      </div>

      <div className={classes.featuredIn}>
        <div className={classes.container}>
          <FeaturedIn />
        </div>
      </div>
    </section>
  );
}

export default AdditionalDiscountChakrasSpecialOfferCustomizedArea;
