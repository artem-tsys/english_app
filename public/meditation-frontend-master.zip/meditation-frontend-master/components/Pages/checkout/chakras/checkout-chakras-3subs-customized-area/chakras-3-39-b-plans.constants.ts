import {
  CHAKRAS_3_39_B_ONE_MONTH,
  CHAKRAS_3_39_B_ONE_WEEK,
  CHAKRAS_3_39_B_SIX_MONTH,
} from '../../../../../constants/order.constants';
import { ChoosePlanProps } from '../components/choose-plan/choose-plan';

export const CHAKRAS_3_39_B_PLANS: ChoosePlanProps[] = [
  { plan: CHAKRAS_3_39_B_SIX_MONTH, customDiscount: '85%*' },
  { plan: CHAKRAS_3_39_B_ONE_MONTH, customDiscount: '54%*' },
  { plan: CHAKRAS_3_39_B_ONE_WEEK },
];
