import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { PlanId } from '../../../../../constants/order.constants';
import { PopupName } from '../../../../../constants/popups.constants';
import { initialPlanSelected, requestPaymentPopup } from '../../../../../redux/order/order.actions';
import { selectedPlanIdSelector } from '../../../../../redux/order/order.selectors';
import Loader from '../../../../Shared/Elements/loader/loader';
import classes from '../checkout-chakras-common.module.scss';
import ChoosePlan from '../components/choose-plan/choose-plan';
import FeaturedIn from '../components/featured-in/featured-in';
import SafeCheckout from '../components/safe-checkout/safe-checkout';
import WhatYouWillGet from '../components/what-you-will-get/what-you-will-get';
import { topBannerFemaleSet } from '../images';
import { CHAKRAS_3_39_B_PLANS } from './chakras-3-39-b-plans.constants';
import localClasses from './checkout-chakras-3subs-customized-area.module.scss';

interface Props {
  paymentPopup?: PopupName;
  underButtonElement?: JSX.Element;
}

function CheckoutChakras3subsCustomizedArea({
  paymentPopup = 'HORIZONTAL_PAYMENT_POPUP_WITH_LEGAL_TEXT',
  underButtonElement = null,
}: Props) {
  const dispatch = useDispatch();
  const planId = useSelector(selectedPlanIdSelector);

  useEffect(() => {
    dispatch(initialPlanSelected(PlanId.Chakras339BSixMonth));
  }, [dispatch]);

  const onGetPlanClick = () => {
    dispatch(requestPaymentPopup(paymentPopup));
  };

  if (!planId) {
    return <Loader isShown />;
  }

  return (
    <section className={classes.checkoutCustomized}>
      <div className={localClasses.topBanner}>
        <div className={classes.topBannerRow}>
          <div className={localClasses.topBannerImageBlock}>
            <img
              className={classes.topBannerImg}
              src={topBannerFemaleSet.src}
              srcSet={topBannerFemaleSet.srcSet}
              alt=""
            />
          </div>

          <div className={localClasses.topBannerFeaturesBlock}>
            <div className={classes.containerNoDesktopPadding}>
              <WhatYouWillGet />
            </div>

            <div className={classes.topBannerSafeCheckout}>
              <div className={classes.containerNoDesktopPadding}>
                <SafeCheckout />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className={classes.choosePlan}>
        <div className={classes.container}>
          <ChoosePlan
            plans={CHAKRAS_3_39_B_PLANS}
            onSelect={onGetPlanClick}
            showOneTimePaymentNote={false}
            dataButton="checkout-get-plan"
            underButtonElement={underButtonElement}
          />
        </div>
      </div>

      <div className={classes.safeCheckout}>
        <div className={classes.container}>
          <SafeCheckout />
        </div>
      </div>

      <div className={classes.featuredIn}>
        <div className={classes.container}>
          <FeaturedIn />
        </div>
      </div>
    </section>
  );
}

export default CheckoutChakras3subsCustomizedArea;
export const underButtonElementClass = classes.underButtonElement;
