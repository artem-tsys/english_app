import { CHAKRAS_2_99_LIFETIME, CHAKRAS_2_99_ONE_MONTH } from '../../../../../constants/order.constants';
import { ChoosePlanCardsProps } from '../components/choose-plan-cards/choose-plan-cards';

export const CHAKRAS_2_99_LIFETIME_PLANS: ChoosePlanCardsProps[] = [
  { plan: CHAKRAS_2_99_LIFETIME, pricePerDay: 30, isBestValue: true },
  { plan: CHAKRAS_2_99_ONE_MONTH, pricePerDay: 143, isMostPopular: true },
];
