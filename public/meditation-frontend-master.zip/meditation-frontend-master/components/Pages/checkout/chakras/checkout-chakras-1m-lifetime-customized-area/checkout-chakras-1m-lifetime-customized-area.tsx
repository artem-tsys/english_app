import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { PlanId } from '../../../../../constants/order.constants';
import { PopupName } from '../../../../../constants/popups.constants';
import { checkoutPageButtonTextSelector } from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { initialPlanSelected, requestPaymentPopup } from '../../../../../redux/order/order.actions';
import Button from '../../../../Shared/Elements/button/button';
import classes from '../checkout-chakras-common.module.scss';
import ChoosePlanCards from '../components/choose-plan-cards/choose-plan-cards';
import FeaturedIn from '../components/featured-in/featured-in';
import SafeCheckout from '../components/safe-checkout/safe-checkout';
import WhatYouWillGet from '../components/what-you-will-get/what-you-will-get';
import { topBannerFemaleSet } from '../images';
import { CHAKRAS_2_99_LIFETIME_PLANS } from './chakras-2-99-lifetime-plans.constants';
import localClasses from './checkout-chakras-1m-lifetime-customized-area.module.scss';

interface Props {
  paymentPopup?: PopupName;
  underButtonElement?: JSX.Element;
  PaymentButton?: JSX.Element;
}

function DefaultPaymentButton(props) {
  const buttonText = useSelector(checkoutPageButtonTextSelector);

  return (
    <Button fullWidth {...props}>
      {buttonText}
    </Button>
  );
}

function CheckoutChakras1mLifetimeCustomizedArea({
  paymentPopup = 'HORIZONTAL_PAYMENT_POPUP_WITH_LEGAL_TEXT',
  underButtonElement = null,
  PaymentButton = <DefaultPaymentButton />,
}: Props) {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(initialPlanSelected(PlanId.Chakras299Lifetime));
  }, [dispatch]);

  const onGetPlanClick = () => {
    dispatch(requestPaymentPopup(paymentPopup));
  };

  return (
    <section className={classes.checkoutCustomized}>
      <div className={localClasses.topBanner}>
        <div className={classes.topBannerRow}>
          <div className={localClasses.topBannerImageBlock}>
            <img
              className={classes.topBannerImg}
              src={topBannerFemaleSet.src}
              srcSet={topBannerFemaleSet.srcSet}
              alt=""
            />
          </div>

          <div className={localClasses.topBannerFeaturesBlock}>
            <div className={classes.containerNoDesktopPadding}>
              <WhatYouWillGet />
            </div>

            <div className={classes.topBannerSafeCheckout}>
              <div className={classes.containerNoDesktopPadding}>
                <SafeCheckout />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className={classes.choosePlan}>
        <div className={classes.container}>
          <div className={classes.choosePlanCards}>
            <ChoosePlanCards
              plans={CHAKRAS_2_99_LIFETIME_PLANS}
              onSelect={onGetPlanClick}
              underButtonElement={underButtonElement}
              dataButton="choose-plan-chakras-get-plan"
              PaymentButton={PaymentButton}
            />
          </div>
        </div>
      </div>

      <div className={classes.safeCheckout}>
        <div className={classes.container}>
          <SafeCheckout />
        </div>
      </div>

      <div className={classes.featuredIn}>
        <div className={classes.container}>
          <FeaturedIn />
        </div>
      </div>
    </section>
  );
}

export default CheckoutChakras1mLifetimeCustomizedArea;
