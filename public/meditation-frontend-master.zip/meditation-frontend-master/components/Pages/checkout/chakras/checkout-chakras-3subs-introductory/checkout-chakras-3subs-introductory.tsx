import cn from 'classnames';
import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import { CHACKRAS_OFFER_PLANS, PlanId } from '../../../../../constants/order.constants';
import { initialPlanSelected, requestPaymentPopup } from '../../../../../redux/order/order.actions';
import { createCloudinaryImageSetWithLimitedWidth } from '../../../../../utils/src-set';
import LegalIntroductoryWithModalUS from '../../../../Shared/Elements/legal/legal-introductory-with-modal-us';
import SafeCheckoutAdvanced from '../../../../Shared/Elements/safe-checkout-advanced/safe-checkout-advanced';
import classes from '../checkout-chakras-common.module.scss';
import ChoosePlan from '../components/choose-plan/choose-plan';
import FeaturedIn from '../components/featured-in/featured-in';
import WhatYouWillGet from '../components/what-you-will-get/what-you-will-get';
import { topBannerFemaleSet } from '../images';
import localClasses from './checkout-chakras-3subs-introductory.module.scss';

const CheckoutChakras3subsIntroductory = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(initialPlanSelected(PlanId.ChakrasIntroductoryOfferOneMonth));
  }, [dispatch]);

  const onGetPlanClick = () => {
    dispatch(requestPaymentPopup('INTRODUCTORY_OFFER_PAYMENT_POPUP'));
  };

  const cardsImageSet = createCloudinaryImageSetWithLimitedWidth(
    `/public/images/guaranteed-checkout-color_mxwlq3.png`,
    720,
  );
  const IntroductoryUnderButtonElement = (
    <>
      <div className={classes.legalContainer}>
        <LegalIntroductoryWithModalUS />
      </div>
      <SafeCheckoutAdvanced cardsImageSet={cardsImageSet} textClassName={classes.safeCheckoutText} />
    </>
  );
  return (
    <section className={classes.checkoutCustomized}>
      <div className={localClasses.topBanner}>
        <div className={classes.topBannerRow}>
          <div className={localClasses.topBannerImageBlock}>
            <img
              className={classes.topBannerImg}
              src={topBannerFemaleSet.src}
              srcSet={topBannerFemaleSet.srcSet}
              alt=""
            />
          </div>

          <div className={localClasses.topBannerFeaturesBlock}>
            <div className={classes.containerNoDesktopPadding}>
              <WhatYouWillGet />
            </div>
          </div>
        </div>
      </div>

      <div className={classes.choosePlan}>
        <div className={cn(classes.choosePlanIntroductory, classes.container)}>
          <ChoosePlan
            plans={CHACKRAS_OFFER_PLANS}
            onSelect={onGetPlanClick}
            showOneTimePaymentNote={false}
            dataButton="checkout-get-plan"
            underButtonElement={IntroductoryUnderButtonElement}
            style="ADVANCED"
          />
        </div>
      </div>
      <div className={classes.featuredIn}>
        <div className={classes.container}>
          <FeaturedIn />
        </div>
      </div>
    </section>
  );
};

export default CheckoutChakras3subsIntroductory;
