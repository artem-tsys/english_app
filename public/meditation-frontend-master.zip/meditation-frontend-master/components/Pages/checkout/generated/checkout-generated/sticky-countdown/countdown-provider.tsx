import React, { createContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { isProd } from '../../../../../../config';
import { ONE_MINUTE } from '../../../../../../constants/timer.constants';
import useCountDown, { TUseCountDownTime } from '../../../../../../hooks/use-countdown';
import { checkoutPageTimerSelector } from '../../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import {
  additionalDiscountCountdownCompleted,
  discountCountdownCompleted,
} from '../../../../../../redux/order/order.actions';
import {
  additionalDiscountCountdownStartedAtSelector,
  flowIdSelector,
  isDiscountAvailableSelector,
} from '../../../../../../redux/order/order.selectors';

export const CountdownContext = createContext<TUseCountDownTime>({ minutes: '00', seconds: '00' });

function CountdownProvider({ children }) {
  const dispatch = useDispatch();

  const timerValue = useSelector(checkoutPageTimerSelector);
  const flowId = useSelector(flowIdSelector);
  const isDiscountAvailable = useSelector(isDiscountAvailableSelector);
  const isAdditionalDiscountAvailable = useSelector(additionalDiscountCountdownStartedAtSelector);
  const actionCountdownCompleted = isAdditionalDiscountAvailable
    ? additionalDiscountCountdownCompleted
    : discountCountdownCompleted;

  const timerValueInMS = ONE_MINUTE * Number(timerValue || 0);
  const discountTime = isProd ? timerValueInMS : ONE_MINUTE;

  const discountCountdownKey = `discountCountdownStartedAtFlow${flowId}`;
  const additionalDiscountCountdownKey = `additionalDiscountCountdownStartedAtFlow${flowId}`;
  const localStorageKey = isAdditionalDiscountAvailable ? additionalDiscountCountdownKey : discountCountdownKey;

  const countdownStartedAt = localStorage.getItem(localStorageKey);

  const setCountdownStartedAt = (seconds: number) => {
    localStorage.setItem(localStorageKey, '' + seconds);
  };

  const onCountdownComplete = () => {
    dispatch(actionCountdownCompleted());
  };

  const time = useCountDown({
    discountTime,
    countdownStartedAt,
    isDiscountAvailable,
    isAdditionalDiscountAvailable,
    setCountdownStartedAt,
    onCountdownComplete,
  });

  const { Provider } = CountdownContext;

  return <Provider value={time}>{children}</Provider>;
}

export default CountdownProvider;
