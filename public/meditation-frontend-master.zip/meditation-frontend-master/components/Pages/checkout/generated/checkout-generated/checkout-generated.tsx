import cn from 'classnames';
import React, { cloneElement, ReactElement, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { PopupName } from '../../../../../constants/popups.constants';
import { Trans } from '../../../../../i18n';
import { checkoutAction, checkoutGetMyPlanBottomClickAction } from '../../../../../redux/analytics/analytics.actions';
import { checkoutPageButtonTextSelector } from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { discountCountdownStarted, requestPaymentPopup } from '../../../../../redux/order/order.actions';
import {
  isAdditionalDiscountAppliedSelector,
  isOrderFetchedSelector,
  isOrderPaidSelector,
  orderHashSelector,
} from '../../../../../redux/order/order.selectors';
import { notifyOnError } from '../../../../../utils/error-tracking';
import useFunnel from '../../../../../utils/funnel-navigation/react/use-funnel-hook';
import Router, { useRouter } from '../../../../../utils/next-with-i18n/router';
import Header from '../../../../Generic/page/header/header';
import Button from '../../../../Shared/Elements/button/button';
import AdditionalDiscountChakrasCustomizedArea from '../../chakras/additional-discount-chakras-customized-area/additional-discount-chakras-customized-area';
import CheckoutChakras3subsCustomizedArea from '../../chakras/checkout-chakras-3subs-customized-area/checkout-chakras-3subs-customized-area';
import CountdownGenerated from '../../chakras/components/countdown-generated/countdown-generated';
import HeaderWithCountdownDesktop from '../../chakras/components/header-with-countdown-desktop/header-with-countdown-desktop';
import AdditionalDiscountGenerated from '../additional-discount-generated/additional-discount-generated';
import PaidOrderMessage from '../additional-discount-generated/paid-order-message/paid-order-message';
import CheckoutGeneratedContent from '../checkout-generated-content/checkout-generated-content';
import classes from './checkout-generated.module.scss';
import CountdownProvider from './sticky-countdown/countdown-provider';
import StickyCountdown from './sticky-countdown/sticky-countdown';

interface Props {
  CustomizedArea?: ReactElement;
  AdditionalDiscountCustomizedArea?: ReactElement;
  paymentPopup?: PopupName;
  shouldShowSuccessStory?: boolean;
  shouldShowCountdown?: boolean;
  Countdown?: JSX.Element;
  stickyHeader?: boolean;
  underButtonElement?: JSX.Element;
  PaymentButton?: JSX.Element;
  AdditionalDiscountBanner?: JSX.Element;
  AdditionalDiscountHeader?: JSX.Element;
}

function DefaultPaymentButton(props) {
  const buttonText = useSelector(checkoutPageButtonTextSelector);

  return (
    <Button fullWidth {...props}>
      {buttonText}
    </Button>
  );
}

const CheckoutGenerated = ({
  CustomizedArea = <CheckoutChakras3subsCustomizedArea />,
  AdditionalDiscountCustomizedArea = <AdditionalDiscountChakrasCustomizedArea />,
  paymentPopup = 'HORIZONTAL_PAYMENT_POPUP_WITH_LEGAL_TEXT',
  shouldShowSuccessStory = true,
  shouldShowCountdown = true,
  underButtonElement = null,
  stickyHeader = false,
  Countdown = <CountdownGenerated />,
  PaymentButton = <DefaultPaymentButton />,
  AdditionalDiscountBanner,
  AdditionalDiscountHeader,
}: Props) => {
  const dispatch = useDispatch();
  const isAdditionalDiscountApplied = useSelector(isAdditionalDiscountAppliedSelector);
  const isOrderFetched = useSelector(isOrderFetchedSelector);
  const isOrderPaid = useSelector(isOrderPaidSelector);
  const [shouldShowPaidMessage, setShouldShowPaidMessage] = useState(false);
  const { upsellPage } = useFunnel();
  const orderHash = useSelector(orderHashSelector);
  const router = useRouter();
  const showPaymentPopup = router.query.showPaymentPopup;

  useEffect(() => {
    dispatch(checkoutAction('purchasing'));
  }, [dispatch]);

  useEffect(() => {
    try {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth',
      });
    } catch (e) {
      notifyOnError('[Checkout] No scrollTo method on window object');
    }
  }, []);

  useEffect(() => {
    dispatch(discountCountdownStarted());
  }, [dispatch]);

  const onGetPlanClick = () => {
    dispatch(checkoutGetMyPlanBottomClickAction());
    dispatch(requestPaymentPopup(paymentPopup));
  };

  useEffect(() => {
    if (isOrderPaid) {
      setShouldShowPaidMessage(true);
    }
  }, [isOrderPaid]);

  useEffect(() => {
    if (showPaymentPopup && isOrderFetched) {
      dispatch(requestPaymentPopup(paymentPopup));
    }
  }, [showPaymentPopup, isOrderFetched]);

  if (shouldShowPaidMessage) {
    return (
      <PaidOrderMessage
        onSubmit={() => {
          Router.push(`${upsellPage}?order=${orderHash}`);
        }}
      />
    );
  }

  if (isAdditionalDiscountApplied) {
    return (
      <AdditionalDiscountGenerated
        CustomizedArea={AdditionalDiscountCustomizedArea}
        paymentPopup={paymentPopup}
        shouldShowSuccessStory={shouldShowSuccessStory}
        underButtonElement={underButtonElement}
        shouldShowCountdown={shouldShowCountdown}
        PaymentButton={PaymentButton}
        Banner={AdditionalDiscountBanner}
        Header={AdditionalDiscountHeader}
      />
    );
  }

  return (
    <CountdownProvider>
      <main className={classes.main}>
        {stickyHeader && (
          <div className={cn(classes.desktopOnly, classes.headerWithCountdown)}>
            <HeaderWithCountdownDesktop
              isCountdownHidden={false}
              Countdown={cloneElement(Countdown, {
                onCtaClick: onGetPlanClick,
              })}
            />
          </div>
        )}
        <Header className={stickyHeader && classes.mobileOnly} />
        <section className={classes.titleSection}>
          <div className={classes.container}>
            <span className={classes.title}>
              {
                // i18n:extract t('checkoutGenerated:title','Unlock your <0>chakras</0> right now!')
              }
              <Trans i18nKey="checkoutGenerated:title" components={[<b key="0" />]} />
            </span>
            <span className={classes.subTitle}>
              {
                // i18n:extract t('checkoutGenerated:subTitle10M','Join over <0>10,000,000</0> members of BetterMe family')
              }
              <Trans i18nKey="checkoutGenerated:subTitle10M" components={[<b key="0" />]} />
            </span>
          </div>
        </section>
        {stickyHeader && (
          <div className={classes.mobileOnly}>{cloneElement(Countdown, { onCtaClick: onGetPlanClick })}</div>
        )}

        {shouldShowCountdown && <StickyCountdown />}

        {CustomizedArea}

        <section className={classes.mainSection}>
          <CheckoutGeneratedContent shouldShowSuccessStory={shouldShowSuccessStory} />

          <div className={classes.btnBlock}>
            <div className={classes.container}>
              {PaymentButton &&
                cloneElement(PaymentButton, { onClick: onGetPlanClick, dataButton: 'checkout-get-plan' })}

              {underButtonElement}
            </div>
          </div>
        </section>
      </main>
    </CountdownProvider>
  );
};

export default CheckoutGenerated;
