import React, { useContext } from 'react';
import useIsInViewport from 'use-is-in-viewport';

import { HEADER_HEIGHT } from '../../../../../../constants/header.constants';
import { Trans } from '../../../../../../i18n';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import { CountdownContext } from './countdown-provider';
import classes from './sticky-countdown.module.scss';

function Countdown() {
  const { t } = useTranslation();
  const time = useContext(CountdownContext);

  if (!time) {
    return null;
  }

  return (
    <div className={classes.container}>
      <div className={classes.countdownText}>
        {/* i18n:extract t('countdown:reservedPrice', `<0>Reserved</0> price for`) */}
        <Trans i18nKey="countdown:reservedPrice" components={[<span key="0" />]} />
        <span className={classes.countdownTimeUnit}>
          <span>{time.minutes}</span>
          <span>:</span>
          <span>{time.seconds}</span>
        </span>
        {t('countdown:mins', 'mins')}
      </div>
    </div>
  );
}

function StickyCountdown() {
  const [isInViewport, ref] = useIsInViewport({
    modTop: `-${HEADER_HEIGHT}px`,
  });

  return (
    <>
      <div ref={ref} className={classes.countdown}>
        <Countdown />
      </div>
      {!isInViewport && (
        <div className={classes.fixedCountdown}>
          <Countdown />
        </div>
      )}
    </>
  );
}

export default StickyCountdown;
