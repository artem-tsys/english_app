import React from 'react';

import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import saveStringLineBreaks from '../../../../../utils/saveStringLineBreaks.util';
import { ImageSet } from '../../../../../utils/src-set';
import { instaLogoSet, user1ImageSet, user2ImageSet, user3ImageSet } from './images';
import classes from './insta-stories.module.scss';

export interface User {
  image: ImageSet;
  name: string;
  text: string;
}

interface InstaStoriesProps {
  title?: string;
  instaLogo?: ImageSet;
  users?: User[];
}

interface InstaQuoteProps {
  user: User;
  instaLogo: ImageSet;
}

const InstaQuote = ({ user, instaLogo }: InstaQuoteProps) => (
  <article className={classes.instaQuote}>
    <div className={classes.instaQuoteHeader}>
      <span className={classes.instaQuoteUser}>
        <img src={user.image.src} srcSet={user.image.srcSet} className={classes.instaQuoteImage} alt="" />
        {user.name}
      </span>
      <img src={instaLogo.src} srcSet={instaLogo.srcSet} className={classes.instaQuoteInstagramLogo} alt="" />
    </div>
    <span className={classes.instaQuoteText}>{saveStringLineBreaks(user.text)}</span>
  </article>
);

const InstaStories = ({ title, instaLogo, users }: InstaStoriesProps) => {
  const { t } = useTranslation();
  const header = title || t('instaStories:title', 'Users love our plans');
  const logo = instaLogo || instaLogoSet;
  const instaUsers = users || [
    {
      image: user1ImageSet,
      name: '@ilsebriejer',
      text: t(
        'instaStories:story1',
        `I do enjoy this plan a lot. It thoroughly made me enjoy exercising more and I have lost 14 lbs in a month. This plan really does help out if you were a beginner like me with working out and losing weight. Thank you `,
      ),
    },
    {
      image: user2ImageSet,
      name: '@jesus_gcf',
      text: t(
        'instaStories:story2',
        `That’s the program that I used to fix my body. It’s really good because you can use it on gym or at home and also choose your body part. And also that you got nutrition section`,
      ),
    },
    {
      image: user3ImageSet,
      name: '@pooshiah',
      text: t(
        'instaStories:story3',
        `I literally get all my home base work out here and it works, no need to go to gym to achieve fit and toned body.`,
      ),
    },
  ];

  return (
    <section className={classes.container}>
      <h3 className={classes.title}>{header}</h3>
      {instaUsers.map((user) => (
        <InstaQuote user={user} instaLogo={logo} key={user.name} />
      ))}
    </section>
  );
};

export default InstaStories;
