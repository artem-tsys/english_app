import createCloudinaryImageSet from '../../../../../utils/src-set';

export const user1ImageSet = createCloudinaryImageSet(`/public/images/user-1/user-1-4x.png`);
export const user2ImageSet = createCloudinaryImageSet('Ellipse_3_nte4nf');
export const user3ImageSet = createCloudinaryImageSet(`/public/images/user-3/user-3-4x.png`);
export const instaLogoSet = createCloudinaryImageSet(`/public/images/insta-logo/insta-logo-4x.png`);
