import createCloudinaryImageSet from '../../../../../../utils/src-set';

export const giftSet = createCloudinaryImageSet(`/public/images/small-gift/small-gift-4x.png`);
