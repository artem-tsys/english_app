import { createCloudinaryImageSet } from '../../../../../../utils/src-set';

export const creditCardImageSet = createCloudinaryImageSet('u1F4B3_1_o2qrsb');
