import React from 'react';
import { useSelector } from 'react-redux';

import { discountTitleSelector } from '../../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import Header from '../../../../../Generic/page/header/header';
import TransparentAbsoluteHeader from '../../../../../Generic/page/transparent-absolute-header/transparent-absolute-header';
import classes from './additional-discount-generated-banner.module.scss';
import { giftSet } from './images';

function AdditionalDiscountGeneratedBanner() {
  const discountTitle = useSelector(discountTitleSelector);

  return (
    <>
      <div className={classes.bannerMobile}>
        <TransparentAbsoluteHeader />
        <img className={classes.bannerMobileImage} src={giftSet.src} srcSet={giftSet.srcSet} alt="" />
        <div className={classes.bannerMobileContent}>
          <h1 className={classes.bannerMobileTitle}>{discountTitle}</h1>
        </div>
      </div>

      <div className={classes.bannerDesktop}>
        <Header className={classes.headerDesktop} />
        <div className={classes.container}>
          <h1 className={classes.bannerDesktopTitle}>{discountTitle}</h1>
        </div>
      </div>
    </>
  );
}

export default AdditionalDiscountGeneratedBanner;
