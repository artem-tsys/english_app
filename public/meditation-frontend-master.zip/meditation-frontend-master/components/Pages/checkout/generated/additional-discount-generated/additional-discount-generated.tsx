import React, { cloneElement, ReactElement, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { PopupName } from '../../../../../constants/popups.constants';
import { checkoutGetMyPlanBottomClickAction } from '../../../../../redux/analytics/analytics.actions';
import { checkoutPageButtonTextSelector } from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { requestPaymentPopup } from '../../../../../redux/order/order.actions';
import FooterOverlay from '../../../../Generic/footer-overlay/footer-overlay';
import AdditionalDiscountCountdown from '../../../../Shared/Elements/additional-discount-countdown/additional-discount-countdown';
import Button from '../../../../Shared/Elements/button/button';
import CheckoutGeneratedContent from '../checkout-generated-content/checkout-generated-content';
import CountdownProvider from '../checkout-generated/sticky-countdown/countdown-provider';
import AdditionalDiscountGeneratedBanner from './additional-discount-generated-banner/additional-discount-generated-banner';
import classes from './additional-discount-generated.module.scss';

interface Props {
  CustomizedArea: ReactElement;
  paymentPopup: PopupName;
  shouldShowCountdown?: boolean;
  shouldShowSuccessStory?: boolean;
  underButtonElement?: JSX.Element;
  PaymentButton?: JSX.Element;
  Banner?: JSX.Element;
  Header?: JSX.Element;
}

function DefaultPaymentButton(props) {
  const buttonText = useSelector(checkoutPageButtonTextSelector);

  return (
    <Button fullWidth {...props}>
      {buttonText}
    </Button>
  );
}

const AdditionalDiscountGenerated = ({
  CustomizedArea,
  paymentPopup,
  shouldShowCountdown = true,
  shouldShowSuccessStory = true,
  underButtonElement = null,
  PaymentButton = <DefaultPaymentButton />,
  Banner = <AdditionalDiscountGeneratedBanner />,
  Header,
}: Props) => {
  const dispatch = useDispatch();

  useEffect(() => {
    try {
      window.scrollTo(0, 0);
    } catch (e) {}
  }, []);

  const onGetPlanClick = () => {
    dispatch(requestPaymentPopup(paymentPopup));
    dispatch(checkoutGetMyPlanBottomClickAction());
  };

  return (
    <CountdownProvider>
      {Header}
      {Banner}
      {CustomizedArea}

      <section className={classes.mainSection}>
        <CheckoutGeneratedContent shouldShowSuccessStory={shouldShowSuccessStory} />

        <div className={classes.btnBlock}>
          <div className={classes.container}>
            {PaymentButton && cloneElement(PaymentButton, { onClick: onGetPlanClick, dataButton: 'checkout-get-plan' })}

            {underButtonElement}
          </div>
        </div>
      </section>

      {shouldShowCountdown && (
        <FooterOverlay>
          <AdditionalDiscountCountdown />
        </FooterOverlay>
      )}
    </CountdownProvider>
  );
};

export default AdditionalDiscountGenerated;
