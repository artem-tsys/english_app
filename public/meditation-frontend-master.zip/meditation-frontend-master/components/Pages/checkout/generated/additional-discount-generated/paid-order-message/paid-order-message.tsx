import React from 'react';

import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import Header from '../../../../../Generic/page/header/header';
import Button from '../../../../../Shared/Elements/button/button';
import { creditCardImageSet } from './images';
import classes from './paid-order-message.module.scss';

const PaidOrderMessage = ({ onSubmit }) => {
  const { t } = useTranslation();

  return (
    <div className={classes.container}>
      <Header />
      <div className={classes.circle}>
        <img className={classes.cardImage} src={creditCardImageSet.src} srcSet={creditCardImageSet.srcSet} />
      </div>
      <p className={classes.text}>
        {t(
          'paidOrderMessage:receivedPayment',
          'We have already received your payment. Please, proceed with your registration.',
        )}
      </p>
      <Button onClick={onSubmit} dataButton="paid-order-message-got-it">
        {t('paidOrderMessage:gotIt', 'GOT IT!')}
      </Button>
    </div>
  );
};

export default PaidOrderMessage;
