import React from 'react';

import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import saveStringLineBreaks from '../../../../../utils/saveStringLineBreaks.util';
import classes from './often-ask.module.scss';

const DEFAULT_QUESTIONS = [
  {
    title: {
      // i18n:extract t('oftenAsk:title1', 'What happens after I order?')
      key: 'oftenAsk:title1',
      value: 'What happens after I order?',
    },
    answer: {
      // i18n:extract t('oftenAsk:answer1_1', 'After you place your order we get to work! Based on the questions you answered in the quiz, our algorithms will craft your plan tailored to your personal nutrition requirements. All plans are verified by a nutritionist so you can be certain the plan you get is the best match for you.')
      key: 'oftenAsk:answer1_1',
      value:
        'After you place your order we get to work! Based on the questions you answered in the quiz, our algorithms will craft your plan tailored to your personal nutrition requirements. All plans are verified by a nutritionist so you can be certain the plan you get is the best match for you.',
    },
  },
  {
    title: {
      // i18n:extract t('oftenAsk:title2', 'When do I get my plan?')
      key: 'oftenAsk:title2',
      value: 'When do I get my plan?',
    },
    answer: {
      // i18n:extract t('oftenAsk:answer2', 'Our every plan is personalized and our nutritionists work hard to make sure you would love them. Normally, it takes up to 2 hours for your plan to be delivered to your email.')
      key: 'oftenAsk:answer2',
      value:
        'Our every plan is personalized and our nutritionists work hard to make sure you would love them. Normally, it takes up to 2 hours for your plan to be delivered to your email.',
    },
  },
];

export interface QuestionType {
  title: {
    key: string;
    value: string;
  };
  answer: {
    key: string;
    value: string;
  };
}

export const getTranslatedQuestions = (t: (key: string, value: string) => string, questions: QuestionType[]) =>
  questions.map((item) => ({
    title: t(item.title.key, item.title.value),
    answer: t(item.answer.key, item.answer.value),
  }));

interface OftenAskProps {
  questions?: {
    title: string;
    answer: string;
  }[];
  title?: string;
}

const OftenAsk = ({ questions, title }: OftenAskProps) => {
  const { t } = useTranslation();

  const translatedQuestions = getTranslatedQuestions(t, DEFAULT_QUESTIONS);
  const questionList = questions || translatedQuestions;

  return (
    <div className={classes.container}>
      <h3 className={classes.title}>{title || t('oftenAsk:title', 'People Often Ask')}</h3>
      <ul className={classes.questionsList}>
        {questionList.map(({ title, answer }) => {
          return (
            <li className={classes.questionsListItem} key={title}>
              <span className={classes.questionTitle}>{title}</span>
              <span className={classes.questionAnswer}>{saveStringLineBreaks(answer)}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default OftenAsk;
