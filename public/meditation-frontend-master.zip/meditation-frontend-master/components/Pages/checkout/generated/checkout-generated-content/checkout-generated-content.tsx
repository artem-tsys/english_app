import React, { ReactElement } from 'react';
import { useSelector } from 'react-redux';

import {
  checkoutLegalTextSelector,
  checkoutPageInstaFeedbacksSelector,
  checkoutPageMainFeedbackImageSelector,
  checkoutPageMainFeedbackNameSelector,
  checkoutPageMainFeedbackSelector,
  checkoutPageMoneyBackGuaranteeSelector,
  checkoutPageOftenAskSelector,
  checkoutPagePlanTypeSelector,
} from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import LegalTextTrial from '../../../../Shared/Elements/legal/legal-text-trial';
import { user1ImageSet, user2ImageSet, user3ImageSet } from '../insta-stories/images';
import InstaStories from '../insta-stories/insta-stories';
import MoneyBackGuarantee from '../money-back-guarantee/money-back-guarantee';
import OftenAsk from '../often-ask/often-ask';
import SuccessStory from '../success-story/success-story';
import classes from './checkout-generated-content.module.scss';

interface Props {
  shouldShowSuccessStory?: boolean;
}

const CheckoutGeneratedContent = ({ shouldShowSuccessStory = true }: Props): ReactElement => {
  const text = useSelector(checkoutPageMainFeedbackSelector);
  const image = useSelector(checkoutPageMainFeedbackImageSelector);
  const planType = useSelector(checkoutPagePlanTypeSelector);
  const oftenAskQuestions = useSelector(checkoutPageOftenAskSelector);
  const instaFeedbacks = useSelector(checkoutPageInstaFeedbacksSelector);
  const moneyBackGuaranteeProps = useSelector(checkoutPageMoneyBackGuaranteeSelector);
  const legalTextValue = useSelector(checkoutLegalTextSelector);
  const name = useSelector(checkoutPageMainFeedbackNameSelector);
  const instaUsers = [
    {
      image: user1ImageSet,
      name: '@ilsebriejer',
      text: instaFeedbacks.feedback1,
    },
    {
      image: user2ImageSet,
      name: '@cyrilaesthetics',
      text: instaFeedbacks.feedback2,
    },
    {
      image: user3ImageSet,
      name: '@pooshiah',
      text: instaFeedbacks.feedback3,
    },
  ];

  return (
    <>
      <div className={classes.main}>
        <div className={classes.container}>
          <div className={classes.row}>
            {shouldShowSuccessStory && (
              <div className={classes.successStory}>
                <SuccessStory planType={planType} image={image} name={name} text={text} />
              </div>
            )}

            <div className={shouldShowSuccessStory ? classes.oftenAsk : classes.oftenAskNoSuccessStory}>
              <OftenAsk questions={oftenAskQuestions} />
            </div>

            <div className={classes.instaUsers}>
              <InstaStories users={instaUsers} />
            </div>
          </div>
        </div>
      </div>

      <div className={classes.moneyBackGuarantee}>
        <div className={classes.container}>
          <MoneyBackGuarantee {...moneyBackGuaranteeProps} />

          {legalTextValue && (
            <div className={classes.legalTextTrial}>
              <LegalTextTrial text={legalTextValue} />
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default CheckoutGeneratedContent;
