import React from 'react';

import { useTranslation } from '../../../../../i18n';
import saveStringLineBreaks from '../../../../../utils/saveStringLineBreaks.util';
import { ImageSet } from '../../../../../utils/src-set';
import classes from './success-story.module.scss';

export interface SuccessStoryProps {
  planType: string;
  image: ImageSet;
  name: string;
  text: string;
}
function SuccessStory({ planType, image, name, text }: SuccessStoryProps) {
  const { t } = useTranslation();
  return (
    <div className={classes.container}>
      <h3 className={classes.title}>
        {t('successStory:title', 'People just like you achieved great results using our')} <b>{planType}</b>
      </h3>

      {image && <img className={classes.successImg} src={image.src} srcSet={image.srcSet} alt="" />}
      <span className={classes.subTitle}>{name}</span>

      <span className={classes.text}>{saveStringLineBreaks(text)}</span>
    </div>
  );
}

export default SuccessStory;
