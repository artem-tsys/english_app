import React, { useState } from 'react';
import { useSelector } from 'react-redux';

import { useTranslation } from '../../../../../i18n';
import { checkoutPageAppStoreReviewsSelector } from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import saveStringLineBreaks from '../../../../../utils/saveStringLineBreaks.util';
import createCloudinaryImageSet from '../../../../../utils/src-set';
import Modal from '../../../../Shared/Elements/modals/modal';
import classes from './app-store-reviews.module.scss';

const fullfilledStar = createCloudinaryImageSet('Star_5start_cgispk');
const unfullfilledStar = createCloudinaryImageSet('Star_5unfilledStar_p9jnut');

const MAX_STARS_COUNT = 5;

interface ReviewProps {
  title: string;
  review: string;
  stars: '0' | '1' | '2' | '3' | '4' | '5';
  name: string;
  date: string;
  onExpand?: () => void;
}

const Review: React.FC<ReviewProps> = ({ title, review, stars = '5', name, date, onExpand }) => {
  const numberOfStars = parseInt(stars);
  const isExpandable = Boolean(onExpand);
  const { t } = useTranslation();

  return (
    <>
      <div className={classes.title}>
        <div className={classes.titleGroup}>
          <h3 className={classes.titleText}>{title}</h3>
          <span className={classes.dateNameText}>{date}</span>
        </div>
        <div className={classes.titleGroup}>
          <div className={classes.stars}>
            {Array(...Array(numberOfStars)).map((_, index) => (
              <img key={index} src={fullfilledStar.src} />
            ))}
            {Array(...Array(MAX_STARS_COUNT - numberOfStars)).map((_, index) => (
              <img src={unfullfilledStar.src} key={index} />
            ))}
          </div>
          <span className={classes.dateNameText}>{name}</span>
        </div>
      </div>
      {isExpandable ? (
        <div className={classes.reviewExpandable}>
          {saveStringLineBreaks(review)}
          <button
            className={classes.expandButton}
            onClick={(e) => {
              e.preventDefault();
              onExpand();
            }}
          >
            {t('checkoutGenerated:moreButton', 'more')}
          </button>
        </div>
      ) : (
        <div className={classes.review}>{saveStringLineBreaks(review)}</div>
      )}
    </>
  );
};

export const ReviewContainer = (props) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className={classes.appStoreReview}>
      <Review {...props} onExpand={() => setIsExpanded(true)} />

      {isExpanded && (
        <Modal isOpen={true} onClose={() => setIsExpanded(false)}>
          <Review {...props} />
        </Modal>
      )}
    </div>
  );
};

const DefaultTitle = () => {
  const { t } = useTranslation();

  return (
    <h1 className={classes.appStoreReviewsTitle}>
      {t('checkoutGenerated:appStoreReviewsTitle', 'Users love our plans')}
    </h1>
  );
};

const DefaultSubTitle = () => {
  const { t } = useTranslation();

  return (
    <div className={classes.appStoreReviewsSubtitle}>
      {t('checkoutGenerated:appStoreReviewsSubtitle', "Here's what people are saying about BetterMe")}
    </div>
  );
};

interface IAppStoreReviewsProps {
  Title?: React.ComponentType;
  SubTitle?: React.ComponentType;
}

const AppStoreReviews: React.FC<IAppStoreReviewsProps> = ({ Title = DefaultTitle, SubTitle = DefaultSubTitle }) => {
  const reviews = useSelector(checkoutPageAppStoreReviewsSelector);
  if (!reviews || !reviews.length) {
    return null;
  }

  return (
    <div className={classes.appStoreReviews}>
      <Title />
      <SubTitle />
      {reviews.map((review) => (
        <ReviewContainer key={review.title} {...review} />
      ))}
    </div>
  );
};

export default AppStoreReviews;
