import React from 'react';

import classes from './button.module.scss';

const Button = ({ children, fullWidth = true, dataButton = 'general', ...restProps }) => {
  return (
    <button
      className={fullWidth ? classes.greenWideButton : classes.greenButton}
      data-button={dataButton}
      {...restProps}
    >
      {children}
    </button>
  );
};

export default Button;
