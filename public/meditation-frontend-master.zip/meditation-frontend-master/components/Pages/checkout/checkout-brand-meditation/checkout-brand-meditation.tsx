import {
  Button,
  ButtonColorModeType,
  CheckoutBanner,
  DesktopMode,
  FaqAccordion,
  HEADER_HEIGHT_DESKTOP,
  HEADER_HEIGHT_MOBILE,
  HEADER_HEIGHT_MOBILE_WITH_BUTTON,
  MobileMode,
  WhatYouGet,
  WhatYouGetType,
} from '@betterme-dev/web-ui-kit';
import React, { useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Gender, PlanId } from '../../../../constants/order.constants';
import useDeviceMode from '../../../../hooks/use-device-mode.hook';
import { checkoutAction, checkoutGetMyPlanTopClickAction } from '../../../../redux/analytics/analytics.actions';
import {
  checkoutPageButtonTextSelector,
  checkoutPageHeaderImageDesktopManSelector,
  checkoutPageHeaderImageDesktopWomanSelector,
  checkoutPageHeaderImageFemaleAfterMobileSelector,
  checkoutPageHeaderImageFemaleBeforeMobileSelector,
  checkoutPageHeaderImageMaleAfterMobileSelector,
  checkoutPageHeaderImageMaleBeforeMobileSelector,
  checkoutPageOftenAskSelector,
  checkoutPageSubtitle,
  checkoutPageTitleSelector,
  checkoutPageWhatYouGetImageWomanSelector,
  checkoutPageWhatYouGetListSelector,
  checkoutPageWhatYouGetTitleSelector,
  generalPlansSelector,
  plansIdsSelector,
} from '../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { planSelected, requestPaymentPopup } from '../../../../redux/order/order.actions';
import { isPaymentRequestLoadingSelector, selectedPlanIdSelector } from '../../../../redux/order/order.selectors';
import { setSkipUpsell } from '../../../../redux/upsell/upsell.actions';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import { shortcodesConfig } from '../../../../utils/shortcodes';
import shortcodeToTags from '../../../../utils/shortcodes/shortcode-to-tags.util';
import { createCloudinaryImageSetWithLimitedWidth } from '../../../../utils/src-set';
import ContentContainer from '../../../Generic/content-container';
import { cardsImageSet } from '../../../Shared/Elements/choose-plan-only-buttons-detailed/images';
import Loader from '../../../Shared/Elements/loader/loader';
import SafeCheckoutAdvanced from '../../../Shared/Elements/safe-checkout-advanced/safe-checkout-advanced';
import WebUiKitHeader from '../../../web-ui-kit-header/web-ui-kit-header';
import FeaturedIn from '../chakras/components/featured-in/featured-in';
import AppStoreReviews from '../generated/app-store-reviews/app-store-reviews';
import classes from './checkout-brand-meditation.module.scss';
import PaymentOffer from './components/payment-offer';

const CheckoutBrandMeditation = () => {
  const deviceMode = useDeviceMode();
  const { t, lang } = useTranslation();
  const isDesktop = deviceMode === 'desktop';
  const showLoader = useSelector(isPaymentRequestLoadingSelector);

  const title = useSelector(checkoutPageTitleSelector);
  const subtitle = useSelector(checkoutPageSubtitle);

  const topBannerDesktopManString = useSelector(checkoutPageHeaderImageDesktopManSelector);
  const topBannerDesktopMan = createCloudinaryImageSetWithLimitedWidth(topBannerDesktopManString, 532);

  const topBannerDesktopWomanString = useSelector(checkoutPageHeaderImageDesktopWomanSelector);
  const topBannerDesktopWoman = createCloudinaryImageSetWithLimitedWidth(topBannerDesktopWomanString, 532);

  const topBannerMobileBeforeManString = useSelector(checkoutPageHeaderImageMaleBeforeMobileSelector);
  const topBannerMobileBeforeMan = createCloudinaryImageSetWithLimitedWidth(topBannerMobileBeforeManString, 288);

  const topBannerMobileBeforeWomanString = useSelector(checkoutPageHeaderImageFemaleBeforeMobileSelector);
  const topBannerMobileBeforeWoman = createCloudinaryImageSetWithLimitedWidth(topBannerMobileBeforeWomanString, 288);

  const topBannerMobileAfterWomanString = useSelector(checkoutPageHeaderImageFemaleAfterMobileSelector);
  const topBannerMobileAfterWoman = createCloudinaryImageSetWithLimitedWidth(topBannerMobileAfterWomanString, 288);

  const topBannerMobileAfterManString = useSelector(checkoutPageHeaderImageMaleAfterMobileSelector);
  const topBannerMobileAfterMan = createCloudinaryImageSetWithLimitedWidth(topBannerMobileAfterManString, 288);

  const whatYouGetBannerString = useSelector(checkoutPageWhatYouGetImageWomanSelector);
  const whatYouGetBanner = createCloudinaryImageSetWithLimitedWidth(whatYouGetBannerString, 592);

  const whatYouGetList = useSelector(checkoutPageWhatYouGetListSelector);

  const whatYouGetTitle = useSelector(checkoutPageWhatYouGetTitleSelector);

  const oftenAskQuestions = useSelector(checkoutPageOftenAskSelector);

  const buttonTextConstructor = useSelector(checkoutPageButtonTextSelector);
  const buttonText = buttonTextConstructor ?? t('checkout:getPlanBtnUpperCase', 'GET MY PLAN');

  const plansIds = useSelector(plansIdsSelector);
  const plans = useSelector(generalPlansSelector);

  const planId = useSelector(selectedPlanIdSelector);
  const selectedPlan = plans.find((plan) => plan.id === planId);
  const dispatch = useDispatch();

  const isUkraine = lang === 'uk';

  useEffect(() => {
    if (isUkraine) {
      dispatch(planSelected(PlanId.MindOneMonthFree));
      return;
    }
    if (plansIds?.length) {
      dispatch(planSelected(plansIds[0]));
    }
  }, [plansIds, dispatch, lang]);

  const handleGetPlanClick = () => {
    dispatch(requestPaymentPopup('INTRODUCTORY_OFFER_PAYMENT_POPUP_WITH_BREAKDOWN'));
    dispatch(checkoutGetMyPlanTopClickAction());
  };
  const paymentBlockRef = useRef(null);

  const handleBtnClick = (): void => {
    const headerHeight = isDesktop ? HEADER_HEIGHT_DESKTOP : HEADER_HEIGHT_MOBILE_WITH_BUTTON;
    if (paymentBlockRef.current) {
      window.scrollTo({
        top: paymentBlockRef.current.offsetTop - headerHeight,
        left: 0,
        behavior: 'smooth',
      });
    }
  };

  useEffect(() => {
    dispatch(checkoutAction('purchasing'));
    dispatch(setSkipUpsell());
  }, []);

  return (
    <div>
      <Loader isShown={showLoader} className={classes.loader} />
      <div className={classes.header}>
        <WebUiKitHeader
          desktopConfig={{ mode: DesktopMode.DesktopDefault }}
          mobileConfig={{ mode: MobileMode.MobileDefault }}
        />
      </div>

      <div style={{ paddingTop: isDesktop ? `${HEADER_HEIGHT_DESKTOP}px` : `${HEADER_HEIGHT_MOBILE}px` }}>
        <CheckoutBanner
          mobileConfig={{
            images: {
              male: { before: topBannerMobileBeforeMan, after: topBannerMobileAfterMan },
              female: {
                before: topBannerMobileBeforeWoman,
                after: topBannerMobileAfterWoman,
              },
            },
            discountText: null,
          }}
          desktopConfig={{
            desktopImages: {
              male: topBannerDesktopMan,
              female: topBannerDesktopWoman,
            },
            handleBtnClick: handleBtnClick,
            pulsingButtonMode: ButtonColorModeType.SECONDARY,
            paymentButtonLabel: t('checkout:getPlanBtnUpperCase', 'GET MY PLAN'),
            featuredInLabel: t('checkoutTotallyGenerated:featuredIn', 'Featured in:'),
          }}
          gender={Gender.Female}
          title={<>{shortcodeToTags(title, shortcodesConfig)}</>}
          subtitle={<>{shortcodeToTags(subtitle, shortcodesConfig)}</>}
        />
      </div>

      <ContentContainer>
        <div className={classes.whatYouGet}>
          <WhatYouGet
            whatYouGetType={WhatYouGetType.BulletedList}
            titleText={whatYouGetTitle}
            image={whatYouGetBanner}
            listItems={whatYouGetList}
          />
        </div>
      </ContentContainer>
      <div className={classes.choosePlan} ref={paymentBlockRef}>
        <PaymentOffer onClick={handleGetPlanClick} selectedPlan={selectedPlan} />
        <SafeCheckoutAdvanced cardsImageSet={cardsImageSet} textClassName={classes.safeCheckoutText} />
      </div>
      <div className={classes.featuredIn}>
        <FeaturedIn />
      </div>

      <div className={classes.lowerContainer}>
        <div className={classes.feedbacks}>
          <div className={classes.appStoreReviews}>
            <ContentContainer>
              <AppStoreReviews />
            </ContentContainer>
          </div>
          <div className={classes.faqAccordion}>
            <ContentContainer>
              <div className={classes.faqAccordionInner}>
                <FaqAccordion
                  questions={oftenAskQuestions}
                  title={t('checkoutTotallyGenerated:peopleOftenAsk', 'People often ask')}
                />
              </div>
            </ContentContainer>
          </div>
        </div>

        <div className={classes.button}>
          <Button label={buttonText} onClick={handleGetPlanClick} colorMode={ButtonColorModeType.PRIMARY} isPulsing />
        </div>

        <ContentContainer>
          <div className={classes.legal}>
            <div className={classes.underButtonLegalText}>
              <div className={classes.legalAddress}>
                {t(
                  'legal:BetterMeLimitedAndAddress',
                  'BetterMe Limited | Themistokli Dervi 39, 1st floor, Office 104, 1066, Nicosia, Cyprus',
                )}
              </div>
            </div>
          </div>
        </ContentContainer>
      </div>
    </div>
  );
};

export const underButtonLegalTextClass = classes.underButtonLegalText;
export default CheckoutBrandMeditation;
