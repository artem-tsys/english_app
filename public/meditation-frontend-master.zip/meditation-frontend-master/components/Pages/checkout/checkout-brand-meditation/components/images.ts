import { createCloudinaryImageSetWithLimitedWidth } from '../../../../../utils/src-set';

export const bannerDesktop = createCloudinaryImageSetWithLimitedWidth('Female_mz2thg', 532);
