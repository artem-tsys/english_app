export { default } from './payment-offer';
