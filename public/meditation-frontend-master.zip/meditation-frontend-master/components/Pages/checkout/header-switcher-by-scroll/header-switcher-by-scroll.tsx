import React, { ReactElement, useEffect, useState } from 'react';

interface IHeaderSwitcherByScrollProps {
  isInViewport: boolean;
  FirstHeader: ReactElement;
  SecondHeader: ReactElement;
}

const HeaderSwitcherByScroll: React.FC<IHeaderSwitcherByScrollProps> = ({
  isInViewport,
  FirstHeader,
  SecondHeader,
}) => {
  const [wasTargetReached, setWasTargetReached] = useState(isInViewport);

  useEffect(() => {
    if (isInViewport) {
      setWasTargetReached(true);
    }
  }, [isInViewport]);

  return wasTargetReached ? SecondHeader : FirstHeader;
};

export default HeaderSwitcherByScroll;
