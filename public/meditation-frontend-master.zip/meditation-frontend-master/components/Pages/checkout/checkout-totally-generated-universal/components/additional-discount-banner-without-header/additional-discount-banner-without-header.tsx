import { ImageSet } from '@betterme-dev/web-ui-kit/dist/constants/image-set-types';
import React, { useEffect } from 'react';
import { Trans } from 'react-i18next';

import { DEFAULT_DISCOUNT_PERCENTAGE } from '../../../../../../constants/discount.constants';
import useDeviceMode from '../../../../../../hooks/use-device-mode.hook';
import { giftSet } from '../../../generated/additional-discount-generated/additional-discount-generated-banner/images';
import AdditionalDiscountBannerDesktopWithoutHeader from '../additional-discount-banner-desktop-without-header/additional-discount-banner-desktop-without-header';
import classes from './additional-discount-banner-without-header.module.scss';

interface IAdditionalDiscountBannerWithoutHeaderProps {
  desktopImage?: ImageSet;
}

const AdditionalDiscountBannerWithoutHeader: React.FC<IAdditionalDiscountBannerWithoutHeaderProps> = ({
  desktopImage,
}) => {
  const deviceMode = useDeviceMode();
  const isDesktop = deviceMode === 'desktop';

  useEffect(() => {
    try {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth',
      });
    } catch (e) {}
  }, []);

  return (
    <>
      {isDesktop ? (
        <AdditionalDiscountBannerDesktopWithoutHeader desktopImage={desktopImage} />
      ) : (
        <section className={classes.banner}>
          <div className={classes.bannerContent}>
            <h1 className={classes.topBannerTitle}>
              {/*i18n:extract t('checkoutAdditionalDiscountBanner:title', 'Get your personal plan with up to <0>{{percent}}%</0> discount')*/}
              <Trans
                i18nKey="checkoutAdditionalDiscountBanner:title"
                components={[<strong key="0" />]}
                values={{ percent: DEFAULT_DISCOUNT_PERCENTAGE }}
              />
            </h1>
          </div>
          <span className={classes.bannerImageContainer}>
            <img className={classes.bannerImage} src={giftSet.src} srcSet={giftSet.srcSet} />
          </span>
        </section>
      )}
    </>
  );
};

export default AdditionalDiscountBannerWithoutHeader;
