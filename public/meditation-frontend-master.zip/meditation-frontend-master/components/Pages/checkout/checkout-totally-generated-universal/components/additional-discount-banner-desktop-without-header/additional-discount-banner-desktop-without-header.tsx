import { FeaturedInHorizontal } from '@betterme-dev/web-ui-kit';
import { ImageSet } from '@betterme-dev/web-ui-kit/dist/constants/image-set-types';
import React from 'react';
import { Trans } from 'react-i18next';

import { DEFAULT_DISCOUNT_PERCENTAGE } from '../../../../../../constants/discount.constants';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import { bannerDesktop } from '../images';
import classes from './additional-discount-banner-desktop-without-header.module.scss';

interface IAdditionalDiscountBannerDesktopWithoutHeaderProps {
  currentDiscount?: number;
  desktopImage?: ImageSet;
}

const AdditionalDiscountBannerDesktopWithoutHeader: React.FC<IAdditionalDiscountBannerDesktopWithoutHeaderProps> = ({
  currentDiscount = DEFAULT_DISCOUNT_PERCENTAGE,
  desktopImage = bannerDesktop,
}) => {
  const { t } = useTranslation();

  return (
    <section className={classes.topBannerSection}>
      <div className={classes.container}>
        <div className={classes.topBannerRow}>
          <div className={classes.topBannerColLeft}>
            <div className={classes.topBannerText}>
              <h1 className={classes.topBannerTitle}>
                {/*i18n:extract t('checkoutAdditionalDiscountBanner:title', 'Get your personal plan with up to <0>{{percent}}%</0> discount')*/}
                <Trans
                  i18nKey="checkoutAdditionalDiscountBanner:title"
                  components={[<strong key="0" />]}
                  values={{ percent: currentDiscount }}
                />
              </h1>
            </div>
            <div className={classes.featuredInHorizontal}>
              <FeaturedInHorizontal label={t('checkoutTotallyGenerated:featuredIn', 'Featured in:')} />
            </div>
          </div>
          <div className={classes.topBannerColRight}>
            <img
              className={classes.topBannerImg}
              src={desktopImage.src}
              srcSet={desktopImage.srcSet}
              alt={t('checkoutGenerated:topBanner', 'Top banner')}
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AdditionalDiscountBannerDesktopWithoutHeader;
