import {
  Button,
  ButtonColorModeType,
  CheckoutBanner,
  DesktopMode,
  FaqAccordion,
  HEADER_HEIGHT_DESKTOP,
  HEADER_HEIGHT_MOBILE,
  HEADER_HEIGHT_MOBILE_WITH_BUTTON,
  MobileMode,
  WhatYouGet,
  WhatYouGetType,
} from '@betterme-dev/web-ui-kit';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useIsInViewport from 'use-is-in-viewport';

import { Gender } from '../../../../constants/order.constants';
import useDeviceMode from '../../../../hooks/use-device-mode.hook';
import { Router, Trans } from '../../../../i18n';
import { checkoutAction, checkoutGetMyPlanTopClickAction } from '../../../../redux/analytics/analytics.actions';
import {
  checkoutPageButtonTextSelector,
  checkoutPageHeaderImageDesktopManSelector,
  checkoutPageHeaderImageDesktopWomanSelector,
  checkoutPageHeaderImageFemaleAfterMobileSelector,
  checkoutPageHeaderImageFemaleBeforeMobileSelector,
  checkoutPageHeaderImageMaleAfterMobileSelector,
  checkoutPageHeaderImageMaleBeforeMobileSelector,
  checkoutPageMoneyBackGuaranteeSelector,
  checkoutPageOftenAskSelector,
  checkoutPageSubtitle,
  checkoutPageTitleSelector,
  checkoutPageWhatYouGetImageWomanSelector,
  checkoutPageWhatYouGetListSelector,
  checkoutPageWhatYouGetTitleSelector,
  checkoutTimerTitleSelector,
  generalPlanIdsSelector,
  generalPlansSelector,
} from '../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { planSelected, requestPaymentPopup } from '../../../../redux/order/order.actions';
import {
  isAdditionalDiscountAppliedSelector,
  isOrderPaidSelector,
  isPaymentRequestLoadingSelector,
  orderHashSelector,
} from '../../../../redux/order/order.selectors';
import useFunnel from '../../../../utils/funnel-navigation/react/use-funnel-hook';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import { shortcodesConfig } from '../../../../utils/shortcodes';
import shortcodeToTags from '../../../../utils/shortcodes/shortcode-to-tags.util';
import { createCloudinaryImageSetWithLimitedWidth } from '../../../../utils/src-set';
import ContentContainer from '../../../Generic/content-container';
import ChoosePlanOnlyButtonsDetailed from '../../../Shared/Elements/choose-plan-only-buttons-detailed/choose-plan-only-buttons-detailed';
import { getPlanItemsToRender } from '../../../Shared/Elements/choose-plan-only-buttons-detailed/get-plan-items-to-render.util';
import Loader from '../../../Shared/Elements/loader/loader';
import WebUiKitHeader, { IHeaderProps } from '../../../web-ui-kit-header/web-ui-kit-header';
import FeaturedIn from '../chakras/components/featured-in/featured-in';
import PaidOrderMessage from '../generated/additional-discount-generated/paid-order-message/paid-order-message';
import AppStoreReviews from '../generated/app-store-reviews/app-store-reviews';
import { CountdownContext } from '../generated/checkout-generated/sticky-countdown/countdown-provider';
import MoneyBackGuarantee from '../generated/money-back-guarantee/money-back-guarantee';
import HeaderSwitcherByScroll from '../header-switcher-by-scroll/header-switcher-by-scroll';
import classes from './checkout-totally-generated-universal.module.scss';
import AdditionalDiscountBannerWithoutHeader from './components/additional-discount-banner-without-header/additional-discount-banner-without-header';

const CheckoutTotallyGeneratedUniversal = () => {
  const deviceMode = useDeviceMode();
  const { t } = useTranslation();
  const isDesktop = deviceMode === 'desktop';
  const [isInViewport, targetRef] = useIsInViewport();
  const time = useContext(CountdownContext);
  const showLoader = useSelector(isPaymentRequestLoadingSelector);
  const [shouldShowPaidMessage, setShouldShowPaidMessage] = useState(false);

  const isAdditionalDiscountApplied = useSelector(isAdditionalDiscountAppliedSelector);

  const title = useSelector(checkoutPageTitleSelector);
  const subtitle = useSelector(checkoutPageSubtitle);

  const buttonText = useSelector(checkoutPageButtonTextSelector);

  const topBannerDesktopManString = useSelector(checkoutPageHeaderImageDesktopManSelector);
  const topBannerDesktopMan = createCloudinaryImageSetWithLimitedWidth(topBannerDesktopManString, 532);

  const topBannerDesktopWomanString = useSelector(checkoutPageHeaderImageDesktopWomanSelector);
  const topBannerDesktopWoman = createCloudinaryImageSetWithLimitedWidth(topBannerDesktopWomanString, 532);

  const topBannerMobileBeforeManString = useSelector(checkoutPageHeaderImageMaleBeforeMobileSelector);
  const topBannerMobileBeforeMan = createCloudinaryImageSetWithLimitedWidth(topBannerMobileBeforeManString, 288);

  const topBannerMobileBeforeWomanString = useSelector(checkoutPageHeaderImageFemaleBeforeMobileSelector);
  const topBannerMobileBeforeWoman = createCloudinaryImageSetWithLimitedWidth(topBannerMobileBeforeWomanString, 288);

  const topBannerMobileAfterWomanString = useSelector(checkoutPageHeaderImageFemaleAfterMobileSelector);
  const topBannerMobileAfterWoman = createCloudinaryImageSetWithLimitedWidth(topBannerMobileAfterWomanString, 288);

  const topBannerMobileAfterManString = useSelector(checkoutPageHeaderImageMaleAfterMobileSelector);
  const topBannerMobileAfterMan = createCloudinaryImageSetWithLimitedWidth(topBannerMobileAfterManString, 288);

  const whatYouGetBannerString = useSelector(checkoutPageWhatYouGetImageWomanSelector);
  const whatYouGetBanner = createCloudinaryImageSetWithLimitedWidth(whatYouGetBannerString, 592);

  const whatYouGetList = useSelector(checkoutPageWhatYouGetListSelector);

  const whatYouGetTitle = useSelector(checkoutPageWhatYouGetTitleSelector);

  const oftenAskQuestions = useSelector(checkoutPageOftenAskSelector);

  const moneyBackGuaranteeProps = useSelector(checkoutPageMoneyBackGuaranteeSelector);

  const timerLabel = useSelector(checkoutTimerTitleSelector);
  const isOrderPaid = useSelector(isOrderPaidSelector);
  const { upsellPage } = useFunnel();
  const orderHash = useSelector(orderHashSelector);

  const plansIds = useSelector(generalPlanIdsSelector);
  const plans = useSelector(generalPlansSelector);
  const planItemsToRender = getPlanItemsToRender(plans);
  const dispatch = useDispatch();

  useEffect(() => {
    if (plansIds?.length) {
      dispatch(planSelected(plansIds[1]));
    }
  }, [plansIds, dispatch]);

  const handleGetPlanClick = () => {
    dispatch(requestPaymentPopup('INTRODUCTORY_OFFER_PAYMENT_POPUP_WITH_BREAKDOWN'));
    dispatch(checkoutGetMyPlanTopClickAction());
  };
  const paymentBlockRef = useRef(null);

  const handleBtnClick = (): void => {
    const headerHeight = isDesktop ? HEADER_HEIGHT_DESKTOP : HEADER_HEIGHT_MOBILE_WITH_BUTTON;
    if (paymentBlockRef.current) {
      window.scrollTo({
        top: paymentBlockRef.current.offsetTop - headerHeight,
        left: 0,
        behavior: 'smooth',
      });
    }
  };
  // i18n:extract t('checkoutTotallyGenerated:discountText', `<0>Reserved price for</0> {{minutes}}:{{seconds}} <0>mins</0>`)
  const discountBannerText = (
    <Trans
      i18nKey="checkoutTotallyGenerated:discountText"
      components={[<span key="0" />]}
      values={{ minutes: time?.minutes, seconds: time?.seconds }}
    />
  );
  const desktopHeaderConfig: IHeaderProps = {
    mobileConfig: null,
    desktopConfig: {
      mode: DesktopMode.DesktopWithButtonAndTimer,
      props: {
        isPulsing: true,
        buttonColorMode: ButtonColorModeType.SECONDARY,
        onGetPlanClick: handleBtnClick,
        timerLabel: <>{shortcodeToTags(timerLabel, shortcodesConfig)}</>,
      },
    },
  };

  const mobileFirstHeaderConfig: IHeaderProps = {
    mobileConfig: { mode: MobileMode.MobileDefault },
    desktopConfig: null,
  };

  const mobileSecondHeaderConfig: IHeaderProps = {
    mobileConfig: {
      mode: MobileMode.MobileWithButtonAndTimer,
      props: {
        isPulsing: true,
        buttonColorMode: ButtonColorModeType.SECONDARY,
        onGetPlanClick: handleBtnClick,
        buttonLabel: buttonText || t('checkout:getPlanBtnUpperCase', 'GET MY PLAN'),
      },
    },
    desktopConfig: null,
  };

  useEffect(() => {
    if (isOrderPaid) {
      setShouldShowPaidMessage(true);
    }
  }, [isOrderPaid]);

  useEffect(() => {
    dispatch(checkoutAction('purchasing'));
  }, []);

  if (shouldShowPaidMessage) {
    return (
      <PaidOrderMessage
        onSubmit={() => {
          Router.push(`${upsellPage}?order=${orderHash}`);
        }}
      />
    );
  }

  return (
    <div>
      <Loader isShown={showLoader} className={classes.loader} />
      {isDesktop ? (
        <WebUiKitHeader {...desktopHeaderConfig} />
      ) : (
        <HeaderSwitcherByScroll
          isInViewport={isInViewport}
          FirstHeader={<WebUiKitHeader {...mobileFirstHeaderConfig} />}
          SecondHeader={<WebUiKitHeader {...mobileSecondHeaderConfig} />}
        />
      )}
      <div style={{ paddingTop: isDesktop ? `${HEADER_HEIGHT_DESKTOP}px` : `${HEADER_HEIGHT_MOBILE}px` }}>
        {isAdditionalDiscountApplied ? (
          <AdditionalDiscountBannerWithoutHeader desktopImage={topBannerDesktopWoman} />
        ) : (
          <CheckoutBanner
            mobileConfig={{
              images: {
                male: { before: topBannerMobileBeforeMan, after: topBannerMobileAfterMan },
                female: {
                  before: topBannerMobileBeforeWoman,
                  after: topBannerMobileAfterWoman,
                },
              },
              discountText: discountBannerText,
            }}
            desktopConfig={{
              desktopImages: {
                male: topBannerDesktopMan,
                female: topBannerDesktopWoman,
              },
              handleBtnClick: handleBtnClick,
              pulsingButtonMode: ButtonColorModeType.SECONDARY,
              paymentButtonLabel: buttonText || t('checkout:getPlanBtnUpperCase', 'GET MY PLAN'),
              featuredInLabel: t('checkoutTotallyGenerated:featuredIn', 'Featured in:'),
            }}
            gender={Gender.Female}
            title={<>{shortcodeToTags(title, shortcodesConfig)}</>}
            subtitle={<>{shortcodeToTags(subtitle, shortcodesConfig)}</>}
          />
        )}
      </div>

      <ContentContainer>
        <div className={classes.whatYouGet}>
          <WhatYouGet
            whatYouGetType={WhatYouGetType.BulletedList}
            titleText={whatYouGetTitle}
            image={whatYouGetBanner}
            listItems={whatYouGetList}
          />
        </div>
      </ContentContainer>
      <div className={classes.choosePlan} ref={paymentBlockRef}>
        <ContentContainer>
          <ChoosePlanOnlyButtonsDetailed
            onGetMyPlanClick={handleGetPlanClick}
            plans={planItemsToRender}
            PaymentButton={
              <Button
                label={buttonText || t('checkout:getPlanBtnUpperCase', 'GET MY PLAN')}
                onClick={handleGetPlanClick}
                colorMode={ButtonColorModeType.SECONDARY}
              />
            }
          />
        </ContentContainer>
      </div>
      <div className={classes.featuredIn} ref={targetRef}>
        <FeaturedIn />
      </div>

      <div className={classes.lowerContainer}>
        <div className={classes.feedbacks}>
          <div className={classes.appStoreReviews}>
            <ContentContainer>
              <AppStoreReviews />
            </ContentContainer>
          </div>
          <div className={classes.faqAccordion}>
            <ContentContainer>
              <div className={classes.faqAccordionInner}>
                <FaqAccordion
                  questions={oftenAskQuestions}
                  title={t('checkoutTotallyGenerated:peopleOftenAsk', 'People often ask')}
                />
              </div>
            </ContentContainer>
          </div>
        </div>
        <ContentContainer>
          <div className={classes.moneyBackGuarantee}>
            <MoneyBackGuarantee {...moneyBackGuaranteeProps} />
          </div>
        </ContentContainer>

        <div className={classes.button}>
          <Button
            label={buttonText || t('checkout:getPlanBtnUpperCase', 'GET MY PLAN')}
            onClick={handleGetPlanClick}
            colorMode={ButtonColorModeType.SECONDARY}
          />
        </div>

        <ContentContainer>
          <div className={classes.legal}>
            <div className={classes.underButtonLegalText}>
              <div className={classes.legalAddress}>
                {t('legal:themistokliDervi39', 'Themistokli Dervi 39, 1st floor, Office 104, 1066, Nicosia, Cyprus.')}
              </div>
            </div>
          </div>
        </ContentContainer>
      </div>
    </div>
  );
};

export const underButtonLegalTextClass = classes.underButtonLegalText;
export default CheckoutTotallyGeneratedUniversal;
