import { Button, ButtonColorModeType } from '@betterme-dev/web-ui-kit';
import React from 'react';

import { Plan } from '../../../../../../constants/order.constants';
import { formatPrice } from '../../../../../../utils/format-price.util';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import LegalTrial from '../../../../../Shared/Elements/legal/legal-trial';
import classes from './payment-offer.module.scss';

const PaymentOffer: React.FC<{ onClick: () => void; selectedPlan: Plan }> = ({ onClick, selectedPlan }) => {
  const { t } = useTranslation();

  const discountPrice =
    selectedPlan?.discountedPrice && selectedPlan?.discountedPrice > 0 ? formatPrice(selectedPlan?.discountedPrice) : 0;

  const buttonLabel = t('checkout:startFreeTrial', 'START FREE TRIAL');

  return (
    <div className={classes.container}>
      <div className={classes.content}>
        <h2 className={classes.title}>
          Start Your <br />
          <span>7-Day Free Trial</span>
        </h2>

        <p className={classes.thenPrice}>then {discountPrice}/year</p>

        <div className={classes.divider} />

        <div className={classes.legal}>
          <LegalTrial />
        </div>
        <div className={classes.button}>
          <Button label={buttonLabel} onClick={onClick} colorMode={ButtonColorModeType.PRIMARY} isPulsing={true} />
        </div>
      </div>
    </div>
  );
};

export default PaymentOffer;
