import cn from 'classnames';
import React, { useState } from 'react';

import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import CloudinaryImage from '../../../../Shared/Elements/cloudinary-image/image';
import classes from './person-with-chakras.module.scss';

interface ChakraItem {
  imagePath: string;
  color: string;
  text: string;
  positionTop: string;
}

function PersonWithChakras() {
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  const { t } = useTranslation();
  const onLoad = () => {
    setIsImageLoaded(true);
  };

  const CHAKRAS_DATA: ChakraItem[] = [
    {
      imagePath: 'meditation/chakras/Sahasrara_active_svbqg1',
      color: '#AC339C',
      text: t('chackra:sahasrara', 'Loneliness, depression'),
      positionTop: '12%',
    },
    {
      imagePath: 'meditation/chakras/Ajna_acive_dvk7cq',
      color: '#7760C8',
      text: t('chackra:ajna', 'Nightmares, poor insight'),
      positionTop: '18%',
    },
    {
      imagePath: 'meditation/chakras/Vishuddha_active_vrnmns',
      color: '#00A0E8',
      text: t('chackra:vishuddha', 'Can’t explain, express myself'),
      positionTop: '34%',
    },
    {
      imagePath: 'meditation/chakras/Anahata_active_youzsv',
      color: '#67AE05',
      text: t('chackra:anahata', 'Heartbroken, unloved'),
      positionTop: '45%',
    },
    {
      imagePath: 'meditation/chakras/Manipura_acive_bfjkht',
      color: '#C79800',
      text: t('chackra:manipura', 'Angry and helpless'),
      positionTop: '58%',
    },
    {
      imagePath: 'meditation/chakras/Svadhishthana_acive_tncrdn',
      color: '#E15F00',
      text: t('chackra:svadhishthana', 'Poor intuition'),
      positionTop: '70%',
    },
    {
      imagePath: 'meditation/chakras/Muladhara_active_r9iigi',
      color: '#FF273C',
      text: t('chackra:muladhara', 'Low self-esteem'),
      positionTop: '78%',
    },
  ];
  return (
    <div
      className={cn(classes.container, {
        [classes.animate]: isImageLoaded,
      })}
    >
      <div className={classes.content}>
        <div className={classes.background}>
          <CloudinaryImage
            className={classes.image}
            imageName="meditation/home/person-with-chakras/circle_xcip06"
            fetchAuto={false}
          />
        </div>
        <div className={classes.person}>
          <CloudinaryImage
            className={classes.personImage}
            imageName="meditation/home/person-with-chakras/meditating-female_qbwn9u"
            fetchAuto={false}
            onLoad={onLoad}
            pixelate={false}
          />
          <div className={classes.chakraLine}>
            {CHAKRAS_DATA.map((chakra, index) => {
              const { positionTop, color, imagePath, text } = chakra;
              return (
                <div className={classes.chakraItem} style={{ top: positionTop }} key={`chakra-item-${index}`}>
                  <span className={classes.chakraConnector} style={{ backgroundColor: color }} />
                  <CloudinaryImage className={classes.chakraImage} imageName={imagePath} fetchAuto={false} />
                  <span className={classes.chakraText} style={{ color: color, borderColor: color }}>
                    {text}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default PersonWithChakras;
