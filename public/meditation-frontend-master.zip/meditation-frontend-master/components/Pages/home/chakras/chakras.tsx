import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

import {
  chakrasOnboardingStarted,
  generatedQuizStarted,
} from '../../../../redux/generated-quiz/generated-quiz.actions';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import Button from '../../../Shared/Elements/button/button';
import Copyright from '../../../Shared/Elements/copyright/copyright';
import PersonWithChakras from '../components/person-with-chakras/person-with-chakras';
import classes from './chakras.module.scss';

function Chakras() {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(chakrasOnboardingStarted());
  }, []);

  const handleSelectChakras = () => {
    dispatch(generatedQuizStarted());
  };
  return (
    <main className={classes.container}>
      <section className={classes.imageSection}>
        <PersonWithChakras />
      </section>
      <section className={classes.titleSection}>
        <span className={classes.title}>{t('chackras:title', 'Activate 7 chakras with meditation')}</span>
        <span className={classes.subTitle}>
          {t(
            'chackras:subTitle',
            'Sleep well, reduce stress, improve relationships, boost creativity and feel happiness',
          )}
        </span>
      </section>
      <section className={classes.buttonSection}>
        <Button onClick={handleSelectChakras} dataButton="chakras-start-onboarding">
          {t(`chakras:nextButton`, `Next`)}
        </Button>
      </section>
      <Copyright />
    </main>
  );
}

export default Chakras;
