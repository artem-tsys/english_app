import { Button, ButtonColorModeType, TopBanner } from '@betterme-dev/web-ui-kit';
import cn from 'classnames';
import React, { useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { useAnimatedWaypoint } from '../../../../hooks/use-animated-waypoint';
import useDeviceMode from '../../../../hooks/use-device-mode.hook';
import {
  purchaseAction,
  purchaseGetMyPlanClickAction,
  purchasePageScroll100Action,
} from '../../../../redux/analytics/analytics.actions';
import { openSidebar } from '../../../../redux/general/common.actions';
import { alternativeLogoSetSelector } from '../../../../redux/generated-quiz/generated-quiz.selectors';
import { purchasePageButtonTextSelector } from '../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { orderHashSelector } from '../../../../redux/order/order.selectors';
import {
  CustomizationKey,
  MyAgeCategory,
  TMyProblemLevel,
  TRiskLevelOfTrauma,
  TTraumaIdentifiers,
} from '../../../../types/my-trauma-purchase';
import answersPersistentClientStore from '../../../../utils/answers-persistent-client-store';
import useFunnel from '../../../../utils/funnel-navigation/react/use-funnel-hook';
import Link from '../../../../utils/next-with-i18n/link';
import router from '../../../../utils/next-with-i18n/router';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import createCloudinaryImageSet from '../../../../utils/src-set';
import { MyFearCard, MyGoalsCard, MyGoalsPercentageCard, MyProblemsCard } from '../../../Shared/Elements';
import HomepageLink from '../../../Shared/Elements/homepage-link';
import classes from './ab-purchase-generated-personalized.module.scss';

const ABBottomOfScrollContainer = () => {
  const dispatch = useDispatch();

  const { targetRef, animate } = useAnimatedWaypoint({ modBottom: '0px' });

  useEffect(() => {
    if (animate) {
      dispatch(purchasePageScroll100Action());
    }
  }, [animate]);

  return <div ref={targetRef} />;
};

const ABPurchaseGeneratedPersonalized: React.FC = () => {
  const dispatch = useDispatch();
  const { checkoutPage } = useFunnel();
  const { lang } = useTranslation();
  const mode = useDeviceMode();
  const isDesktop = mode === 'desktop';

  const answers = useMemo(() => answersPersistentClientStore.getCustomizationData(), []);

  // TODO: add default fallbacks
  const AB_HARDCODE = {
    riskLevelOfTrauma: answers[CustomizationKey.RISK_LEVEL_OF_TRAUMA] as TRiskLevelOfTrauma,
    traumaIdentifiers: [
      answers[CustomizationKey.TRAUMA_IDENTIFIER_1],
      answers[CustomizationKey.TRAUMA_IDENTIFIER_2],
      answers[CustomizationKey.TRAUMA_IDENTIFIER_3],
      answers[CustomizationKey.TRAUMA_IDENTIFIER_4],
      answers[CustomizationKey.TRAUMA_IDENTIFIER_5],
    ] as TTraumaIdentifiers,
    goal: (answers[CustomizationKey.MIND_GOAL] as string[]) || [],
    areaToImprove: answers[CustomizationKey.AREA_TO_IMPROVE] as string[],
    lackOfFocusLevel: answers[CustomizationKey.LACK_OF_FOCUS_LEVEL] as TMyProblemLevel,
    stressLevel: answers[CustomizationKey.STRESS_LEVEL] as TMyProblemLevel,
    anxietyLevel: answers[CustomizationKey.ANXIETY_LEVEL] as TMyProblemLevel,
    insufficientSleepLevel: answers[CustomizationKey.INSUFFICIENT_SLEEP_LEVEL] as TMyProblemLevel,
    ageCategory: answers[CustomizationKey.AGE_CATEGORY] as MyAgeCategory,
  };

  if (AB_HARDCODE.goal.length > 2) {
    AB_HARDCODE.goal.length = 2;
  }

  if (AB_HARDCODE.areaToImprove.length > 2) {
    AB_HARDCODE.areaToImprove.length = 2;
  }

  const hash = useSelector(orderHashSelector);

  const buttonText = useSelector(purchasePageButtonTextSelector);
  const alternativeLogoSet = useSelector(alternativeLogoSetSelector);
  const headerImageSet = createCloudinaryImageSet(isDesktop ? 'sarsfsywb9gwinbronem' : 'njc6wwsws1gavaf10g37');

  const headerText = 'Get Childhood Trauma Healing Plan';

  const handleMenuButtonClick = () => {
    dispatch(openSidebar());
  };

  const handleGetMyPlanClick = () => {
    dispatch(purchaseGetMyPlanClickAction());
  };

  useEffect(() => {
    if (lang === 'uk') {
      router.push(`${checkoutPage}?order=${hash}`);
      return;
    }
    dispatch(purchaseAction('purchasing'));
  }, []);

  return (
    <div className={classes.root}>
      <div className={classes.bannerContainer}>
        <TopBanner
          logoSet={alternativeLogoSet}
          imageSet={headerImageSet}
          text={headerText}
          LinkComponent={HomepageLink}
          onBurgerClick={handleMenuButtonClick}
        />
      </div>
      <section className={classes.section}>
        <div className={classes.cardsContainer}>
          <span className={classes.sectionTitle}>Personal Summary</span>
          <div className={classes.cards}>
            <MyFearCard
              riskLevelOfTrauma={AB_HARDCODE.riskLevelOfTrauma}
              traumaIdentifiers={AB_HARDCODE.traumaIdentifiers}
            />
            <MyProblemsCard
              stressLevel={AB_HARDCODE.stressLevel}
              anxietyLevel={AB_HARDCODE.anxietyLevel}
              insufficientSleepLevel={AB_HARDCODE.insufficientSleepLevel}
              lackOfFocusLevel={AB_HARDCODE.lackOfFocusLevel}
              ageCategory={AB_HARDCODE.ageCategory}
            />
          </div>
        </div>
        <div className={classes.cardsContainer}>
          <span className={classes.sectionTitle}>Highlights of Your Plan</span>
          <div className={cn(classes.cards, classes.cardsHighlights)}>
            <MyGoalsPercentageCard percentage={77} />
            <MyGoalsCard
              goal={AB_HARDCODE.goal}
              areaToImprove={AB_HARDCODE.areaToImprove}
              ageCategory={AB_HARDCODE.ageCategory}
              traumaIdentifiers={AB_HARDCODE.traumaIdentifiers}
            />
          </div>
        </div>
      </section>
      <ABBottomOfScrollContainer />
      <Link
        href={{
          pathname: `${checkoutPage}`,
          query: {
            order: hash,
          },
        }}
      >
        <div className={classes.buttonContainer}>
          <Button
            isPulsing
            label={buttonText}
            colorMode={ButtonColorModeType.SECONDARY}
            onClick={handleGetMyPlanClick}
          />
        </div>
      </Link>
    </div>
  );
};

export default ABPurchaseGeneratedPersonalized;
