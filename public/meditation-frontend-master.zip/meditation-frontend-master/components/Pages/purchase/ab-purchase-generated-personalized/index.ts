export { default } from './ab-purchase-generated-personalized';
