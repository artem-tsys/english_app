import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { useTranslation } from '../../../../i18n';
import { purchaseAction } from '../../../../redux/analytics/analytics.actions';
import { hidePopup } from '../../../../redux/general/common.actions';
import { shownPopupSelector } from '../../../../redux/general/common.selectors';
import { purchasePageButtonTextSelector } from '../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { orderHashSelector } from '../../../../redux/order/order.selectors';
import useFunnel from '../../../../utils/funnel-navigation/react/use-funnel-hook';
import Link from '../../../../utils/next-with-i18n/link';
import Button from '../../../Shared/Elements/button/button';
import AnxietyFactors from '../components/anxiety-factors';
import Battery from '../components/battery';
import BlockedChakras from '../components/blocked-chakras/blocked-chakras';
import ResultCard from '../components/result-card/result-card';
import classes from './purchase-generated.module.scss';
import ResultBannerGenerated from './result-banner-generated/result-banner-generated';

function PurchaseGenerated() {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const { checkoutPage } = useFunnel();

  const hash = useSelector(orderHashSelector);
  const popupShowing = useSelector(shownPopupSelector);
  const buttonText = useSelector(purchasePageButtonTextSelector);

  useEffect(() => {
    dispatch(purchaseAction('purchasing'));
  }, []);

  useEffect(() => {
    if (popupShowing) {
      dispatch(hidePopup());
    }
  }, []);

  return (
    <>
      <main className={classes.purchaseGenerated}>
        <ResultBannerGenerated />
        <div className={classes.container}>
          <div className={classes.row}>
            <h3 className={classes.title}>{t('purchaseGenerated:title', 'Personal summary')}</h3>

            <div className={classes.battery}>
              <ResultCard>
                <Battery />
              </ResultCard>
            </div>

            <div className={classes.blockedChakras}>
              <ResultCard>
                <BlockedChakras />
              </ResultCard>
            </div>

            <div className={classes.anxietyFactors}>
              <ResultCard>
                <AnxietyFactors />
              </ResultCard>
            </div>
          </div>
        </div>

        <div className={classes.fixedToBottomBlock}>
          <Link
            href={{
              pathname: `${checkoutPage}`,
              query: {
                order: hash,
              },
            }}
          >
            <Button fullWidth>{buttonText}</Button>
          </Link>
        </div>
      </main>
    </>
  );
}

export default PurchaseGenerated;
