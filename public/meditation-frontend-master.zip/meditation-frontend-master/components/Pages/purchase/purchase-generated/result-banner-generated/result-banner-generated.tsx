import React from 'react';
import { useSelector } from 'react-redux';

import { alternativeLogoSetSelector } from '../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  resultBannerHeaderImageSelector,
  resultBannerHeaderSvgSelector,
  resultBannerHeaderTextSelector,
} from '../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import TransparentAbsoluteHeader from '../../../../Generic/page/transparent-absolute-header/transparent-absolute-header';
import classes from './result-banner-generated.module.scss';

function ResultBannerGenerated() {
  const headerSvgImageSet = useSelector(resultBannerHeaderSvgSelector);
  const alternativeLogoSet = useSelector(alternativeLogoSetSelector);
  const headerImageSet = useSelector(resultBannerHeaderImageSelector);
  const headerText = useSelector(resultBannerHeaderTextSelector);

  return (
    <section
      className={headerSvgImageSet ? classes.resultBanner : classes.resultBannerColored}
      style={headerSvgImageSet ? { backgroundImage: `url('${headerSvgImageSet.src}')` } : {}}
    >
      <TransparentAbsoluteHeader logoSet={alternativeLogoSet} burgerColor="var(--whiteColor)" />

      <div className={classes.container}>
        <div className={classes.bannerContent}>
          {headerImageSet && (
            <img className={classes.bannerImage} src={headerImageSet.src} srcSet={headerImageSet.srcSet} />
          )}

          <span className={classes.bannerText}>{headerText}</span>
        </div>
      </div>
    </section>
  );
}

export default ResultBannerGenerated;
