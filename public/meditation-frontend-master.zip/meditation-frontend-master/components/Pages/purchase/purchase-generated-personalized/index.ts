export { default } from './purchase-generated-personalized';
