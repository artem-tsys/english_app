import { Button, ButtonColorModeType, TopBanner } from '@betterme-dev/web-ui-kit';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { purchaseAction } from '../../../../redux/analytics/analytics.actions';
import { openSidebar } from '../../../../redux/general/common.actions';
import { alternativeLogoSetSelector } from '../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  isPersonalizedPersonalSummarySelector,
  purchasePageButtonTextSelector,
  purchasePageOptionsSelector,
  purchasePageShowPersonalSummarySelector,
  resultBannerHeaderImageSelector,
  resultBannerHeaderSvgDesktopSelector,
  resultBannerHeaderSvgMobileSelector,
  resultBannerHeaderTextSelector,
} from '../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { orderHashSelector } from '../../../../redux/order/order.selectors';
import useFunnel from '../../../../utils/funnel-navigation/react/use-funnel-hook';
import Link from '../../../../utils/next-with-i18n/link';
import router from '../../../../utils/next-with-i18n/router';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import HomepageLink from '../../../Shared/Elements/homepage-link';
import Benefits from './components/benefits/benefits';
import CommonIssues from './components/common-issues';
import PersonalSummary, { PersonalSummaryCustomized } from './components/personal-summary';
import Reasons from './components/reasons/reasons';
import classes from './purchase-generated-personalized.module.scss';

const PurchaseGeneratedPersonalized: React.FC = () => {
  const dispatch = useDispatch();
  const { checkoutPage } = useFunnel();
  const { lang } = useTranslation();

  const hash = useSelector(orderHashSelector);

  const buttonText = useSelector(purchasePageButtonTextSelector);
  const headerSvgImageSetDesktop = useSelector(resultBannerHeaderSvgDesktopSelector);
  const headerSvgImageSetMobile = useSelector(resultBannerHeaderSvgMobileSelector);
  const alternativeLogoSet = useSelector(alternativeLogoSetSelector);
  const headerImageSet = useSelector(resultBannerHeaderImageSelector);
  const headerText = useSelector(resultBannerHeaderTextSelector);
  const showPersonalSummary = useSelector(purchasePageShowPersonalSummarySelector);
  const isPersonalizedPersonalSummary = useSelector(isPersonalizedPersonalSummarySelector);

  const { issues, reasons, results } = useSelector(purchasePageOptionsSelector);

  const issuesTitle = issues?.title;
  const issuesItems = issues?.items;
  const isIssuesAvailable = issuesTitle && Array.isArray(issuesItems) && issuesItems?.length;

  const reasonsTitle = reasons?.title;
  const reasonsItems = reasons?.items;
  const reasonsItemsFiltered = reasonsItems?.filter(
    ({ title, description }) => title?.trim().length > 0 && description?.trim().length > 0,
  );
  const isReasonsAvailable = reasonsTitle && Array.isArray(reasonsItemsFiltered) && reasonsItemsFiltered?.length;

  const resultsTitle = results?.title;
  const resultsItems = results?.items;
  const resultsImage = results?.image;
  const isResultsAvailable = resultsTitle && resultsImage && Array.isArray(resultsItems) && resultsItems?.length;

  const handleMenuButtonClick = () => {
    dispatch(openSidebar());
  };

  useEffect(() => {
    if (lang === 'uk') {
      router.push(`${checkoutPage}?order=${hash}`);
      return;
    }
    dispatch(purchaseAction('purchasing'));
  }, [dispatch]);

  return (
    <div className={classes.purchaseGeneratedPersonalizedContainer}>
      <div className={classes.topBannerContainer}>
        <TopBanner
          svgImageSets={{
            mobile: headerSvgImageSetMobile,
            desktop: headerSvgImageSetDesktop,
          }}
          logoSet={alternativeLogoSet}
          imageSet={headerImageSet}
          text={headerText}
          LinkComponent={HomepageLink}
          onBurgerClick={handleMenuButtonClick}
        />
      </div>
      <section>
        {showPersonalSummary && (
          <div className={classes.personalSummaryContainer}>
            {isPersonalizedPersonalSummary ? <PersonalSummaryCustomized /> : <PersonalSummary />}
          </div>
        )}

        {isIssuesAvailable && (
          <div className={classes.commonIssues}>
            <CommonIssues title={issuesTitle} items={issuesItems} />
          </div>
        )}

        {isReasonsAvailable && (
          <div className={classes.reasons}>
            <Reasons title={reasonsTitle} items={reasonsItemsFiltered} />
          </div>
        )}

        {isResultsAvailable && (
          <div className={classes.benefits}>
            <Benefits title={resultsTitle} items={resultsItems} image={resultsImage} />
          </div>
        )}

        <Link
          href={{
            pathname: `${checkoutPage}`,
            query: {
              order: hash,
            },
          }}
        >
          <div className={classes.buttonContainer}>
            <Button label={buttonText} colorMode={ButtonColorModeType.PRIMARY} />
          </div>
        </Link>
      </section>
    </div>
  );
};

export default PurchaseGeneratedPersonalized;
