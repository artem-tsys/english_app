export { default } from './bullets';
