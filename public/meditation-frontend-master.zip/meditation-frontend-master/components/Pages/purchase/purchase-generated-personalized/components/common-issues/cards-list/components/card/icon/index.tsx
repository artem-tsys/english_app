export { default } from './icon';
