import React from 'react';

import CardsList, { ICard } from './cards-list';
import classes from './common-issues.module.scss';

interface ICommonIssuesProps {
  title: string;
  items: ICard[];
}

const CommonIssues: React.FC<ICommonIssuesProps> = ({ title, items }) => (
  <div className={classes.container}>
    <h2 className={classes.header}>{title}</h2>

    <CardsList data={items} />
  </div>
);

export default CommonIssues;
