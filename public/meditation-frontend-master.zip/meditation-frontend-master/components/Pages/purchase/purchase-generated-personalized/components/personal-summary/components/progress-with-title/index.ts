import { IProgressWithTitleProps } from './progress-with-title';

export { default, ProgressWithTitleState } from './progress-with-title';
export type { IProgressWithTitleProps };
