import React from 'react';
import { useSelector } from 'react-redux';

import { Anxiety, Distraction, Insomnia, Stressed } from '../../../../../../constants/quiz-options.constants';
import { Trans, useTranslation } from '../../../../../../i18n';
import {
  purchasePagePersonalSummarySubtitleSelector,
  purchasePagePersonalSummaryTitleSelector,
} from '../../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import {
  anxietySelector,
  distractionSelector,
  insomniaSelector,
  stressedSelector,
} from '../../../../../../redux/order/order.selectors';
import { shortcodesConfig } from '../../../../../../utils/shortcodes';
import shortcodeToTags from '../../../../../../utils/shortcodes/shortcode-to-tags.util';
import ProgressWithTitle from './components/progress-with-title';
import classes from './personal-summary.module.scss';
import { usePersonalSummaryConfig } from './use-personal-summury-params.util';

const PersonalSummary: React.FC = () => {
  const { t } = useTranslation();

  const personalSummaryTitle = useSelector(purchasePagePersonalSummaryTitleSelector);
  const personalSummarySubtitle = useSelector(purchasePagePersonalSummarySubtitleSelector);

  const insomnia = useSelector(insomniaSelector) || Insomnia.TroubleFallingAsleep;
  const distraction = useSelector(distractionSelector) || Distraction.OftenHardToFocus;
  const anxiety = useSelector(anxietySelector) || Anxiety.Often;
  const stressed = useSelector(stressedSelector) || Stressed.PrettyOften;

  const summaryListArray = usePersonalSummaryConfig(t, {
    insomnia,
    distraction,
    anxiety,
    stressed,
  });

  return (
    <div className={classes.container}>
      <div className={classes.headerContainer}>
        <h2 className={classes.title}>
          {personalSummaryTitle
            ? shortcodeToTags(personalSummaryTitle, shortcodesConfig)
            : t('personalSummary:personalSummary', 'Personal summary')}
        </h2>
        <p className={classes.description}>
          {personalSummarySubtitle ? (
            shortcodeToTags(personalSummarySubtitle, shortcodesConfig)
          ) : (
            <>
              {/* i18n:extract t('personalSummary:description', `Based on your answers we have determined that these factors <0>negatively affect your well-being</0>`) */}
              <Trans
                i18nKey="personalSummary:description"
                components={[<strong className={classes.descriptionAccent} key="0" />]}
              />
            </>
          )}
        </p>
      </div>
      <div className={classes.listContainer}>
        {summaryListArray.map((item) => (
          <div className={classes.listItem} key={item.title}>
            <ProgressWithTitle {...item} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default PersonalSummary;
