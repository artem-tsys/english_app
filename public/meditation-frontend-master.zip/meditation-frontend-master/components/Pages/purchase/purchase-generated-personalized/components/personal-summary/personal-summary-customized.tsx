import React, { useMemo } from 'react';
import { useSelector } from 'react-redux';

import { Trans, useTranslation } from '../../../../../../i18n';
import {
  purchasePagePersonalSummaryFactorsSelector,
  purchasePagePersonalSummarySubtitleSelector,
  purchasePagePersonalSummaryTitleSelector,
} from '../../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { FEELINGS_CUSTOMIZATION_KEYS, SymptomLevel } from '../../../../../../types/my-trauma-purchase';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import { shortcodesConfig } from '../../../../../../utils/shortcodes';
import shortcodeToTags from '../../../../../../utils/shortcodes/shortcode-to-tags.util';
import ProgressWithTitle, { ProgressWithTitleState } from './components/progress-with-title';
import classes from './personal-summary.module.scss';

const CustomizationKeyToProgressWithTitleState = {
  [SymptomLevel.SEVERE]: ProgressWithTitleState.RED,
  [SymptomLevel.HIGH]: ProgressWithTitleState.ORANGE,
  [SymptomLevel.MILD]: ProgressWithTitleState.YELLOW,
  [SymptomLevel.NOT_IDENTIFIED]: ProgressWithTitleState.GREEN,
};

const getTextOfChakraLevel = (levelStringNumber: SymptomLevel, t): string => {
  if (levelStringNumber === SymptomLevel.SEVERE) {
    return t('personalSummary:chakraLevelSevere', 'Severely blocked');
  }

  if (levelStringNumber === SymptomLevel.HIGH) {
    return t('personalSummary:chakraLevelHighly', 'Highly blocked');
  }

  if (levelStringNumber === SymptomLevel.MILD) {
    return t('personalSummary:chakraLevelMildly', 'Mildly blocked');
  }

  if (levelStringNumber === SymptomLevel.NOT_IDENTIFIED) {
    return t('personalSummary:chakraLevelNotIdentified', 'Not identified');
  }
};

const getTextOfFeelingsLevel = (levelStringNumber: SymptomLevel, t): string => {
  if (levelStringNumber === SymptomLevel.SEVERE) {
    return t('personalSummary:feelingsLevelSevere', 'Severe');
  }

  if (levelStringNumber === SymptomLevel.HIGH) {
    return t('personalSummary:feelingsLevelHighly', 'High');
  }

  if (levelStringNumber === SymptomLevel.MILD) {
    return t('personalSummary:feelingsLevelMildly', 'Mild');
  }

  if (levelStringNumber === SymptomLevel.NOT_IDENTIFIED) {
    return t('personalSummary:feelingsLevelNotIdentified', 'Not identified');
  }
};

const getFullFactorTitle = (factorText: string, level: SymptomLevel, key, t) => {
  if (FEELINGS_CUSTOMIZATION_KEYS.includes(key)) {
    return factorText + ': ' + getTextOfFeelingsLevel(level, t);
  }
  return factorText + ': ' + getTextOfChakraLevel(level, t);
};

const PersonalSummaryCustomized: React.FC = () => {
  const { t } = useTranslation();

  const customizationAnswers = useMemo(() => answersPersistentClientStore.getCustomizationAnswers(), []);

  const personalSummaryTitle = useSelector(purchasePagePersonalSummaryTitleSelector);
  const personalSummarySubtitle = useSelector(purchasePagePersonalSummarySubtitleSelector);

  const factorArray = useSelector(purchasePagePersonalSummaryFactorsSelector);
  const factorArrayWithCustomizationKeys = factorArray.filter((factor) => !!factor.customizationKey);

  return (
    <div className={classes.container}>
      <div className={classes.headerContainer}>
        <h2 className={classes.title}>
          {personalSummaryTitle
            ? shortcodeToTags(personalSummaryTitle, shortcodesConfig)
            : t('personalSummary:personalSummary', 'Personal summary')}
        </h2>
        <p className={classes.description}>
          {personalSummarySubtitle ? (
            shortcodeToTags(personalSummarySubtitle, shortcodesConfig)
          ) : (
            <>
              {/* i18n:extract t('personalSummary:description', `Based on your answers we have determined that these factors <0>negatively affect your well-being</0>`) */}
              <Trans
                i18nKey="personalSummary:description"
                components={[<strong className={classes.descriptionAccent} key="0" />]}
              />
            </>
          )}
        </p>
      </div>
      <div className={classes.listContainer}>
        {factorArrayWithCustomizationKeys.map((item) => (
          <div className={classes.listItem} key={item.title}>
            <ProgressWithTitle
              title={getFullFactorTitle(
                item.title,
                customizationAnswers[item.customizationKey],
                item.customizationKey,
                t,
              )}
              description={item.subtitle}
              state={CustomizationKeyToProgressWithTitleState[customizationAnswers[item.customizationKey]]}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default PersonalSummaryCustomized;
