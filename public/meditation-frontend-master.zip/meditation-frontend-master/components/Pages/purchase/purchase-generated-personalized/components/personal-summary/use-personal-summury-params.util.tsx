import { TFunction } from 'next-i18next';
import { useSelector } from 'react-redux';

import { Anxiety, Distraction, Insomnia, Stressed } from '../../../../../../constants/quiz-options.constants';
import {
  purchasePageFactor1SubtitleSelector,
  purchasePageFactor1TitleSelector,
  purchasePageFactor2SubtitleSelector,
  purchasePageFactor2TitleSelector,
  purchasePageFactor3SubtitleSelector,
  purchasePageFactor3TitleSelector,
  purchasePageFactor4SubtitleSelector,
  purchasePageFactor4TitleSelector,
} from '../../../../../../redux/generated-sale-funnel/generated-sale-funnel.selectors';
import { IProgressWithTitleProps, ProgressWithTitleState } from './components/progress-with-title';

interface IPersonalSummaryConfigParams {
  insomnia: Insomnia;
  distraction: Distraction;
  anxiety: Anxiety;
  stressed: Stressed;
}

interface IFactorDynamicParams {
  title: string;
  state: ProgressWithTitleState;
  description: string;
}

export const useInsomniaParams = (
  t: TFunction,
  insomnia: Insomnia = Insomnia.TroubleFallingAsleep,
): IFactorDynamicParams => {
  // i18n:extract t('personalSummary:frustration', 'Frustration')
  const titleTranslated = t('personalSummary:frustration', 'Frustration');
  // i18n:extract t('personalSummary:frustrationDescription', 'Negative feelings or annoyance when unable to change or achieve something.')
  const descriptionTranslated = t(
    'personalSummary:frustrationDescription',
    'Negative feelings or annoyance when unable to change or achieve something.',
  );

  const titlePrefix = useSelector(purchasePageFactor1TitleSelector) || titleTranslated;
  const description = useSelector(purchasePageFactor1SubtitleSelector) || descriptionTranslated;

  const INSOMNIA_PARAMS: Record<Insomnia, { title: string; state: ProgressWithTitleState }> = {
    [Insomnia.FallAsleepSoon]: {
      // i18n:extract t('personalSummary:notIdentified', 'Not identified')
      title: t('personalSummary:notIdentified', 'Not identified'),
      state: ProgressWithTitleState.GREEN,
    },
    [Insomnia.UpTo15MinutesAsleep]: {
      // i18n:extract t('personalSummary:mild', 'Mild')
      title: t('personalSummary:mild', 'Mild'),
      state: ProgressWithTitleState.YELLOW,
    },
    [Insomnia.TurnForAnHour]: {
      // i18n:extract t('personalSummary:moderate', 'Moderate')
      title: t('personalSummary:moderate', 'Moderate'),
      state: ProgressWithTitleState.ORANGE,
    },
    [Insomnia.TroubleFallingAsleep]: {
      // i18n:extract t('personalSummary:severe', 'Severe')
      title: t('personalSummary:severe', 'Severe'),
      state: ProgressWithTitleState.RED,
    },
  };

  return {
    ...INSOMNIA_PARAMS[insomnia],
    title: `${titlePrefix}: ${INSOMNIA_PARAMS[insomnia].title}`,
    description,
  };
};

export const useDistractionParams = (
  t: TFunction,
  distraction: Distraction = Distraction.OftenHardToFocus,
): IFactorDynamicParams => {
  // i18n:extract t('personalSummary:lackOfFocus', 'Lack of focus')
  const titleTranslated = t('personalSummary:lackOfFocus', 'Lack of focus');
  // i18n:extract t('personalSummary:lackOfFocusDescription', 'Aftermath of stress, poor sleep or diet, sedentary behavior.')
  const descriptionTranslated = t(
    'personalSummary:lackOfFocusDescription',
    'Aftermath of stress, poor sleep or diet, sedentary behavior.',
  );

  const titlePrefix = useSelector(purchasePageFactor2TitleSelector) || titleTranslated;
  const description = useSelector(purchasePageFactor2SubtitleSelector) || descriptionTranslated;

  const DISTRACTION_PARAMS: Record<Distraction, { title: string; state: ProgressWithTitleState }> = {
    [Distraction.FocusMaster]: {
      // i18n:extract t('personalSummary:notIdentified', 'Not identified')
      title: t('personalSummary:notIdentified', 'Not identified'),
      state: ProgressWithTitleState.GREEN,
    },
    [Distraction.SometimesHardToFocus]: {
      // i18n:extract t('personalSummary:mild', 'Mild')
      title: t('personalSummary:mild', 'Mild'),
      state: ProgressWithTitleState.YELLOW,
    },
    [Distraction.OftenHardToFocus]: {
      // i18n:extract t('personalSummary:moderate', 'High')
      title: t('personalSummary:moderate', 'High'),
      state: ProgressWithTitleState.ORANGE,
    },
    [Distraction.AllTheTimeHardToFocus]: {
      // i18n:extract t('personalSummary:severe', 'Severe')
      title: t('personalSummary:severe', 'Severe'),
      state: ProgressWithTitleState.RED,
    },
  };

  return {
    ...DISTRACTION_PARAMS[distraction],
    title: `${titlePrefix}: ${DISTRACTION_PARAMS[distraction].title}`,
    description,
  };
};

export const useAnxietyParams = (t: TFunction, anxiety: Anxiety = Anxiety.Often): IFactorDynamicParams => {
  // i18n:extract t('personalSummary:anxiety', 'Anxiety')
  const titleTranslated = t('personalSummary:anxiety', 'Anxiety');
  // i18n:extract t('personalSummary:anxietyDescription', 'Restlessness and constant worry about everyday situations.')
  const descriptionTranslated = t(
    'personalSummary:anxietyDescription',
    'Restlessness and constant worry about everyday situations.',
  );

  const titlePrefix = useSelector(purchasePageFactor3TitleSelector) || titleTranslated;
  const description = useSelector(purchasePageFactor3SubtitleSelector) || descriptionTranslated;

  const ANXIETY_PARAMS: Record<Anxiety, { title: string; state: ProgressWithTitleState }> = {
    [Anxiety.Never]: {
      // i18n:extract t('personalSummary:notIdentified', 'Not identified')
      title: t('personalSummary:notIdentified', 'Not identified'),
      state: ProgressWithTitleState.GREEN,
    },
    [Anxiety.OnceOrTwice]: {
      // i18n:extract t('personalSummary:Moderate', 'Moderate')
      title: t('personalSummary:Moderate', 'Moderate'),
      state: ProgressWithTitleState.YELLOW,
    },
    [Anxiety.Often]: {
      // i18n:extract t('personalSummary:High', 'High')
      title: t('personalSummary:High', 'High'),
      state: ProgressWithTitleState.ORANGE,
    },
    [Anxiety.Always]: {
      // i18n:extract t('personalSummary:veryHigh', 'Very high')
      title: t('personalSummary:veryHigh', 'Very high'),
      state: ProgressWithTitleState.RED,
    },
  };

  return {
    ...ANXIETY_PARAMS[anxiety],
    title: `${titlePrefix}: ${ANXIETY_PARAMS[anxiety].title}`,
    description,
  };
};

export const useStressedParams = (t: TFunction, stressed: Stressed = Stressed.AlmostAlways): IFactorDynamicParams => {
  // i18n:extract t('personalSummary:stress', 'Stress')
  const titleTranslated = t('personalSummary:stress', 'Stress');
  // i18n:extract t('personalSummary:stressDescription', 'Feelings of being overwhelmed, difficulties dealing with pressure.')
  const descriptionTranslated = t(
    'personalSummary:stressDescription',
    'Feelings of being overwhelmed, difficulties dealing with pressure.',
  );

  const titlePrefix = useSelector(purchasePageFactor4TitleSelector) || titleTranslated;
  const description = useSelector(purchasePageFactor4SubtitleSelector) || descriptionTranslated;

  const STRESSED_PARAMS: Record<Stressed, { title: string; state: ProgressWithTitleState }> = {
    [Stressed.Never]: {
      // i18n:extract t('personalSummary:notIdentified', 'Not identified')
      title: t('personalSummary:notIdentified', 'Not identified'),
      state: ProgressWithTitleState.GREEN,
    },
    [Stressed.Rarely]: {
      // i18n:extract t('personalSummary:moderate', 'Moderate')
      title: t('personalSummary:moderate', 'Moderate'),
      state: ProgressWithTitleState.YELLOW,
    },
    [Stressed.PrettyOften]: {
      // i18n:extract t('personalSummary:high', 'High')
      title: t('personalSummary:high', 'High'),
      state: ProgressWithTitleState.ORANGE,
    },
    [Stressed.AlmostAlways]: {
      // i18n:extract t('personalSummary:veryHigh', 'Very high')
      title: t('personalSummary:veryHigh', 'Very high'),
      state: ProgressWithTitleState.RED,
    },
  };

  return {
    ...STRESSED_PARAMS[stressed],
    title: `${titlePrefix}: ${STRESSED_PARAMS[stressed].title}`,
    description,
  };
};

export const usePersonalSummaryConfig = (
  t: TFunction,
  { insomnia, distraction, anxiety, stressed }: IPersonalSummaryConfigParams,
): IProgressWithTitleProps[] => {
  return [
    useInsomniaParams(t, insomnia),
    useDistractionParams(t, distraction),
    useAnxietyParams(t, anxiety),
    useStressedParams(t, stressed),
  ];
};
