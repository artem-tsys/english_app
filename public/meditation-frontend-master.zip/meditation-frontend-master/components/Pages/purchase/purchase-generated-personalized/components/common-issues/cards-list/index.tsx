export { default } from './cards-list';
export type { ICard } from './cards-list';
