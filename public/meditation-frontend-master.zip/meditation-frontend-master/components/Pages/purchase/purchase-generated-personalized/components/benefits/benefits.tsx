import { PicsList } from '@betterme-dev/web-ui-kit';
import React from 'react';

import { IPurchasePageResults } from '../../../../../../api/generated-flow.api';
import { shortcodesConfig } from '../../../../../../utils/shortcodes';
import shortcodeToTags from '../../../../../../utils/shortcodes/shortcode-to-tags.util';
import { createCloudinaryImageSetWithLimitedWidth } from '../../../../../../utils/src-set';
import classes from './benefits.module.scss';

const formatData = (items: IPurchasePageResults['items']) =>
  items.map(({ image, ...item }, i) => ({
    ...item,
    id: i,
    image: image
      ? createCloudinaryImageSetWithLimitedWidth(image, 72)
      : {
          src: '',
          srcSet: '',
        },
  }));

const Benefits: React.FC<IPurchasePageResults> = ({ title, items, image }) => {
  const mainImage = createCloudinaryImageSetWithLimitedWidth(image, 672);

  return (
    <div className={classes.container}>
      <div className={classes.header}>
        <span className={classes.title}>{shortcodeToTags(title, shortcodesConfig)}</span>
      </div>
      <img className={classes.image} {...mainImage} />
      <div className={classes.picsList}>
        <PicsList items={formatData(items)} />
      </div>
    </div>
  );
};

export default Benefits;
