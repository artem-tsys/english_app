import React from 'react';

import classes from './bullets.module.scss';

interface IBulletsProps {
  data: string[];
}

const Bullet = (text: string, idx: number) => (
  <li key={idx}>
    <div className={classes.dot}>·</div>
    <span>{text}</span>
  </li>
);

const Bullets: React.FC<IBulletsProps> = ({ data }) => <ul className={classes.container}>{data.map(Bullet)}</ul>;

export default Bullets;
