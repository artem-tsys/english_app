import React from 'react';

import Bullets from './bullets';
import classes from './card.module.scss';
import Header from './header';
import Icon from './icon';

interface IComponents {
  Icon: typeof Icon;
  Header: typeof Header;
  Bullets: typeof Bullets;
}

interface ICardProps {
  children: JSX.Element | JSX.Element[];
}

const Card: React.FC<ICardProps> & IComponents = (props) => <div className={classes.container}>{props.children}</div>;

Card.Icon = Icon;
Card.Bullets = Bullets;
Card.Header = Header;

export default Card;
