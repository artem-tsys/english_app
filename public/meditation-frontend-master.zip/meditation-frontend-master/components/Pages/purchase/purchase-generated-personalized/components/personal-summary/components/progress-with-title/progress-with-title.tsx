import cn from 'classnames';
import React from 'react';

import classes from './progress-with-title.module.scss';

export enum ProgressWithTitleState {
  GREEN = 'green',
  YELLOW = 'yellow',
  ORANGE = 'orange',
  RED = 'red',
}

export interface IProgressWithTitleProps {
  title: string;
  description: string;
  state: ProgressWithTitleState;
}

interface IProgressProps {
  state: ProgressWithTitleState;
}

const Progress: React.FC<IProgressProps> = ({ state }) => (
  <div className={classes.progressContainer}>
    <div className={cn(classes.progress, classes[state])} />
  </div>
);

const ProgressWithTitle: React.FC<IProgressWithTitleProps> = ({ title, description, state }) => (
  <div className={classes.container}>
    <h3 className={classes.title}>{title}</h3>
    <p className={classes.description}>{description}</p>
    <Progress state={state} />
  </div>
);

export default ProgressWithTitle;
