import React from 'react';

import { IPurchasePageReasons } from '../../../../../../api/generated-flow.api';
import { createCloudinaryImageSetWithLimitedWidth } from '../../../../../../utils/src-set';
import classes from './reasons.module.scss';

type IReasonsProps = IPurchasePageReasons;

const Reasons: React.FC<IReasonsProps> = ({ title, items }) => {
  return (
    <div className={classes.container}>
      <h2 className={classes.smallerHeader}>{title}</h2>

      {items.map(({ title, description, image }, i) => {
        return (
          <div className={classes.contentItem} key={i}>
            <img className={classes.contentImage} {...createCloudinaryImageSetWithLimitedWidth(image, 497)} />
            <div className={classes.contentDescription}>
              <h4 className={classes.contentHeader}>{title}</h4>
              <p className={classes.contentText}>{description}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Reasons;
