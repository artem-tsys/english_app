import React from 'react';

import { createCloudinaryImageSetWithLimitedWidth } from '../../../../../../../utils/src-set';
import classes from './cards-list.module.scss';
import Card from './components/card';

export interface ICard {
  title: string;
  bullets: Array<string>;
  id?: string;
  icon: string;
}

interface ICardListProps {
  data: ICard[];
}

const getKey = <T extends { id?: string }>(datum: T, idx: number) => datum?.id ?? idx;

const CardsList: React.FC<ICardListProps> = ({ data }) => {
  return (
    <div className={classes.container}>
      {data.map((card, idx) => {
        const imageSet = createCloudinaryImageSetWithLimitedWidth(card.icon, 24);

        return (
          <Card key={getKey(card, idx)}>
            <Card.Icon imageSet={imageSet} />
            <Card.Header text={card.title} imageSet={imageSet} />
            <Card.Bullets data={card.bullets} />
          </Card>
        );
      })}
    </div>
  );
};

export default CardsList;
