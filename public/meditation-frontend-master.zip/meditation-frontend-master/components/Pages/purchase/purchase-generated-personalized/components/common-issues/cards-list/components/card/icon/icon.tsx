import React from 'react';

import { ImageSet } from '../../../../../../../../../../utils/src-set';
import classes from './icon.module.scss';

interface IIconProps {
  imageSet: ImageSet;
}

const Icon: React.FC<IIconProps> = ({ imageSet }) => (
  <div className={classes.container}>
    <img {...imageSet} className={classes.icon} />
  </div>
);

export default Icon;
