import React from 'react';

import { ImageSet } from '../../../../../../../../../../utils/src-set';
import classes from './header.module.scss';

interface IHeaderProps {
  text: string;
  imageSet: ImageSet;
}

const Header: React.FC<IHeaderProps> = ({ text, imageSet }) => {
  return (
    <div className={classes.container}>
      <img {...imageSet} className={classes.image} />
      {text}
    </div>
  );
};

export default Header;
