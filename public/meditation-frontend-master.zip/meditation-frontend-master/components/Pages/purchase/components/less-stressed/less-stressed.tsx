import cn from 'classnames';
import React, { useState } from 'react';

import { useInterval } from '../../../../../hooks/use-interval.hook';
import { Trans } from '../../../../../i18n';
import classes from './less-stressed.module.scss';

const TICK_TIME = 20;
const SLOW_TICK_TIME = 70;

const getTickTime = (progress: number) => {
  if (progress > 75 && progress < 94) {
    return SLOW_TICK_TIME;
  }
  return TICK_TIME;
};

interface Props {
  startProgress: number;
  endProgress: number;
  animate?: boolean;
  planText?: string;
}
//Todo: Add Trans
function LessStressed({ startProgress, endProgress, animate }: Props) {
  const [progress, setProgress] = useState(startProgress);
  const isAnimationFinished = progress === endProgress;

  useInterval(
    () => {
      animate && setProgress(progress + 1);
    },
    !animate || isAnimationFinished ? null : getTickTime(progress),
  );

  return (
    <div className={cn(classes.container, { [classes.animate]: animate })}>
      <span className={classes.usersPercent}>
        {progress}
        <span>%</span>
      </span>
      <span className={classes.text}>
        {/* i18n:extract t('lessStressed:text', 'Users with similar profiles <0>feel less stressed</0> using our meditation plans') */}
        <Trans i18nKey="lessStressed:text" components={[<b key="0" />, <b key="1" />]} />
      </span>
    </div>
  );
}

export default LessStressed;
