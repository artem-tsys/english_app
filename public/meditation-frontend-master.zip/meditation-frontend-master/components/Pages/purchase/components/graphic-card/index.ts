export { default } from './graphic-card';
