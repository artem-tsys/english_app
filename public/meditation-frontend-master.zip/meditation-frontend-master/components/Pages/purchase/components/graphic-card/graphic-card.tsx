import cn from 'classnames';
import React, { CSSProperties } from 'react';

import CloudinaryImage from '../../../../Shared/Elements/cloudinary-image/image';
import classes from './graphic-card.module.scss';

interface GraphicCardProps {
  image: string;
  color: string;
  titleText: string;
  subTitleText: string;
  labelText: string;
  description?: string;
  animate?: boolean;
}

const GraphicCard: React.FC<GraphicCardProps> = ({
  image,
  color,
  titleText,
  subTitleText,
  labelText,
  description,
  animate,
}) => (
  <div className={cn(classes.container, { [classes.animate]: animate })}>
    <h2 className={classes.title}>{titleText}</h2>
    <div className={classes.subTitle}>
      <span className={classes.subTitleText}>{subTitleText}</span>{' '}
      <span className={classes.subTitleLabel} style={{ ['--subTitleLabelColor']: color } as CSSProperties}>
        {labelText}
      </span>
    </div>
    <div className={classes.imageContainer}>
      <CloudinaryImage className={classes.image} imageName={image} />
    </div>
    {description && <div className={classes.descriptionContainer}>{description}</div>}
  </div>
);

export default GraphicCard;
