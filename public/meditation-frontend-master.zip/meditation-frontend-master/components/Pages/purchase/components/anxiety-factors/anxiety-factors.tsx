import React from 'react';
import { useSelector } from 'react-redux';

import { AnxietyFactorsParams, Stressed } from '../../../../../constants/quiz-options.constants';
import { stressedSelector } from '../../../../../redux/order/order.selectors';
import useTranslation from '../../../../../utils/next-with-i18n/use-translation';
import GraphicCard from '../graphic-card';

const AnxietyFactors: React.FC = () => {
  const { t } = useTranslation();

  const selectedStress = useSelector(stressedSelector);
  const cardData = AnxietyFactorsParams[selectedStress || Stressed.AlmostAlways];

  const titleText = t('anxietyFactors:stressFactors', 'Stress Factors');
  const subTitleText = t('anxietyFactors:yourStressIs', 'Your stress is:');
  const labelText = t(cardData.label.key, cardData.label.value);

  return (
    <GraphicCard
      color={cardData.color}
      image={cardData.image}
      titleText={titleText}
      subTitleText={subTitleText}
      labelText={labelText}
    />
  );
};

export default AnxietyFactors;
