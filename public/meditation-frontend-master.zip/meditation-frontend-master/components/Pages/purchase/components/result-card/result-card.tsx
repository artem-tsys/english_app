import cn from 'classnames';
import React, { cloneElement, ReactElement, useEffect, useState } from 'react';
import useIsInViewport from 'use-is-in-viewport';

import classes from './result-card.module.scss';

interface Props {
  children: ReactElement;
}

function ResultCard({ children }: Props) {
  const [isInViewport, targetRef] = useIsInViewport({ modBottom: `-200px` });
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    !animate && isInViewport && setAnimate(true);
  }, [isInViewport]);

  return (
    <div
      className={cn(classes.resultCard, {
        [classes.animate]: animate,
      })}
      ref={targetRef}
    >
      {cloneElement(children, { animate })}
    </div>
  );
}

export default ResultCard;
