import React from 'react';
import { useSelector } from 'react-redux';

import { StressCauseType } from '../../../../../constants/quiz-options.constants';
import { useTranslation } from '../../../../../i18n';
import { stressCauseSelector } from '../../../../../redux/order/order.selectors';
import classes from './blocked-chakras.module.scss';
import { womanWithImagesSet } from './images';
enum Chakra {
  Vishuddha = 'Vishuddha',
  Anahata = 'Anahata',
  Muladhara = 'Muladhara',
  Svadhishthana = 'Svadhishthana',
  Ajna = 'Ajna',
  Sahasrara = 'Sahasrara',
  Manipura = 'Manipura',
}

const STRESS_TO_CHAKRAS: Record<StressCauseType, Chakra> = {
  'excess-weight': Chakra.Vishuddha,
  relationships: Chakra.Anahata,
  'financial-difficulties': Chakra.Muladhara,
  'work-or-school': Chakra.Svadhishthana,
  'health-issues': Chakra.Ajna,
  'bad-habits': Chakra.Sahasrara,
  'low-self-esteem': Chakra.Manipura,
};

const CHAKRAS_TITLE: Record<Chakra, string> = {
  [Chakra.Vishuddha]: 'Vishuddha',
  [Chakra.Anahata]: 'Anahata',
  [Chakra.Muladhara]: 'Muladhara',
  [Chakra.Svadhishthana]: 'Svadhishthana',
  [Chakra.Ajna]: 'Ajna',
  [Chakra.Sahasrara]: 'Sahasrara',
  [Chakra.Manipura]: 'Manipura',
};

const CHAKRAS_COLORS: Record<Chakra, string> = {
  [Chakra.Vishuddha]: '#138EC5',
  [Chakra.Anahata]: '#7ECC8F',
  [Chakra.Muladhara]: '#E55C3E',
  [Chakra.Svadhishthana]: '#EB780D',
  [Chakra.Ajna]: '#7159C6',
  [Chakra.Sahasrara]: '#AC339C',
  [Chakra.Manipura]: '#E2AA1A',
};

const BlockedChakras = () => {
  const stressCause = useSelector(stressCauseSelector);
  const blockedChakras = stressCause.map((cause) => {
    return STRESS_TO_CHAKRAS[cause];
  });
  const { t } = useTranslation();
  const CHAKRAS_DESCRIPTION: Record<Chakra, string> = {
    [Chakra.Vishuddha]: t(
      'blockedChakras:Vishuddha',
      'you may suffer from headaches, excess weight, and find it hard to stay focused.',
    ) as string,
    [Chakra.Anahata]: t(
      'blockedChakras:Anahata',
      'you may have trust issues, feel indifferent and find it hard to form relationships.',
    ) as string,
    [Chakra.Muladhara]: t(
      'blockedChakras:Muladhara',
      'you may feel emotionally insecure, worried and sleep poorly.',
    ) as string,
    [Chakra.Svadhishthana]: t(
      'blockedChakras:Svadhishthana',
      'you may be scared of change and feel uninspired.',
    ) as string,
    [Chakra.Ajna]: t(
      'blockedChakras:Ajna',
      'you may have poor intuition, health issues and feel introverted.',
    ) as string,
    [Chakra.Sahasrara]: t(
      'blockedChakras:Sahasrara',
      'you may feel disconnected from everyone and everything which might lead you to bad habits.',
    ) as string,
    [Chakra.Manipura]: t(
      'blockedChakras:Manipura',
      'you may have difficulty making decisions and can be taken advantage of easily.',
    ) as string,
  };
  const isPlural = stressCause && stressCause.length > 1;
  const chakraWordForm = isPlural
    ? t('blockedChakras:blockedChackras', 'blocked chakras')
    : t('blockedChakras:blockedChackra', 'a blocked chakra');
  const titleText = `${t('blockedChakras:titleText', 'We found that you have')} ${chakraWordForm}`;

  return (
    <div className={classes.container}>
      <div className={classes.titleContainer}>
        <h2 className={classes.title}>{titleText}</h2>
      </div>
      <div className={classes.imageContainer}>
        <img className={classes.chakrasImage} src={womanWithImagesSet.src} srcSet={womanWithImagesSet.srcSet} />
      </div>
      <div className={classes.descriptionContainer}>
        <h2 className={classes.titleDesktop}>{titleText}</h2>
        {blockedChakras.map((chakra, index) => (
          <div className={classes.descriptionItem} key={`chakra-desc-${index}`}>
            <h3 className={classes.chakraHeader}>
              {t('blockedChakras:whenYour', 'When your')}{' '}
              <span style={{ color: CHAKRAS_COLORS[chakra] }}>{CHAKRAS_TITLE[chakra]}</span>{' '}
              {t('blockedChakras:isBlocked', 'is blocked')}
            </h3>
            <p className={classes.chakraDescription}>{CHAKRAS_DESCRIPTION[chakra]}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BlockedChakras;
