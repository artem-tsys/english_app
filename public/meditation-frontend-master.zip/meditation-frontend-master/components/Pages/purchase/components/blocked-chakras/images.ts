import createCloudinaryImageSet from '../../../../../utils/src-set';

export const womanWithImagesSet = createCloudinaryImageSet(
  '/meditation/purchase-generated/woman_with_chakras_wx9pup.png',
);
