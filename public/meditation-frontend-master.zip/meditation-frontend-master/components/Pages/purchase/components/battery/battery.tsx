import React from 'react';
import { useSelector } from 'react-redux';

import { useTranslation } from '../../../../../i18n';
import { energyLevelSelector } from '../../../../../redux/order/order.selectors';
import { EnergyLevelType } from '../../../../../types/order';
import GraphicCard from '../graphic-card';
const Battery = () => {
  const { t } = useTranslation();
  const energyLevel = useSelector(energyLevelSelector);

  const imageMap: Record<EnergyLevelType, string> = {
    'High-speed': 'High-speed_ho1ich',
    Idle: 'iddle_mvpq2n',
    Dragging: 'Dragging_yegyin',
  };

  const colorMap: Record<EnergyLevelType, string> = {
    'High-speed': 'var(--accentGreenColor)',
    Idle: 'var(--accentYellowColor)',
    Dragging: 'var(--accentRedColor)',
  };

  const batteryEnergyLevelMap = {
    'High-speed': {
      // i18n:extract t('battery:labelHighSpeed', 'High-speed')
      key: 'battery:labelHighSpeed',
      value: 'High-speed',
    },
    Idle: {
      // i18n:extract t('battery:labelIdle', 'Idle')
      key: 'battery:labelIdle',
      value: 'Idle',
    },
    Dragging: {
      // i18n:extract t('battery:labelDragging', 'Dragging')
      key: 'battery:labelDragging',
      value: 'Dragging',
    },
  };

  const color = colorMap[energyLevel];
  const image = imageMap[energyLevel];
  const labelText = batteryEnergyLevelMap[energyLevel];

  return (
    <GraphicCard
      color={color}
      image={image}
      titleText={t('battery:title', 'Energy levels') as string}
      subTitleText={t('battery:subTitleText', 'Your energy is: ') as string}
      labelText={t(labelText.key, labelText.value) as string}
    />
  );
};

export default Battery;
