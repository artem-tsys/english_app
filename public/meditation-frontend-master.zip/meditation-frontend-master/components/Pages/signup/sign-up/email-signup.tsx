import cn from 'classnames';
import React, { useContext, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { emailChanged } from '../../../../redux/signup/signup.actions';
import { isSignupInProgressSelector, signupEmailSelector } from '../../../../redux/signup/signup.selectors';
import uClasses from '../../../../styles/utilities.module.scss';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import signUpContext from './sign-up-context';
import {
  I18N_KEY_TO_VALUE,
  validateConfirmEmail,
  validateConfirmPassword,
  validateEmail,
  validatePassword,
} from './sign-up-validate';
import classes from './sign-up.module.scss';

const isFormValid = (errors) => {
  return Object.keys(errors).filter((fieldName) => !!errors[fieldName]).length === 0;
};

const preventDefault = (e) => e.preventDefault();

const DefaultSubmitButton = () => {
  const { t } = useTranslation();
  const isLoading = useSelector(isSignupInProgressSelector);
  return (
    <button className={uClasses.uGreenWideButton} type="submit" disabled={isLoading} data-button="email-signup-submit">
      {t('signUp:buttonContinue', 'Continue')}
    </button>
  );
};

const EmailSignup = ({ SubmitButton = DefaultSubmitButton }) => {
  const dispatch = useDispatch();
  const email = useSelector(signupEmailSelector) || '';
  const [emailSignupStarted, setEmailSignupStarted] = useState(false);
  const [confirmEmail, setConfirmEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const { initialEmail, requestEmailSignup, signupError } = useContext(signUpContext);

  useEffect(() => {
    dispatch(emailChanged(initialEmail));
  }, []);

  const [validationErrors, setValidationErrors] = useState({
    emailError: null,
    passwordError: null,
    confirmPasswordError: null,
    confirmEmailError: null,
  });
  function validateAndSetErrors({ email, password, confirmPassword, confirmEmail }) {
    const emailError = validateEmail(email);
    const passwordError = validatePassword(password);
    const confirmEmailError = validateConfirmEmail(email, confirmEmail);
    const confirmPasswordError = validateConfirmPassword(password, confirmPassword);
    const errors = { emailError, passwordError, confirmPasswordError, confirmEmailError };

    setValidationErrors({ emailError, passwordError, confirmPasswordError, confirmEmailError });

    return errors;
  }

  // if user stqarted to type confirm paswword we may conclude that he chose email signup
  useEffect(() => {
    if (!emailSignupStarted && confirmEmail.length > 0) {
      setEmailSignupStarted(true);
    }
  }, [confirmEmail]);

  const onEmailChange = (e) => {
    setValidationErrors({ ...validationErrors, emailError: null });
    dispatch(emailChanged(e.target.value));
  };

  const onConfirmEmailChange = (e) => {
    setValidationErrors({ ...validationErrors, confirmEmailError: null });
    setConfirmEmail(e.target.value);
  };

  const onPasswordChange = (e) => {
    setValidationErrors({ ...validationErrors, passwordError: null });
    setPassword(e.target.value);
  };

  const onConfirmPasswordChange = (e) => {
    setValidationErrors({ ...validationErrors, confirmPasswordError: null });
    setConfirmPassword(e.target.value);
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const errors = validateAndSetErrors({ email, password, confirmPassword, confirmEmail });

    if (isFormValid(errors)) {
      requestEmailSignup(password);
    }
  };

  const { t } = useTranslation();

  const { emailError, passwordError, confirmPasswordError, confirmEmailError } = validationErrors;

  return (
    <>
      <form onSubmit={onSubmit}>
        <p className={classes.instruction}>{t('signUp:instruction', 'Enter your email and create a password')}</p>
        <div className={classes.inputRow}>
          <input
            className={cn(uClasses.uInput, { [uClasses.isInvalid]: !!emailError })}
            value={email}
            type="email"
            name="email"
            onChange={onEmailChange}
            placeholder={t('signUp:enterEmail', 'Enter your email to get your plan')}
            data-input="email-signup-email"
          />
          {emailError && <div className={classes.error}>{t(emailError, I18N_KEY_TO_VALUE[emailError])}</div>}
        </div>
        <div className={classes.inputRow}>
          <input
            className={cn(uClasses.uInput, { [uClasses.isInvalid]: !!confirmEmailError })}
            value={confirmEmail}
            onChange={onConfirmEmailChange}
            type="email"
            onPaste={preventDefault}
            placeholder={t('signUp:confirmEmail', 'Confirm your email')}
            data-input="email-signup-email-confirm"
          />
          {confirmEmailError && (
            <div className={classes.error}>{t(confirmEmailError, I18N_KEY_TO_VALUE[confirmEmailError])}</div>
          )}
        </div>
        <div className={classes.inputRow}>
          <input
            className={cn(uClasses.uInput, { [uClasses.isInvalid]: !!passwordError })}
            value={password}
            onChange={onPasswordChange}
            type="password"
            placeholder={t('signUp:enterPassword', 'Password')}
            data-input="email-signup-password"
          />
          {passwordError && <div className={classes.error}>{t(passwordError, I18N_KEY_TO_VALUE[passwordError])}</div>}
        </div>
        <div className={classes.inputRow}>
          <input
            className={cn(uClasses.uInput, { [uClasses.isInvalid]: !!confirmPasswordError })}
            value={confirmPassword}
            onChange={onConfirmPasswordChange}
            type="password"
            onPaste={preventDefault}
            placeholder={t('signUp:confirmPassword', 'Confirm your password')}
            data-input="email-signup-password-confirm"
          />
          {confirmPasswordError && (
            <div className={classes.error}>{t(confirmPasswordError, I18N_KEY_TO_VALUE[confirmPasswordError])}</div>
          )}
          {signupError && <div className={classes.mainError}>{signupError}</div>}
        </div>

        <div className={classes.btn}>
          <SubmitButton />
        </div>
      </form>
    </>
  );
};

export default EmailSignup;
