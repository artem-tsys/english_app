import cn from 'classnames';
import React, { useContext, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { v4 as uuidv4 } from 'uuid';

import { appleSignInClientId, isInBrowser } from '../../../../config';
import { useScript } from '../../../../hooks/use-script.hook';
import { appleSignupErrorSelector } from '../../../../redux/signup/signup.selectors';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import AppleIcon from '../../../Shared/Elements/apple-icon';
import Loader from '../../../Shared/Elements/loader/loader';
import signUpContext from './sign-up-context';
import classes from './sign-up.module.scss';

declare global {
  interface Window {
    AppleID: any;
  }
}

const APPLE_SDK_SCRIPT_SRC = 'https://appleid.cdn-apple.com/appleauth/static/jsapi/appleid/1/en_US/appleid.auth.js';
const SCOPE = 'email';
// redirect uri is not used in current flow, just a placholder in case
const REDIRECT_URI = isInBrowser ? `${window.location.origin}/signup` : null;

const AppleSignup = () => {
  const { t } = useTranslation();
  const [isScriptLoaded, isScriptError] = useScript(APPLE_SDK_SCRIPT_SRC);
  const [isSignupRequested, setIsSignupRequested] = useState(false);
  const signupError = useSelector(appleSignupErrorSelector);
  const { authorizeAppleSignup } = useContext(signUpContext);

  useEffect(() => {
    if (isScriptLoaded) {
      window.AppleID.auth.init({
        clientId: appleSignInClientId,
        scope: SCOPE,
        redirectURI: REDIRECT_URI,
        state: uuidv4(),
        usePopup: true,
      });
    }
  }, [isScriptLoaded]);

  const startSignUp = async () => {
    try {
      const data = await window.AppleID.auth.signIn();

      authorizeAppleSignup(data.authorization.code);
    } catch (e) {
      // we do nothing, the only error dispatched by apple is when user closes popup
      // no action required in this case
    }
  };

  const onClick = () => {
    if (isScriptError) return;

    if (isScriptLoaded) {
      startSignUp();
    } else {
      // we need to register user's click on button in case script was not loaded and
      // start a popup after script is loaded
      setIsSignupRequested(true);
    }
  };

  useEffect(() => {
    if (isSignupRequested && isScriptLoaded) {
      startSignUp();
    }
  }, [isSignupRequested, isScriptLoaded]);

  // we show loading only if script is loading and user already clicked on a button
  const shouldIndicateLoading = !isScriptLoaded && isSignupRequested;

  return (
    <>
      <div className={classes.signinWithAppleContainer}>
        {shouldIndicateLoading && <Loader isShown />}
        <>
          <button
            className={cn(classes.signinWithApple, { [classes.isDisabled]: isScriptError })}
            onClick={onClick}
            data-button="apple-signup"
          >
            <AppleIcon className={classes.appleLogo} />
            {t('signUp:buttonAppleSignup', 'Sign in with Apple')}
          </button>
          {signupError && <div className={classes.mainError}>{signupError}</div>}
        </>
      </div>
    </>
  );
};

export default AppleSignup;
