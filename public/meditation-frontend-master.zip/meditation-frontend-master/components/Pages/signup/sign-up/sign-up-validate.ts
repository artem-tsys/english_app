const emailRegex = /^[a-zA-Z0-9!#$%&\'*+\/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&\'*+\/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/;

export const I18N_KEY_TO_VALUE = {
  // i18n:extract t('signUpValidate:empty', `This field shouldn't be empty`)
  'signUpValidate:empty': `This field shouldn't be empty`,
  // i18n:extract t('signUpValidate:invalid', 'Email seems to be invalid')
  'signUpValidate:invalid': 'Email seems to be invalid',
  // i18n:extract t('signUpValidate:emailsDoNotMatch', 'Emails do not match')
  'signUpValidate:emailsDoNotMatch': 'Emails do not match',
  // i18n:extract t('signUpValidate:passwordsDoNotMatch', 'Passwords do not match')
  'signUpValidate:passwordsDoNotMatch': 'Passwords do not match',
  // i18n:extract t('signUpValidate:passwordRequirementsLength', 'Password should have at least 6 symbols and less then 24 symbols')
  'signUpValidate:passwordRequirementsLength': 'Password should have at least 6 symbols and less then 24 symbols',
  // i18n:extract t('signUpValidate:passwordRequirementsSimple', 'Password should include only symbols or letters')
  'signUpValidate:passwordRequirementsSimple': 'Password should include only symbols or letters',
};

export const validateEmail = (email) => {
  if (!email) return 'signUpValidate:empty';
  const isValid = emailRegex.test(email);
  return isValid ? null : 'signUpValidate:invalid';
};

export const validateConfirmEmail = (email, confirmEmail) => {
  const isValid = email === confirmEmail;

  return isValid ? null : 'signUpValidate:emailsDoNotMatch';
};

export const validateConfirmPassword = (password, confirmPassword) => {
  const isValid = password === confirmPassword;

  return isValid ? null : 'signUpValidate:passwordsDoNotMatch';
};

const passwordRegex = /^[A-Za-z\d@$!%*#?&.\-]{6,24}$/i;
const MIN_PASSWORD = 6;
const MAX_PASSWORD = 24;
export const validatePassword = (password) => {
  const isTooLongOrTooShort = password.length < MIN_PASSWORD || password.length > MAX_PASSWORD;
  if (isTooLongOrTooShort) return 'signUpValidate:passwordRequirementsLength';

  const isValid = passwordRegex.test(password);

  return isValid ? null : 'signUpValidate:passwordRequirementsSimple';
};
