import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Trans } from '../../../../i18n';
import { orderEmailSelector, signupMethodSelector } from '../../../../redux/order/order.selectors';
import { signupPageInit } from '../../../../redux/signup/signup.actions';
import { hasGDPRValueSelector, isSignupInProgressSelector } from '../../../../redux/signup/signup.selectors';
import { notifyOnError } from '../../../../utils/error-tracking';
import getMobileOs from '../../../../utils/get-mobile-os';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import Loader from '../../../Shared/Elements/loader/loader';
import AppleSignup from './apple-signup';
import EmailSignup from './email-signup';
import SignUpProvider from './sign-up-provider.container';
import classes from './sign-up.module.scss';
import AlreadyUsed from './sing-up-used';

interface SignUpProps {
  Title?: () => JSX.Element;
  SubmitButton?: () => JSX.Element;
}
//Todo : Add Trans
const SignUp = ({ Title, SubmitButton }: SignUpProps) => {
  const dispatch = useDispatch();
  {
    /* i18n:extract t('signUp:title', 'Please finish your<0/> <1>registration</1>') */
  }
  const DefaultTitle = () => (
    <span>
      {/* i18n:extract t('signUp:defaultTitle', 'Create an account to <0>access the app</0>') */}
      <Trans i18nKey="signUp:defaultTitle" components={[<b key="0" />]} />
    </span>
  );
  const SignUpTitle = Title || DefaultTitle;

  useEffect(() => {
    dispatch(signupPageInit());
  }, []);

  useEffect(() => {
    try {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth',
      });
    } catch (e) {
      notifyOnError('[SignUp] No scrollTo method on window object');
    }
  }, []);

  const isSignupInProgress = useSelector(isSignupInProgressSelector);
  const hasGDPRValue = useSelector(hasGDPRValueSelector);
  const email = useSelector(orderEmailSelector);
  const { t } = useTranslation();
  const isUserSignedUp = useSelector(signupMethodSelector);
  const isAndroid = getMobileOs() === 'Android';
  const isDeveloper = email === 'alforov.ievgen@betterme.world';

  if (isUserSignedUp && !isSignupInProgress) {
    return (
      <div className={classes.signupPage}>
        <main className={classes.container}>
          <AlreadyUsed />
        </main>
      </div>
    );
  }

  return (
    <div className={classes.signupPage}>
      <main className={classes.container}>
        <article>
          <div className={classes.header}>
            <SignUpTitle />
          </div>
          <SignUpProvider>
            <EmailSignup SubmitButton={SubmitButton} />
            {!isAndroid && isDeveloper && (
              <>
                <div className={classes.buttonSeparator}>{t('signUp:orLabel', 'or')}</div>
                <AppleSignup />
              </>
            )}
          </SignUpProvider>
          {!hasGDPRValue && (
            <div className={classes.agreeTerms}>
              {t('signUp:agreeTerms', 'By signing up you agree to our terms and conditions')}
            </div>
          )}
          <Loader isShown={isSignupInProgress} />
        </article>
      </main>
    </div>
  );
};

export default SignUp;
