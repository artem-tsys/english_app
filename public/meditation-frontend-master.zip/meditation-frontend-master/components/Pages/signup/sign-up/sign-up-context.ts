import React from 'react';

interface SignUpContext {
  requestEmailSignup: (password: string) => void;
  authorizeAppleSignup: (code: string) => void;
  signupError: string;
  initialEmail: string;
}

const signUpContext = React.createContext<SignUpContext>(null);

export default signUpContext;
