import createCloudinaryImageSet from '../../../../utils/src-set';

export const exclamationImageSet = createCloudinaryImageSet(`/public/images/exclamation/exclamation-4x.png`);

const images = {
  exclamationImageSet,
};

export default images;
