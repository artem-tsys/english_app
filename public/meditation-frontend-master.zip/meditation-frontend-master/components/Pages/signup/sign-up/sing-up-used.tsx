import { useRouter } from 'next/router';
import React from 'react';
import { useSelector } from 'react-redux';

import {
  orderAmountSelector,
  questionaryVersionSelector,
  signupMethodSelector,
} from '../../../../redux/order/order.selectors';
import Trans from '../../../../utils/next-with-i18n/trans';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import Button from '../../../Shared/Elements/button/button';
import { exclamationImageSet } from './images';
import classes from './sign-up.module.scss';

const AlreadyUsed = () => {
  const { t } = useTranslation();
  const router = useRouter();

  const callSupport = (e) => {
    e.preventDefault();
    if (router.asPath.indexOf('#support') === -1) {
      router.push(`${router.asPath}#support`);
    }
    router.reload();
  };

  const amount = useSelector(orderAmountSelector);
  const signupMethod = useSelector(signupMethodSelector);
  const questionaryVersion = useSelector(questionaryVersionSelector);

  const appLink = `https://better-wl.onelink.me/sS7F?pid=web_onboarding_${signupMethod}&c=${questionaryVersion}&af_adset=${amount}`;

  const openApp = (e) => {
    e.preventDefault();
    window.location.href = appLink;
  };

  return (
    <div className={classes.alreadySignedUpContent}>
      <div className={classes.warningIcon}>
        <img className={classes.warningIconImg} src={exclamationImageSet.src} srcSet={exclamationImageSet.srcSet} />
      </div>
      <div className={classes.header}>{t('signUp:important', 'Important!')}</div>
      <span className={classes.message}>
        {/* i18n:extract t('signUp:signedUp', 'You have already signed up — now you <1/> can sign-in in the <0>BetterMe app</0>.') */}
        <Trans i18nKey="signUp:signedUp" components={[<b key="0" />, <br key="1" />]} />
      </span>
      <div className={classes.infoContainer}>
        {t('signUp:infoContainer', 'In case you have any issues please reach out to our')}{' '}
        <a className={classes.supportLink} onClick={(e) => callSupport(e)}>
          {t('signUp:friendly', 'friendly support team')}
        </a>
        .
      </div>
      <Button onClick={(e) => openApp(e)} fullWidth>
        {t('signUp:signIn', 'Sign in')}
      </Button>
    </div>
  );
};

export default AlreadyUsed;
