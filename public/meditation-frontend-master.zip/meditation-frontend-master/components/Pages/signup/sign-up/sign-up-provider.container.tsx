import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { orderEmailSelector } from '../../../../redux/order/order.selectors';
import { appleSignupAuthorized, emailSignupRequested } from '../../../../redux/signup/signup.actions';
import { signupErrorSelector } from '../../../../redux/signup/signup.selectors';
import SignUpContext from './sign-up-context';
const { Provider } = SignUpContext;

const SignUpProvider = ({ children }) => {
  const dispatch = useDispatch();

  const requestEmailSignup = (password) => dispatch(emailSignupRequested(password));
  const authorizeAppleSignup = (code) => dispatch(appleSignupAuthorized(code));
  const signupError = useSelector(signupErrorSelector);
  const initialEmail = useSelector(orderEmailSelector);

  return (
    <Provider
      value={{
        requestEmailSignup,
        authorizeAppleSignup,
        signupError,
        initialEmail,
      }}
    >
      {children}
    </Provider>
  );
};

export default SignUpProvider;
