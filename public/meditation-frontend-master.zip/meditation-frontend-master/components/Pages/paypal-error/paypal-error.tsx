import React from 'react';
import { useSelector } from 'react-redux';

import { useTranslation } from '../../../i18n';
import { orderHashSelector } from '../../../redux/order/order.selectors';
import useFunnel from '../../../utils/funnel-navigation/react/use-funnel-hook';
import Router from '../../../utils/next-with-i18n/router';
import Button from '../../Shared/Elements/button/button';
import { crossImageSet } from './images';
import classes from './paypal-error.module.scss';

function PaypalError() {
  const orderHash = useSelector(orderHashSelector);
  const { t } = useTranslation();
  const checkoutPath = useFunnel().checkoutPage;

  const onClick = () => {
    Router.push(`${checkoutPath}?order=${orderHash}&showPaymentPopup=true`);
  };
  return (
    <main className={classes.container}>
      <div className={classes.content}>
        <div className={classes.errorIcon}>
          <img className={classes.errorIconImg} src={crossImageSet.src} srcSet={crossImageSet.srcSet} />
        </div>
        <span className={classes.title}>{t('paypalError:title', 'Ooops')}</span>
        <span className={classes.subTitle}>{t('paypalError:subTitle', 'Sorry, your transaction failed.')}</span>
        <Button onClick={onClick} fullWidth dataButton="paypal-error-try-again">
          {t('paypalError:try', 'TRY AGAIN')}
        </Button>
      </div>
    </main>
  );
}

export default PaypalError;
