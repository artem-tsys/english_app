import createCloudinaryImageSet from '../../../utils/src-set';

export const crossImageSet = createCloudinaryImageSet(`/public/images/cross/cross-4x.png`);

const images = {
  crossImageSet,
};

export default images;
