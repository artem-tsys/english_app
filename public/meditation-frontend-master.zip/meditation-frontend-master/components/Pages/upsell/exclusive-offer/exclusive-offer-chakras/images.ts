import createCloudinaryImageSet from '../../../../../utils/src-set';

export const giftSet = createCloudinaryImageSet(`/public/images/small-gift/small-gift-4x.png`);

export const moonSet = createCloudinaryImageSet(`meditation/emojis/waxing_gibbous_moon_ykbgux`);

export const womanMassageSet = createCloudinaryImageSet(`meditation/emojis/woman_getting_massage_huxk9g`);
