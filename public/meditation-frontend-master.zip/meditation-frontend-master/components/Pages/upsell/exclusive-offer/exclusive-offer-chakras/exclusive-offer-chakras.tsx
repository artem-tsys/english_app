import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

import addPricesToUpsellPlans from '../../../../../business-logic/get-upsell-plan-amount.logic';
import { UPSELL_CHAKRAS_PLANS, UpsellPlanId } from '../../../../../constants/order.constants';
import { orderAmountSelector } from '../../../../../redux/order/order.selectors';
import { ImageSet } from '../../../../../utils/src-set';
import PulsingButton from '../../../../Shared/Elements/pulsing-button';
import ExclusiveOfferNoDescription from '../components/exclusive-offer-no-description';
import { giftSet, moonSet, womanMassageSet } from './images';

const PLAN_IMAGES: Partial<Record<UpsellPlanId, ImageSet>> = {
  [UpsellPlanId.ChakrasSleepAndStress]: giftSet,
  [UpsellPlanId.ChakrasSleep]: moonSet,
  [UpsellPlanId.ChakrasStress]: womanMassageSet,
};

const PRIMARY_PLAN = UpsellPlanId.ChakrasSleepAndStress;

const benefitList = [
  {
    // i18n:extract t('exclusiveOffer:autoRenewablePlan', 'Auto-renewable plan, cancel anytime')
    key: 'exclusiveOffer:autoRenewablePlan',
    value: 'Auto-renewable plan, cancel anytime',
  },
  {
    // i18n:extract t('exclusiveOffer:intensivePrograms', 'Intensive programs to repeat indefinitely')
    key: 'exclusiveOffer:intensivePrograms',
    value: 'Intensive programs to repeat indefinitely',
  },
  {
    // i18n:extract t('exclusiveOffer:resultInJustAMonth', 'Results that you will feel in just a month')
    key: 'exclusiveOffer:resultInJustAMonth',
    value: 'Results that you will feel in just a month',
  },
  {
    // i18n:extract t('exclusiveOffer:minimalEffortMaximumResult', 'Minimal effort, maximum result')
    key: 'exclusiveOffer:minimalEffortMaximumResult',
    value: 'Minimal effort, maximum result',
  },
];

const ExclusiveOfferChakras = () => {
  const [selectedPlan, setSelectedPlan] = useState(null);

  useEffect(() => {
    if (selectedPlan === null) {
      setSelectedPlan(UpsellPlanId.ChakrasSleepAndStress);
    }
  }, [selectedPlan]);

  const mainPlanPrice = useSelector(orderAmountSelector);
  const PLANS = addPricesToUpsellPlans(UPSELL_CHAKRAS_PLANS, UPSELL_CHAKRAS_PLANS, mainPlanPrice);

  return (
    <ExclusiveOfferNoDescription
      primaryPlan={PRIMARY_PLAN}
      discountPrimaryPlan={null}
      Button={PulsingButton}
      plans={PLANS}
      planImages={PLAN_IMAGES}
      benefitList={benefitList}
    />
  );
};

export default ExclusiveOfferChakras;
