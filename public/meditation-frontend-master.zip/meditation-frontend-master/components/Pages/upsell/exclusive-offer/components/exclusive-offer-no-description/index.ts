export { default } from './exclusive-offer-no-description';
