import cn from 'classnames';
import React, { CSSProperties, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { calculatePlanDiscountPercentage } from '../../../../../../business-logic/calculate-plan-discount-percentage.logic';
import { UpsellPlanFriendId, UpsellPlanId, UpsellPlans } from '../../../../../../constants/order.constants';
import { viewUpsellDobivashkaAction } from '../../../../../../redux/analytics/analytics.actions';
import { showPopup } from '../../../../../../redux/general/common.actions';
import {
  isAdditionalDiscountAppliedSelector,
  isUpsellAdditionalDiscountAppliedSelector,
  planSnapshotSelector,
} from '../../../../../../redux/order/order.selectors';
import { initUpsellPage, skipUpsell, upsellRequested } from '../../../../../../redux/upsell/upsell.actions';
import { SkipToFriendUpsellAction, SkipUpsellAction } from '../../../../../../redux/upsell/upsell.interfaces';
import { isPayWithTokenLoadingSelector } from '../../../../../../redux/upsell/upsell.selectors';
import { formatPrice } from '../../../../../../utils/format-price.util';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import { ImageSet } from '../../../../../../utils/src-set';
import Checkbox from '../../../../../Shared/Elements/checkbox/checkbox';
import LegalExclusiveOffer from '../../../../../Shared/Elements/legal/legal-exclusive-offer';
import Loader from '../../../../../Shared/Elements/loader/loader';
import SelectableCard from '../../../../../Shared/Elements/selectable-card/selectable-card';
import ArrowSkip from '../arrow-skip';
import { ExclusiveOfferHeaderTheme } from '../exclusive-offer-header/default-theme';
import ExclusiveOfferHeader from '../exclusive-offer-header/exclusive-offer-header';
import { upsellDiscountSet } from '../images';
import defaultTheme, { ExclusiveOfferNoDescriptionTheme } from './default-theme';
import classes from './exclusive-offer-no-description.module.scss';

interface ExclusiveOfferNoDescriptionProps {
  primaryPlan: UpsellPlanId;
  discountPrimaryPlan: UpsellPlanId;
  Button: React.ComponentType<any>;
  plans: UpsellPlans;
  planImages: Partial<Record<UpsellPlanId, ImageSet>>;
  benefitList: {
    key: string;
    value: string;
  }[];
  theme?: ExclusiveOfferNoDescriptionTheme;
  headerTheme?: ExclusiveOfferHeaderTheme;
  requestUpsellAction?: (planId: UpsellPlanId | UpsellPlanFriendId) => any;
  skipUpsellAction?: () => SkipUpsellAction | SkipToFriendUpsellAction;
}
const ExclusiveOfferNoDescription = ({
  primaryPlan,
  discountPrimaryPlan,
  Button,
  plans,
  planImages,
  benefitList,
  theme = defaultTheme,
  headerTheme,
  requestUpsellAction = upsellRequested,
  skipUpsellAction = skipUpsell,
}: ExclusiveOfferNoDescriptionProps) => {
  const isUpsellAdditionalDiscountApplied = useSelector(isUpsellAdditionalDiscountAppliedSelector);
  const isAdditionalDiscountApplied = useSelector(isAdditionalDiscountAppliedSelector);
  const isPrimaryPlan = (planId: UpsellPlanId | UpsellPlanFriendId) =>
    isUpsellAdditionalDiscountApplied ? planId === discountPrimaryPlan : planId === primaryPlan;
  const { t, lang } = useTranslation();
  const gender = 'female';
  const dispatch = useDispatch();
  const [selectedPlan, setSelectedPlan] = useState(null);
  const isOneClickLoading = useSelector(isPayWithTokenLoadingSelector);
  const mainPlan = useSelector(planSnapshotSelector);
  const buttonText = t('exclusiveOfferNoDescription:onAddToPlanClick', 'Add to my plan');

  useEffect(() => {
    isUpsellAdditionalDiscountApplied && dispatch(viewUpsellDobivashkaAction('purchasing'));
  }, [isUpsellAdditionalDiscountApplied]);

  useEffect(() => {
    dispatch(initUpsellPage());
  }, []);

  useEffect(() => {
    try {
      window.scrollTo(0, 0);
    } catch (e) {}
  }, []);

  useEffect(() => {
    isUpsellAdditionalDiscountApplied && setSelectedPlan(discountPrimaryPlan);
  }, [isUpsellAdditionalDiscountApplied, discountPrimaryPlan]);

  useEffect(() => {
    if (selectedPlan === null) {
      setSelectedPlan(primaryPlan);
    }
  }, [gender, selectedPlan]);

  useEffect(() => {
    setSelectedPlan(primaryPlan);
  }, [primaryPlan]);

  const handleSkipDefault = () => dispatch(skipUpsellAction());

  const onSkip = () => {
    !isAdditionalDiscountApplied && !isUpsellAdditionalDiscountApplied
      ? dispatch(showPopup('UPSELL_ADDITIONAL_DISCOUNT_POPUP'))
      : handleSkipDefault();
  };

  const selectPlan = (e) => {
    const planId = e.currentTarget.dataset.cardId;

    setSelectedPlan(planId);
  };

  const onAddToPlanClick = () => {
    dispatch(requestUpsellAction(selectedPlan));
  };

  const discountImage = isUpsellAdditionalDiscountApplied ? upsellDiscountSet : null;

  const PLANS = isUpsellAdditionalDiscountApplied ? plans.upsellPlansDobivashka : plans.upsellPlans;

  const selectedUpsellPlan = PLANS.find((plan) => plan.id === selectedPlan);
  const upsellDiscountedPrice = selectedUpsellPlan?.discountedPrice ?? 0;
  return (
    <div className={classes.page} style={theme as CSSProperties}>
      <ExclusiveOfferHeader theme={headerTheme} handleSkip={onSkip} />
      {isOneClickLoading && <Loader isShown />}

      <main className={classes.container}>
        {isUpsellAdditionalDiscountApplied && (
          <img src={discountImage.src} srcSet={discountImage.srcSet} className={classes.discountImage} alt="" />
        )}

        <div className={classes.titleContainer}>
          <h1 className={cn({ [classes.headerContainsImage]: !!discountImage }, classes.title)}>
            {isUpsellAdditionalDiscountApplied
              ? t('exclusiveOffer02:header', 'Additional discount applied just for you')
              : t('exclusiveOfferNoDescription:header', 'Exclusive sign-up offer')}
          </h1>
        </div>
        <>
          {PLANS.map((plan) => {
            const { i18nKey, name, id, discountedPrice, amount } = plan;
            const { src, srcSet } = planImages[id];
            const isSelected = selectedPlan === id;
            const discount = calculatePlanDiscountPercentage(plan);
            const discountAmount = Math.round(discount * 100);

            return (
              <SelectableCard
                isSelected={isSelected}
                key={id}
                dataCardId={id}
                onClick={selectPlan}
                className={cn(classes.card, { [classes.isSelected]: isSelected })}
              >
                <img src={src} srcSet={srcSet} className={classes.planLogo} />
                <div className={classes.planContent}>
                  <div className={classes.planName}>{t(i18nKey, name)}</div>
                  <div className={classes.sellLabels}>
                    <div className={classes.prices}>
                      <span className={classes.price}>
                        {isPrimaryPlan(id) ? (
                          <>
                            {formatPrice(discountedPrice, { locale: lang })}{' '}
                            {t('exclusiveOfferNoDescription:only', 'only!')}
                          </>
                        ) : (
                          formatPrice(discountedPrice, { locale: lang })
                        )}
                      </span>

                      <div className={classes.salePrices}>
                        <span className={classes.originalPrice}>{formatPrice(amount, { locale: lang })}</span>
                        <span className={classes.saveLabel}>
                          {discountAmount}% {t('exclusiveOfferNoDescription:off', 'OFF')}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <Checkbox
                  isChecked={isSelected}
                  className={classes.checkbox}
                  dataCheckbox="exclusive-offer-no-description"
                />
              </SelectableCard>
            );
          })}
        </>
        <div className={classes.footerContainer}>
          <ul className={classes.planBenefits}>
            {benefitList.map(({ key, value }) => {
              return (
                <li key={key}>
                  <Checkbox
                    isChecked={true}
                    className={classes.checkboxBenefits}
                    dataCheckbox="exclusive-offer-no-description-benefit"
                  />
                  {t(key, value)}
                </li>
              );
            })}
          </ul>
          <div className={classes.buttonBlock}>
            <Button onClick={onAddToPlanClick}>{buttonText}</Button>
          </div>
        </div>
        <div className={classes.skipLabel} onClick={onSkip}>
          {t('exclusiveOfferNoDescription:skipAndContinue', 'Skip this and continue enrollment')}
          <ArrowSkip className={classes.arrowSkip} />
        </div>
        <div className={classes.legalText}>
          <LegalExclusiveOffer days={mainPlan.days} discountedPrice={upsellDiscountedPrice} buttonText={buttonText} />
        </div>
      </main>
    </div>
  );
};

export default ExclusiveOfferNoDescription;
