import React from 'react';

const ArrowSkip = ({ className }) => (
  <svg width={12} height={16} viewBox="0 0 12 16" className={className}>
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M10.864.447a1.475 1.475 0 010 2.158L5.198 8l5.665 5.396a1.475 1.475 0 010 2.158 1.66 1.66 0 01-2.266 0L.667 8V8L8.596.447a1.66 1.66 0 012.267 0z"
    />
  </svg>
);

export default ArrowSkip;
