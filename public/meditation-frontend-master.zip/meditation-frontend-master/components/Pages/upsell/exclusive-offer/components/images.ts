import createCloudinaryImageSet from '../../../../../utils/src-set';

export const upsellDiscountSet = createCloudinaryImageSet('discount_kwudox');
