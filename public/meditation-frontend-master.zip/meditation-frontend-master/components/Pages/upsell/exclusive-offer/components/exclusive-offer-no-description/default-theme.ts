const defaultTheme = {
  '--titleColor': 'var(--neutral900Color)',
  '--containerBackgroundColor': 'var(--background3Color)',
  '--cardBorderColor': 'var(--neutral300Color)',
  '--planLogoColor': 'rgba(217, 227, 252, 0.4)',
  '--selectedCardColor': 'var(--whiteColor)',
  '--selectedCheckboxColor': 'var(--primary400Color)',
  '--oldPriceFontSize': '10px',
  '--oldPriceLineHeight': '1.8',
  '--checkboxBorderColor': 'var(--neutral300Color)',
  '--planTextColor': 'var(--neutral700Color)',
  '--oldPriceColor': 'var(--neutral900Color)',
  '--skipLabelColor': 'var(--neutral500Color)',
  '--checkmarkColor': 'var(--whiteColor)',
} as const;

export type ExclusiveOfferNoDescriptionTheme = Record<keyof typeof defaultTheme, string>;

export default defaultTheme;
