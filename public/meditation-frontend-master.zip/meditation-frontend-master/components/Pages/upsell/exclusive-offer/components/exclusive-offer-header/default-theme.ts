const defaultHeaderTheme = {
  '--headerBackgroundMobile': 'transparent',
  '--headerBackgroundDesktop': 'var(--background1Color)',
  '--headerDesktopShadow': '0 2px 10px rgba(22, 42, 65, 0.08)',
  '--skipArrowColor': 'var(--neutral500Color)',
} as const;

export type ExclusiveOfferHeaderTheme = Record<keyof typeof defaultHeaderTheme, string>;

export default defaultHeaderTheme;
