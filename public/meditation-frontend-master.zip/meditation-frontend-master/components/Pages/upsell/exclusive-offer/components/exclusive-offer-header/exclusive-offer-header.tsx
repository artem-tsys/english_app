import React, { CSSProperties } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import {
  generatedLandingPageUrlSelector,
  generatedLogoSetSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import { skipUpsell } from '../../../../../../redux/upsell/upsell.actions';
import Link from '../../../../../../utils/next-with-i18n/link';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import { ImageSet } from '../../../../../../utils/src-set';
import ArrowSkip from '../arrow-skip';
import defaultHeaderTheme, { ExclusiveOfferHeaderTheme } from './default-theme';
import classes from './exclusive-offer-header.module.scss';

interface Props {
  logoSet?: ImageSet;
  theme?: ExclusiveOfferHeaderTheme;
  handleSkip?: () => void;
}

const ExclusiveOfferHeader: React.FunctionComponent<Props> = ({ logoSet, theme = defaultHeaderTheme, handleSkip }) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const homePage = useSelector(generatedLandingPageUrlSelector);
  const generatedLogoSet = useSelector(generatedLogoSetSelector);
  const headerLogoSet = logoSet || generatedLogoSet;

  const handleSkipDefault = () => {
    dispatch(skipUpsell());
  };

  const onSkipButtonClick = () => {
    handleSkip ? handleSkip() : handleSkipDefault();
  };

  return (
    <header className={classes.header} style={theme as CSSProperties}>
      <div className={classes.headerLeft} />
      <Link href={homePage}>
        <a>
          <img className={classes.logo} src={headerLogoSet.src} srcSet={headerLogoSet.srcSet} />
        </a>
      </Link>
      <div className={classes.headerRight}>
        <span className={classes.skip} onClick={onSkipButtonClick}>
          {t('exclusiveOfferHeader:skipButton', 'Skip')}
          <ArrowSkip className={classes.arrowSkip} />
        </span>
      </div>
    </header>
  );
};

export default ExclusiveOfferHeader;
