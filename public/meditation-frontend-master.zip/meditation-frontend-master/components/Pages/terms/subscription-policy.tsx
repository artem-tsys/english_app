import React from 'react';
import { useSelector } from 'react-redux';

import { generatedLandingPageUrlSelector } from '../../../redux/generated-quiz/generated-quiz.selectors';
import Link from '../../../utils/next-with-i18n/link';
import { androidDevice, iosDevice, webDevice } from './images';
import classes from './static-content.module.scss';

//Todo: add translation
function SubscriptionPolicy() {
  const anchorStyle = { top: `-30px` };
  const homePage = useSelector(generatedLandingPageUrlSelector);

  return (
    <div className={classes.privacy}>
      <span className={classes.anchor} id="subscription-policy" style={anchorStyle} />
      <h1>SUBSCRIPTION TERMS</h1>

      <h2>TABLE OF CONTENTS</h2>
      <nav>
        <ol>
          <li>
            <a href="#subscription-section-1">FREE OR PAID TRIAL</a>
          </li>
          <li>
            <a href="#subscription-section-2">SUBSCRIPTION</a>
          </li>
          <li>
            <a href="#subscription-section-3">PAYMENT METHOD</a>
          </li>
          <li>
            <a href="#subscription-section-4">CANCELATION</a>
          </li>
          <li>
            <a href="#subscription-section-5">REFUNDS</a>
          </li>
          <li>
            <a href="#subscription-section-6">CHANGES</a>
          </li>
        </ol>
      </nav>

      <ol className="main">
        <li>
          <h3>
            <div className={classes.anchor} id="subscription-section-1" style={anchorStyle} />
            FREE OR PAID TRIAL
          </h3>
          <p>
            We may offer a free or paid (for a small payment) trial subscription for service. Unless you cancel at least
            24 hours before the end of the trial, you will be automatically charged a price indicated on the payment
            screen or/and Apple’s/Google’s payment pop-up screen for a chosen subscription period. Please note that if a
            trial is offered, this will be explicitly stated on the price screen before the checkout. If this is not the
            case, you will purchase our subscription without a trial.
          </p>
        </li>

        <li>
          <h3>
            <div className={classes.anchor} id="subscription-section-2" style={anchorStyle} />
            SUBSCRIPTION
          </h3>
          <p>
            The subscription renews automatically at the end of each period (each week, month, 6 months, year, or
            otherwise, depending on the option selected by you at the time of purchase) until you cancel.
          </p>
        </li>
        <li>
          <h3>
            <div className={classes.anchor} id="subscription-section-3" style={anchorStyle} />
            PAYMENT METHOD
          </h3>
          <p>
            Payment will be charged to the payment method you submitted at the time of purchase at confirmation of
            purchase (after you confirm by single-touch identification, facial recognition, or entering your payment
            method details on the web, or otherwise accepting subscription terms provided on the payment screen or on
            the pop-up screen provided by Apple/Google or on our web page) or after the end of the trial period. You
            authorize us to charge the applicable subscription fees to the payment method that you use.
          </p>
        </li>

        <li>
          <h3>
            <div className={classes.anchor} id="subscription-section-4" style={anchorStyle} />
            CANCELATION
          </h3>
          <p>
            Your subscription renews automatically at the end of each period until you cancel. Note that deleting the
            app does not cancel your subscriptions.
          </p>
          <ul>
            <li>
              <p>
                <b>If you purchased a subscription or enabled trial on the App Store:</b>
                <br />
                You may cancel a free trial or a subscription anytime by turning off auto-renewal through your Apple ID
                account settings. To avoid being charged, cancel the subscription in your Apple ID account settings at
                least 24 hours before the end of the free trial or the current subscription period. You alone can manage
                your subscriptions. Learn more about managing subscriptions (and how to cancel them) on{' '}
                <a href="https://support.apple.com/en-ca/HT202039">Apple support page</a>.
              </p>
            </li>
            <li>
              <p>
                <b>If you purchased a subscription or enabled trial on Google Play:</b>
                <br />
                You may cancel a free trial or a subscription anytime by turning off auto-renewal through your Google
                Play account settings. To avoid being charged, cancel the subscription in your account settings at least
                24 hours before the end of the trial or the current subscription period. You alone can manage your
                subscriptions. Learn more about managing subscriptions (and how to cancel them) on{' '}
                <a href="https://support.apple.com/en-ca/HT202039">Google’s support page</a>.
              </p>
            </li>
            <li>
              <p>
                <b>If you purchased a subscription or enabled trial on Huawei AppGallery:</b>
                <br />
                You may cancel a free trial or a subscription anytime by turning off auto-renewal through your Huawei
                account settings. To avoid being charged, cancel the subscription in your account settings at least 24
                hours before the end of the trial or the current subscription period. You alone can manage your
                subscriptions. Learn more about managing subscriptions (and how to cancel them) on{' '}
                <a href="https://consumer.huawei.com/eg-en/support/content/en-us00791633/">Huawei’s support page</a>.
              </p>
            </li>
            <li>
              <p>
                <b>If you purchased a subscription or enabled trial on our websites:</b>
                <br />
                To avoid being charged cancel your subscription at least 24 hours before the end of then-current period.
                Note that if you have purchased the subscription on our website, you will not be able to control it
                through the Apple App Store or Google Play. Instead, you may cancel your subscription via our support
                chat that is available within the app and through our website.
              </p>
              <ul className={classes.innerList}>
                <li>
                  <p>
                    <b>If you have an iOS device:</b>
                    <br />
                    Open the BetterMe app, go to your profile and select Help.
                  </p>
                  <img src={iosDevice.src} srcSet={iosDevice.srcSet} className={classes.image} />
                  <p>
                    From here, you can reach out to support representatives and they will help you to cancel the
                    subscription.
                  </p>
                </li>
                <li>
                  <p>
                    <b>If you have an Android device:</b>
                    <br />
                    Use the Question icon in the top right corner to open a chat window.
                  </p>
                  <img src={androidDevice.src} srcSet={androidDevice.srcSet} className={classes.image} />
                  <p>Further “cancel subscription” option will be provided and will be able to choose it.</p>
                </li>
                <li>
                  <p>
                    <b>Don’t have the app?</b>
                    <br />
                    Open a{' '}
                    <Link href={homePage}>
                      <a>BetterMe web page</a>
                    </Link>{' '}
                    and click on the Chat icon in the bottom right corner to get in touch with a support representative.
                  </p>
                  <img src={webDevice.src} srcSet={webDevice.srcSet} className={classes.image} />
                  <p>
                    In order to cancel your subscription, you will have to send our support team a message with the
                    request.
                  </p>
                </li>
              </ul>
            </li>
          </ul>
          <p>
            Canceling your subscription means that the automatic renewal will be disabled, but you will still have
            access to all your subscription features for the remaining time of your then-current period.
          </p>
        </li>

        <li>
          <h3>
            <div className={classes.anchor} id="subscription-section-5" style={anchorStyle} />
            REFUNDS
          </h3>
          <p>
            <b>If you purchased a subscription or enabled free trial on App Store</b>: If you are eligible for a refund,
            you'll have to request it directly from Apple. To request a refund, follow these instructions from the{' '}
            <a href="https://support.apple.com/en-us/HT204084">Apple support page</a>.
          </p>
          <p>
            <b>If you purchased a subscription or enabled free trial on Google Play</b>: If you are eligible for a
            refund, you'll have to request it directly from Google. To request a refund, follow these instructions from
            the <a href="https://support.google.com/googleplay/answer/2479637?hl=en">Google’s support page</a>.
          </p>
          <p>
            <b>If you purchased a subscription or enabled trial on Huawei AppGallery</b>: If you are eligible for a
            refund, you’ll have to request it directly from Huawei. To request a refund, follow these instructions from
            the <a href="https://consumer.huawei.com/za/support/content/en-us00738330/">Huawei’s support page</a>.
          </p>
          <p>
            <b>If you purchased a subscription or enabled free trial on our websites</b>: We provide refunds at our own
            discretion and subject to laws and our policies that may be published from time to time. Refund will be
            provided if we find the request acceptable.
          </p>
          <p>
            Please note that after your subscription period expires, we will not be able to refund you as the service
            will be deemed consumed in full, unless otherwise provided for by applicable law.
          </p>
        </li>

        <li>
          <h3>
            <div className={classes.anchor} id="subscription-section-6" style={anchorStyle} />
            CHANGES
          </h3>
          <p>
            To the maximum extent permitted by applicable laws, we may change subscription fees at any time. We will
            give you reasonable notice of any such pricing changes by posting the new prices on or through the app
            and/or by sending you an email notification, or in other prominent ways. If you do not wish to pay the new
            fees, you can cancel the applicable subscription prior to the change going into effect.
          </p>
        </li>
      </ol>

      <section>
        <p>
          If you have any questions in relation to the subscription terms, please contact us via the chat functionality
          or directly at support@betterme.world
        </p>
        <p>
          Please make a screenshot of this information for your reference. This may help you to control your
          subscriptions.
        </p>
      </section>
    </div>
  );
}

export default SubscriptionPolicy;
