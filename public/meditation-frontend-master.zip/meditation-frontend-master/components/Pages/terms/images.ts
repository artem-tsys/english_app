import createCloudinaryImageSet from '../../../utils/src-set';

export const androidDevice = createCloudinaryImageSet('terms/cancelation_android_fai2mg');

export const iosDevice = createCloudinaryImageSet('terms/cancelation_ios_thwyhz');

export const webDevice = createCloudinaryImageSet('terms/cancelation_web_pq8ajn');
