import React from 'react';

import classes from './static-content.module.scss';
//Todo: add translation
function MoneyBackPolicy() {
  const anchorStyle = { top: `-30px` };

  return (
    <div className={classes.privacy}>
      <span className={classes.anchor} id="money-back-policy" style={anchorStyle} />
      <h1>MONEY-BACK GUARANTEE POLICY</h1>

      <p>
        In addition to refund rights available under applicable laws, you are eligible to receive a refund if you{' '}
        <b>did not get visible results</b> with our customized meal plan and <b>all of the following</b> conditions are
        met:
      </p>
      <ul>
        <li>
          <p>
            you contact us within <b>30 days</b> after you purchased our customized meal plan; and
          </p>
        </li>
        <li>
          <p>
            you have followed our customized meal plan at least during <b>10 consecutive days</b> within the first 30
            days after the purchase; and
          </p>
        </li>
        <li>
          <p>
            you are able to demonstrate that you have followed the customized meal plan pursuant to the{' '}
            <b>requirements</b> stated below in Section “How to demonstrate that you have followed the plan”.
          </p>
        </li>
      </ul>

      <p>
        We will review your application and notify you (by email) whether your application is approved. If the
        application is approved, your refund will be processed, and a credit will be applied to your creditcard or
        original method of payment.
      </p>

      <h3>HOW TO DEMONSTRATE THAT YOU HAVE FOLLOWED THE PLAN</h3>
      <p />

      <p>You can demonstrate that you have followed the customized meal plan only if:</p>

      <ul>
        <li>
          <p>
            you provide <b>photos or/and videos</b> of meals, which you have prepared/ordered according to our
            customized meal plan; and
          </p>
        </li>
        <li>
          <p>
            the meals were made <b>according to the recipes</b> provided by us in your customized meal plan; and
          </p>
        </li>
        <li>
          <p>
            the <b>minimum number of meals</b> from the customized meal plan <b>depicted in your photos/videos</b>{' '}
            should be equal to <b>at least 15 meals</b>.
          </p>
        </li>
      </ul>

      <h3>IMPORTANT STATEMENT</h3>
      <p />

      <p>
        Please note that only fulfillment of the above requirements allows you to receive a complete refund under
        “Money-back guarantee”. For the sake of clarity, this “Money-back guarantee” does not applyto any other
        instances, including, but not limited to, the following cases:
      </p>

      <ul>
        <li>
          <p>some of the ingredients from the customized meal plan are not available where you live;</p>
        </li>
        <li>
          <p>
            you think that you do not (1) have enough time to cook the meals contained in the customized meal plan, (2)
            possess sufficient skills to prepare some the meals;
          </p>
        </li>
        <li>
          <p>
            you do not have some of the utensils or/and equipment required for the preparation of meals contained in the
            customized meal plan.
          </p>
        </li>
      </ul>

      <p>
        This Money Back Policy is incorporated into, and is subject to the Terms of Service unless otherwise provided
        for therein and applies solely to purchases made directly from us through our website. For the sake of clarity,
        this Money Back Police does not apply, in particular, to any purchases made on mobile apps stores (including,
        but not limited to, App Store or Google Play).
      </p>

      <p>Last updated: 10 August 2020</p>
    </div>
  );
}

export default MoneyBackPolicy;
