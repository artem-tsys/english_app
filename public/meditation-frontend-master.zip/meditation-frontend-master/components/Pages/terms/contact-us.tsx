import React from 'react';

import useTranslation from '../../../utils/next-with-i18n/use-translation';
import classes from './static-content.module.scss';

const EmailLink = ({ value }) => {
  return (
    <a className={classes.link} href={`mailto:${value}`}>
      {value}
    </a>
  );
};
const ContactUs = () => {
  const { t } = useTranslation();

  return (
    <main className={classes.contactUs}>
      <h1 className={classes.contactUsHeader}>{t('contactUs:title', 'Contact Us')}</h1>
      <p className={classes.contactUstext} key="p">
        {t(
          'contactUs:contactUstext',
          ' We will be glad to assist you via email. Please send your questions and feedback to',
        )}{' '}
        <EmailLink value="support@betterme.world" />
      </p>
    </main>
  );
};

export default ContactUs;
