import LinkWithoutLanguage from 'next/link';
import React from 'react';
import { useSelector } from 'react-redux';

import { Trans } from '../../../i18n';
import { generatedLandingPageUrlSelector } from '../../../redux/generated-quiz/generated-quiz.selectors';
import { getLocalizedLegalUrls } from '../../../utils/lefalLangToClientLang.utils';
import useTranslation from '../../../utils/next-with-i18n/use-translation';
import classes from './static-content.module.scss';
//Todo: add translation
const SupportEmailLink = () => {
  return (
    <a className={classes.link} href="mailto:support@betterme.world">
      support@betterme.world
    </a>
  );
};

const FAQ = () => {
  const { t, lang } = useTranslation();
  const homePage = useSelector(generatedLandingPageUrlSelector);

  const legalUrls = getLocalizedLegalUrls(lang);

  return (
    <main className={classes.faq}>
      <h1 className={classes.faqHeader}>{t('faq:title', 'FREQUENTLY ASKED QUESTIONS')}</h1>
      <h3 className={classes.faqQuestion}>{t('faq:question1', 'How do I sign up?')}</h3>
      <p className={classes.faqAnswer}>
        {/* i18n:extract t('faq:answer1', `To get started, simply go to <0>Meditation web page</0>, and answer a few quick questions about your current lifestyle, stressors and emotional well-being, as well as your goals. We will also ask for your email: please make sure you enter it correctly. Once we have the necessary information, we will generate a custom yoga and meditation plan designed according to your preferences. The plan will be available in the app that you will be able to download via a link provided to you after the payment has been made.`) */}
        <Trans i18nKey="faq:answer1" components={[<a href={homePage} className={classes.link} key="0" />]} />
      </p>
      <h3 className={classes.faqQuestion}>
        {t('faq:question2', 'How will I receive my customized yoga and meditation plan?')}
      </h3>
      <p className={classes.faqAnswer}>
        {t(
          'faq:answer2',
          ` You’ll receive a unique download link that will take you to the AppStore or Google Play Store to download the
          app. Once the app is installed on your device, you need to sign into the app using the email you entered when
          signing up on our website. You will have unlimited access to all the features of your subscription plan within
          the app for the duration of your paid period.

          If you experience any difficulties with downloading or accessing the app, please contact us at `,
        )}
        <SupportEmailLink />.
      </p>

      <h3 className={classes.faqQuestion}>
        {t('faq:question3', 'When will I receive my customized yoga and meditation plan?')}
      </h3>
      <p className={classes.faqAnswer}>
        {t(
          'faq:answer3',
          `Our smart algorithms are highly precise and are able to customize your meditation plan according to your specific needs.
           The unique download link will be generated right after your payment.
           The plan will become available as soon as you download the app using your unique link.`,
        )}
      </p>

      <h3 className={classes.faqQuestion}>{t('faq:question4', 'Do we always offer free trials?')}</h3>
      <p className={classes.faqAnswer}>
        {t(
          'faq:answer4',
          `Please note that if a free trial is offered, this will be explicitly stated on the price screen before the
          checkout. If this is not the case, you will purchase our subscription without a free trial.`,
        )}
      </p>

      <h3 className={classes.faqQuestion}>{t('faq:question5', 'How will you bill me?')}?</h3>
      <p className={classes.faqAnswer}>
        {t(
          'faq:answer5',
          `Generally we offer subscriptions that automatically renew. Depending on what option you choose, your
          subscription will be renewed at the end of each period.`,
        )}
      </p>

      <h3 className={classes.faqQuestion}>{t('faq:question6', 'Can I cancel my subscription?')}?</h3>
      <p className={classes.faqAnswer}>
        {t(
          'faq:answer6',
          `Your subscription renews automatically at the end of each period until you cancel.
           Note that deleting the app does not cancel your subscriptions.
           You may cancel a trial or a subscription by following simple steps from our `,
        )}
        <LinkWithoutLanguage href={legalUrls.subscriptionPolicyUrl}>
          <a className={classes.link}>{t('legalText:terms', `Subscription Terms`)}</a>
        </LinkWithoutLanguage>
        .
      </p>
    </main>
  );
};

export default FAQ;
