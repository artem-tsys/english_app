import React from 'react';
import { useSelector } from 'react-redux';

import { SignupMethod } from '../../../../constants/order.constants';
import { useTranslation } from '../../../../i18n';
import { questionaryVersionSelector } from '../../../../redux/order/order.selectors';
import AppleIcon from '../../../Shared/Elements/apple-icon';
import classes from './download.module.scss';
import { planMarketLogoSet } from './images';

const DownloadButtons = ({ price, signupMethod }: { price: string; signupMethod: SignupMethod }) => {
  const questionaryVersion = useSelector(questionaryVersionSelector);
  const { t } = useTranslation();

  const link = `https://better-meditation.onelink.me/MD4H/85daee03?pid=web_onboarding_${signupMethod}&c=${questionaryVersion}&af_adset=${price}`;
  return (
    <div className={classes.downloadButtonsSection}>
      <a href={link} className={classes.downloadButton}>
        <div className={classes.downloadButtonLogoContainer}>
          <AppleIcon className={classes.appleLogo} />
        </div>
        <div className={classes.downloadButtonText}>
          <div>
            {t('downloadButtons:download', 'Download on the')} <div className={classes.storeName}>App Store</div>
          </div>
        </div>
      </a>
      <a href={link} className={classes.downloadButton}>
        <div className={classes.downloadButtonLogoContainer}>
          <img src={planMarketLogoSet.src} className={classes.downloadButtonLogo} />
        </div>
        <div className={classes.downloadButtonText}>
          <div>
            {t('downloadButtons:get', 'Get it on')} <div className={classes.storeName}>Google Play</div>
          </div>
        </div>
      </a>
    </div>
  );
};

export default DownloadButtons;
