import React from 'react';
import { useSelector } from 'react-redux';

import {
  orderAmountSelector,
  orderCurrencySelector,
  signupMethodSelector,
} from '../../../../redux/order/order.selectors';
import DownloadContext from './download-context';
const { Provider } = DownloadContext;

const DownloadProvider = ({ children }) => {
  const amount = useSelector(orderAmountSelector);
  const currency = useSelector(orderCurrencySelector);
  const signupMethod = useSelector(signupMethodSelector);

  return (
    <Provider
      value={{
        signupMethod,
        amount,
        currency,
      }}
    >
      {children}
    </Provider>
  );
};

export default DownloadProvider;
