import React from 'react';

import { SignupMethod } from '../../../../constants/order.constants';

interface DownloadContext {
  amount: number;
  currency: string;
  signupMethod: SignupMethod;
}

const downloadContext = React.createContext<DownloadContext>(null);

export default downloadContext;
