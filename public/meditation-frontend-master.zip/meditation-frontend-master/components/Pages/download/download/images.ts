import createCloudinaryImageSet from '../../../../utils/src-set';

// download.tsx
export const planMarketLogoSet = createCloudinaryImageSet(`/public/images/play-market.svg`);

export const emailInstruction = createCloudinaryImageSet(`/public/images/email-instruction.gif`);
export const appleInstruction = createCloudinaryImageSet(`/public/images/apple-instruction.gif`);
export const qrCode = createCloudinaryImageSet('/meditation/download/image_7_kkr36y.png');

const images = {
  planMarketLogoSet,
};

export const appleDownloadImages = {
  appleInstruction,
};

export const emailDownloadImages = {
  emailInstruction,
};

export default images;
