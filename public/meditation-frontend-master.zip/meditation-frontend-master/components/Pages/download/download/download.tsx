import React, { useContext, useEffect } from 'react';
import { useDispatch } from 'react-redux';

import { isInBrowser } from '../../../../config';
import { SignupMethod } from '../../../../constants/order.constants';
import { downloadAction } from '../../../../redux/analytics/analytics.actions';
import { downloadPageInit } from '../../../../redux/signup/signup.actions';
import { notifyOnError } from '../../../../utils/error-tracking';
import useTranslation from '../../../../utils/next-with-i18n/use-translation';
import PageHeader from '../../../Shared/Elements/page-header/page-header';
import DownloadButtons from './download-buttons';
import downloadContext from './download-context';
import classes from './download.module.scss';
import { qrCode } from './images';

const SIGNUP_STEP_TEXT: Record<SignupMethod, Record<string, string>> = {
  // i18n:extract t('download:step-two', 'Use the same credentials as on the website to log in')
  email: { key: 'download:step-two', value: 'Enter the same credentials from the previous step.' },
  apple: { key: 'download:step-two', value: 'Use the same credentials as on the website to log in' },
};

const DISCLAMER_HEADER: Record<SignupMethod, Record<string, string>> = {
  // i18n:extract t('download:disclamerSubheaderApple', 'About Continue with Apple and Skip')
  apple: { key: 'download:disclamerSubheaderApple', value: 'About continue with Apple and skip' },
  // i18n:extract t('download:disclamerSubheaderEmail', 'About Continue with E-mail and Skip')
  email: { key: 'download:disclamerSubheaderEmail', value: 'Use Already Registered? to log in' },
};

const Download = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const { amount, signupMethod } = useContext(downloadContext);

  useEffect(() => {
    try {
      isInBrowser && window.scrollTo(0, 0);
    } catch (e) {
      notifyOnError('[Download] No scrollTo method on widnow object');
    }

    dispatch(downloadPageInit());
    dispatch(downloadAction('purchasing'));
  }, []);

  const price = (amount / 100).toFixed(2);
  const signupStepText = SIGNUP_STEP_TEXT[signupMethod];
  const disclamerSubHeader = DISCLAMER_HEADER[signupMethod];
  return (
    <div className={classes.downloadPage}>
      <main className={classes.container}>
        <PageHeader className={classes.header}>{t('download:header', 'Thank You For Your Purchase!')}</PageHeader>
        <ul className={classes.steps}>
          <li className={classes.mobileStep}>
            <div className={classes.stepDescription}>
              <span className={classes.stepNumber}>1</span>
              {t('download:step-one-mobile', 'Download the app to your phone')}
            </div>
            <DownloadButtons price={price} signupMethod={signupMethod} />
          </li>
          <li className={classes.desktopStep}>
            <div className={classes.stepDescription}>
              <span className={classes.stepNumber}>1</span>
              {t('download:step-one-desktop', 'Download the app by scanning the QR-code below')}
            </div>
            <section className={classes.qrCodeSection}>
              <img src={qrCode.src} className={classes.qrCode} srcSet={qrCode.srcSet} />
              <DownloadButtons price={price} signupMethod={signupMethod} />
            </section>
          </li>
          <li>
            <div className={classes.stepDescription}>
              <span className={classes.stepNumber}>2</span>
              {t(signupStepText.key, signupStepText.value)}
            </div>
            <div className={classes.instructionContainer}>
              <div className={classes.instructionPhoneFrame}>
                <div className={classes.instructionAnimationWrapper}>
                  <img src="https://res.cloudinary.com/drhg6wpcy/image/upload/c_scale,q_80,vc_auto,w_160/v1644591757/login_insrtuction_for_meditation_15.38.18_ykqz0c.gif" />
                </div>
              </div>
            </div>
            <div className={classes.disclamer}>
              <div className={classes.disclamerHeader}>
                <span className={classes.disclamerHeaderMark}>!</span> {t('download:disclamer', 'Disclamer')}
              </div>
              <div className={classes.disclamerSubheader}>{t(disclamerSubHeader.key, disclamerSubHeader.value)}</div>
              <p className={classes.disclamerText}>
                {t(
                  'download:disclamerText',
                  ` You must select Already Registered? option and enter the same credentials you registered with to access
                the app.`,
                )}
                <strong className={classes.disclamerCaption}>
                  {t(
                    'download:disclamerCaption',
                    `If you choose Get Started, you must complete the questionnaire and make a purchase once again.`,
                  )}
                </strong>
              </p>
            </div>
          </li>

          <li>
            <div className={classes.stepDescription}>
              <span className={classes.stepNumber}>3</span>
              {t('download:step-three-enjoy', 'Enjoy your meditation journey!')}
            </div>
          </li>
        </ul>
      </main>
    </div>
  );
};

export default Download;
