import cn from 'classnames';
import React, { useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { submitQuizAnswerClickAction } from '../../../../../../../redux/analytics/analytics.actions';
import { AnalyticQuestionType } from '../../../../../../../redux/analytics/analytics.types';
import { answerOptionHeightSelector } from '../../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  QuestionStyle,
  QuestionType,
} from '../../../../../../../redux/generated-quiz/generated-quiz.types';
import { createCloudinaryImageSetWithLimitedWidth, ImageSet } from '../../../../../../../utils/src-set';
import FixedSizeImage from '../../../../../../Generic/fixed-size-image/fixed-size-image';
import Checkbox from '../../../../../../Shared/Elements/checkbox/checkbox';
import SelectableCard from '../../../../../../Shared/Elements/selectable-card/selectable-card';
import classes from '../../../../quiz/quiz.module.scss';
import singleSelectClasses from './single-select-question.module.scss';

interface SingleSelectQuestionProps {
  title: string;
  answerOptions: GeneratedSingleSelectAnswerOption[];
  description?: string;
  onAnswerSelected: (e: Event) => void;
  selectedId: number | string;
  questionType: QuestionType;
  questionStyle?: QuestionStyle;
  questionImage?: string;
  id: number;
}

function getQuestionImageSet(width: number, id?: string): ImageSet | null {
  if (!id) {
    return null;
  }

  return createCloudinaryImageSetWithLimitedWidth(id, width);
}

const SingleSelectQuestion: React.FunctionComponent<SingleSelectQuestionProps> = ({
  title,
  answerOptions,
  description,
  onAnswerSelected,
  selectedId,
  questionType,
  questionStyle,
  questionImage,
  id,
}) => {
  const dispatch = useDispatch();
  const answerOptionHeight = useSelector(answerOptionHeightSelector);

  const isImageStyleType = questionStyle === QuestionStyle.IMAGE;

  const questionImageSet = useMemo(() => getQuestionImageSet(500, questionImage), [questionImage]);

  const handleClick = (e) => {
    const analyticQuestionType =
      questionType === QuestionType.SingleSelect ? AnalyticQuestionType.OPTIONAL : AnalyticQuestionType.REQUIRED;
    dispatch(submitQuizAnswerClickAction(id, analyticQuestionType, e.currentTarget.dataset.cardId));
    onAnswerSelected(e);
  };
  return (
    <>
      <div className={singleSelectClasses.header}>
        <h1 className={singleSelectClasses.headerTitle}>{title}</h1>
        {description && <p className={singleSelectClasses.headerDescription}>{description}</p>}
      </div>
      <section className={classes.questionsSection}>
        {isImageStyleType && (
          <div className={singleSelectClasses.imageContainter}>
            <img
              className={singleSelectClasses.image}
              src={questionImageSet.src}
              srcSet={questionImageSet.srcSet}
              alt=""
            />
          </div>
        )}

        {answerOptions.map(({ title, description, icon, id }) => {
          const isSelected = id === selectedId;

          return (
            <SelectableCard
              key={id}
              onClick={handleClick}
              dataCardId={id}
              isSelected={isSelected}
              className={classes.quizCardContainer}
            >
              <article className={classes.quizCard}>
                {icon && answerOptionHeight.imageSize && (
                  <div
                    className={classes.generatedQuizCardImage}
                    style={{
                      paddingLeft: answerOptionHeight.imageLeftPadding,
                      width: answerOptionHeight.imageSize,
                      height: answerOptionHeight.imageSize,
                    }}
                  >
                    <FixedSizeImage
                      imageName={icon}
                      width={answerOptionHeight.imageSize}
                      height={answerOptionHeight.imageSize}
                    />
                  </div>
                )}
                <div className={classes.quizCardContent} style={{ paddingLeft: answerOptionHeight.textLeftPadding }}>
                  <div className={classes.quizCardHeader}>{title}</div>
                  {description && <div className={classes.quizCardDescription}>{description}</div>}
                </div>
                <Checkbox
                  isChecked={isSelected}
                  className={cn({ [classes.isTransparent]: !isSelected })}
                  dataCheckbox="generated-single-select-question"
                />
              </article>
            </SelectableCard>
          );
        })}
      </section>
    </>
  );
};

export default SingleSelectQuestion;
