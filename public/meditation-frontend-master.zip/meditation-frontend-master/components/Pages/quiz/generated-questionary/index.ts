export { default } from './generated-questionary';
