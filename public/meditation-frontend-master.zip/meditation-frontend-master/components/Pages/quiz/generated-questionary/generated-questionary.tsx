import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Anxiety, Distraction, Insomnia, Stressed } from '../../../../constants/quiz-options.constants';
import {
  SKIP_BUTTON_LOCALSTORAGE_KEY,
  SKIP_BUTTON_LOCALSTORAGE_VALUE,
} from '../../../../constants/skip-button.constants';
import { skipClicked } from '../../../../redux/generated-quiz/generated-quiz.actions';
import {
  generatedQuestionStepSelector,
  generatedStepSelector,
  questionsAmountSelector,
} from '../../../../redux/generated-quiz/generated-quiz.selectors';
import QuizIndicator from '../../../Pages/quiz/quiz/quiz-indicator';
import Loader from '../../../Shared/Elements/loader/loader';
import classes from '../quiz/quiz.module.scss';
import GeneratedQuizStep from './components/generated-quiz-step';

const useScrollToNextStepTop = () => {
  const step = useSelector(generatedStepSelector);

  useEffect(() => {
    if (window?.scrollTo) {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth',
      });
    }
  }, [step]);
};

const GeneratedQuestionary: React.FC = () => {
  useScrollToNextStepTop();
  const dispatch = useDispatch();

  const step = useSelector(generatedQuestionStepSelector);
  const stepAmount = useSelector(questionsAmountSelector);
  const shouldShowIndicator = step && step < stepAmount;
  const [shouldShowSkipButton, setShouldShowSkipButton] = useState(false);
  const [shouldShowLoader, setShouldShowLoader] = useState(false);

  useEffect(() => {
    const keyToSkipButton = localStorage?.getItem(SKIP_BUTTON_LOCALSTORAGE_KEY);

    if (keyToSkipButton === SKIP_BUTTON_LOCALSTORAGE_VALUE) {
      setShouldShowSkipButton(true);
    }
  }, []);

  const handleSkipClicked = (): void => {
    dispatch(
      skipClicked({
        health: 'stressed',
        stressCause: ['bad-habits'],
        sleepQuality: 'took-me-a-while',
        mainGoals: ['reduce-stress'],
        anxiety: Anxiety.Often,
        stressed: Stressed.PrettyOften,
        distraction: Distraction.SometimesHardToFocus,
        insomnia: Insomnia.TurnForAnHour,
        flowTopic: 'Meditation_80',
      }),
    );
    setShouldShowLoader(true);
  };

  return (
    <>
      <div className={classes.quizContainer}>
        {shouldShowIndicator && <QuizIndicator stepsAmount={stepAmount} currentStep={step} />}
        <div className={classes.quizContent}>
          <GeneratedQuizStep />
        </div>
        {shouldShowSkipButton && (
          <button data-button="secret-skip-button" className={classes.skipButton} onClick={handleSkipClicked}>
            Skip
          </button>
        )}
      </div>
      <Loader isShown={shouldShowLoader} className={classes.loader} />
    </>
  );
};

export default GeneratedQuestionary;
