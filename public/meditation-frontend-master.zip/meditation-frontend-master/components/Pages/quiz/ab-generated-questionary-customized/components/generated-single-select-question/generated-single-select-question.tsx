import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { generatedSingleSelectSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  generatedQuestionSelectedValueSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import { GeneratedSingleSelectQuestion as GeneratedSingleSelectQuestionType } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { State } from '../../../../../../redux/store';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import SingleSelectQuestion from './components/single-select';

const GeneratedSingleSelectQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestionType;
  const selectedId = useSelector((state: State) => generatedQuestionSelectedValueSelector(state, question.id));

  const onAnswerSelected = (e): void => {
    const value = +e.currentTarget.dataset.cardId;

    dispatch(generatedSingleSelectSelected(question.id, value));

    const answer = question.answerOptions.find((a) => a.id === value);
    const answerForStore = { value };

    if (question.customizationKey) {
      Object.assign(answerForStore, {
        customizationKey: question.customizationKey,
        customizationValue: answer?.customizationValue ?? value.toString(),
      });
    }

    answersPersistentClientStore.setAnswer(question.id.toString(), answerForStore);
  };

  return <SingleSelectQuestion {...question} onAnswerSelected={onAnswerSelected} selectedId={selectedId} />;
};

export default GeneratedSingleSelectQuestion;
