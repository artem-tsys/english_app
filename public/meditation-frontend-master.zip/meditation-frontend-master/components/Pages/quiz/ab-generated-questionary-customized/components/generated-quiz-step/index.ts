export { default } from './generated-quiz-step';
