import { MainPage } from '@betterme-dev/web-ui-kit';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Router } from '../../../../../../i18n';
import { submitQuizAnswerClickAction } from '../../../../../../redux/analytics/analytics.actions';
import { AnalyticQuestionType } from '../../../../../../redux/analytics/analytics.types';
import { firstPageGeneratedAction } from '../../../../../../redux/analytics/generated-analytics.actions';
import {
  generatedOnboardingStarted,
  generatedQuizStarted,
} from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import { generatedFirstPageSelector } from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import { IGeneratedFirstPageWithCards } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import shortcodeToTags from '../../../../../../utils/shortcodes/shortcode-to-tags.util';
import { createCloudinaryImageSetWithLimitedWidth } from '../../../../../../utils/src-set';
import Copyright from '../../../../../Shared/Elements/copyright/copyright';
import classes from './first-page-generated.module.scss';

interface IBoldTextProps {
  params: string[];
}

const BoldText: React.FC<IBoldTextProps> = ({ params }) => {
  return <b className={classes.boldWeight}>{params[0]}</b>;
};

const localShortcodeConfig = [
  {
    Component: BoldText,
    tag: 'span',
    default: false,
  },
  {
    Component: BoldText,
    tag: 'b',
    default: false,
  },
];

interface IFooterLabel {
  footerText: string;
}

const FooterLabel: React.FC<IFooterLabel> = ({ footerText }) => {
  return <>{shortcodeToTags(footerText, localShortcodeConfig)}</>;
};

const FirstPageGenerated: React.FC = () => {
  const generatedFirstPage = useSelector(generatedFirstPageSelector);
  const dispatch = useDispatch();

  const { subtitle, title, note, cards, pageId } = generatedFirstPage as IGeneratedFirstPageWithCards;

  const handleCardSelected = (index: number): void => {
    dispatch(submitQuizAnswerClickAction(pageId, AnalyticQuestionType.FIRST, index));
    dispatch(generatedQuizStarted());
  };

  useEffect(() => {
    if (generatedFirstPage) {
      if ('customUrl' in generatedFirstPage) {
        Router.push(generatedFirstPage.customUrl);

        return;
      }
      const { analytics } = generatedFirstPage;

      dispatch(firstPageGeneratedAction(analytics));
    }
  }, []);

  useEffect(() => {
    dispatch(generatedOnboardingStarted());
  }, []);

  const Title = () => <h1 className={classes.title}>{title}</h1>;
  const SubTitle = () => (
    <span className={classes.subtitle}>{subtitle && shortcodeToTags(subtitle, localShortcodeConfig)}</span>
  );
  const Note = () => <span>{shortcodeToTags(note, localShortcodeConfig)}</span>;

  const cardList =
    cards?.map((card, index) => ({
      label: <FooterLabel footerText={card.footerText} />,
      image: createCloudinaryImageSetWithLimitedWidth(card.image, 160),
      onClick: () => handleCardSelected(index),
      dataButton: 'first-page-generated-button',
    })) || [];

  return (
    <div className={classes.container}>
      <MainPage Title={Title} Subtitle={SubTitle} Note={Note} Copyright={Copyright} cards={cardList} />
    </div>
  );
};

export default FirstPageGenerated;
