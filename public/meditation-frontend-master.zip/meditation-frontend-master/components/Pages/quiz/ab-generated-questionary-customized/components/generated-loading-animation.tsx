import cn from 'classnames';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { useInterval } from '../../../../../hooks/use-interval.hook';
import { generatedAnimationCompleted } from '../../../../../redux/generated-quiz/generated-quiz.actions';
import { currentStepElementSelector } from '../../../../../redux/generated-quiz/generated-quiz.selectors';
import { GeneratedLoader } from '../../../../../redux/generated-quiz/generated-quiz.types';
import classes from '../generated-loading-animation.module.scss';
import Mandala from './mandala';

const getOpacity = (textStep, currentIndex) => {
  if (textStep > currentIndex) return 0;
  if (textStep === currentIndex) return 1;
  return 1 - (currentIndex - textStep + 1) * 0.1;
};

const GeneratedLoadingAnimation = () => {
  const dispatch = useDispatch();
  const { duration, start, finish, loaderText } = useSelector(currentStepElementSelector) as GeneratedLoader;
  const [progress, setProgress] = useState(start);
  const [textStep, setTextStep] = useState(0);
  const isAnimationFinished = progress === finish;
  const tickTime = (duration * 1000) / (finish - start);

  useInterval(
    () => {
      setProgress(progress + 1);
    },
    isAnimationFinished ? null : tickTime,
  );

  useEffect(() => {
    const currentTextStep = Math.ceil((loaderText.length / (finish - start)) * (progress - start)) - 1;
    setTextStep(currentTextStep);
  }, [progress]);

  useEffect(() => {
    if (isAnimationFinished) {
      dispatch(generatedAnimationCompleted());
    }
  }, [isAnimationFinished]);

  return (
    <>
      <main className={classes.container}>
        <Mandala className={classes.loaderImage} />
        <div className={classes.progress}>
          {progress}
          <span className={classes.progressUnit}>%</span>
        </div>

        <ul className={classes.progressDescription}>
          {loaderText.map((step, index) => {
            return (
              <li
                key={step}
                className={cn({ [classes.isHidden]: textStep > index })}
                style={{ opacity: getOpacity(textStep, index) }}
              >
                {step}
              </li>
            );
          })}
        </ul>
      </main>
    </>
  );
};

export default GeneratedLoadingAnimation;
