import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { initGeneratedStep } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import { currentStepElementSelector } from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import { QuestionType, StructureElementTypes } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import Loader from '../../../../../Shared/Elements/loader/loader';
import AnxietyQuestion from '../../../quiz/ab-steps-customized/anxiety';
import DistractionQuestion from '../../../quiz/ab-steps-customized/distraction';
import HealthQuestion from '../../../quiz/ab-steps-customized/health';
import InsomniaQuestion from '../../../quiz/ab-steps-customized/insomnia';
import MainGoalsQuestion from '../../../quiz/ab-steps-customized/main-goals';
import SleepQuality from '../../../quiz/ab-steps-customized/sleep-quality';
import StressQuestion from '../../../quiz/ab-steps-customized/stress';
import StressCauseQuestion from '../../../quiz/ab-steps-customized/stress-cause';
import classes from '../../ab-generated-questionary-customized.module.scss';
import GeneratedLoadingAnimation from '../generated-loading-animation';
import MultiSelectQuestion from '../generated-multi-select-question/generated-multi-select-question';
import SingleSelectQuestion from '../generated-single-select-question/generated-single-select-question';

const GeneratedQuizStep: React.FunctionComponent = () => {
  const currentStepElement = useSelector(currentStepElementSelector);
  const dispatch = useDispatch();

  useEffect(() => {
    if (currentStepElement) dispatch(initGeneratedStep());
  }, [currentStepElement]);

  switch (currentStepElement?.type) {
    case StructureElementTypes.question:
      switch (currentStepElement.questionType) {
        case QuestionType.Health:
          return <HealthQuestion />;

        case QuestionType.SleepQuality:
          return <SleepQuality />;

        case QuestionType.StressCause:
          return <StressCauseQuestion />;

        case QuestionType.MainGoals:
          return <MainGoalsQuestion />;

        case QuestionType.Anxiety:
          return <AnxietyQuestion />;

        case QuestionType.Distraction:
          return <DistractionQuestion />;

        case QuestionType.Insomnia:
          return <InsomniaQuestion />;

        case QuestionType.Stress:
          return <StressQuestion />;

        case QuestionType.SingleSelect:
          return <SingleSelectQuestion />;

        case QuestionType.MultiSelect:
          return <MultiSelectQuestion />;

        default:
          return null;
      }

    case StructureElementTypes.loader:
      return <GeneratedLoadingAnimation />;

    default:
      return <Loader isShown className={classes.loader} />;
  }
};

export default GeneratedQuizStep;
