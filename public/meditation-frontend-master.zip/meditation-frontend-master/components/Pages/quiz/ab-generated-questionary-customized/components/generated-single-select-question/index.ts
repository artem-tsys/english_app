export { default } from './generated-single-select-question';
