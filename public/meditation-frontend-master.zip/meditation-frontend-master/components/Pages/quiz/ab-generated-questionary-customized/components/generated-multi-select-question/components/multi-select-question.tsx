import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { submitQuizAnswerClickAction } from '../../../../../../../redux/analytics/analytics.actions';
import { AnalyticQuestionType } from '../../../../../../../redux/analytics/analytics.types';
import { stepForwardGenerated } from '../../../../../../../redux/generated-quiz/generated-quiz.actions';
import { answerOptionHeightSelector } from '../../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedMultiSelectQuestion,
  QuestionType,
} from '../../../../../../../redux/generated-quiz/generated-quiz.types';
import useTranslation from '../../../../../../../utils/next-with-i18n/use-translation';
import FixedSizeImage from '../../../../../../Generic/fixed-size-image/fixed-size-image';
import Checkbox from '../../../../../../Shared/Elements/checkbox/checkbox';
import SelectableCard from '../../../../../../Shared/Elements/selectable-card/selectable-card';
import classes from '../../../../quiz/quiz.module.scss';
import multiSelectClasses from '../generated-multi-select-question.module.scss';

interface MultiSelectQuestionProps {
  question: GeneratedMultiSelectQuestion;
  onAnswerClicked: (e: Event) => void;
  selectedValues: any[];
}

const MultiSelectQuestion: React.FunctionComponent<MultiSelectQuestionProps> = ({
  question,
  onAnswerClicked,
  selectedValues,
}) => {
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const answerOptionHeight = useSelector(answerOptionHeightSelector);

  const stepForward = () => dispatch(stepForwardGenerated());
  const isInputValid = selectedValues.length > 0;

  const handleSubmit = (e) => {
    e.preventDefault();

    selectedValues.map((id) => {
      const analyticQuestionType =
        question.questionType === QuestionType.MultiSelect
          ? AnalyticQuestionType.OPTIONAL
          : AnalyticQuestionType.REQUIRED;
      dispatch(submitQuizAnswerClickAction(question.id, analyticQuestionType, id));
    });
    stepForward();
  };

  return (
    <form onSubmit={handleSubmit} className={multiSelectClasses.container}>
      <div className={multiSelectClasses.goalTypeHeader}>
        <h1 className={multiSelectClasses.goalTypeHeaderTitle}>{question.title}</h1>
        {question.description && <p className={multiSelectClasses.goalTypeHeaderDescription}>{question.description}</p>}
      </div>
      {question.answerOptions.map(({ title, description, icon, id }) => {
        const isSelected = selectedValues.indexOf(id) > -1;
        return (
          <SelectableCard
            key={id}
            onClick={onAnswerClicked}
            dataCardId={id}
            isSelected={isSelected}
            className={multiSelectClasses.quizCardContainer}
          >
            <article className={classes.quizCard}>
              {icon && answerOptionHeight.imageSize && (
                <div
                  className={classes.generatedQuizCardImage}
                  style={{
                    paddingLeft: answerOptionHeight.imageLeftPadding,
                    width: answerOptionHeight.imageSize,
                    height: answerOptionHeight.imageSize,
                  }}
                >
                  <FixedSizeImage
                    imageName={icon}
                    width={answerOptionHeight.imageSize}
                    height={answerOptionHeight.imageSize}
                  />
                </div>
              )}
              <div className={classes.quizCardContent} style={{ paddingLeft: answerOptionHeight.textLeftPadding }}>
                <div className={classes.quizCardHeader}>{title}</div>
                {description && <div className={classes.quizCardDescription}>{description}</div>}
              </div>
              <Checkbox isChecked={isSelected} dataCheckbox="multi-select-question" />
            </article>
          </SelectableCard>
        );
      })}
      <div className={multiSelectClasses.formBtnContainer}>
        <button
          className={multiSelectClasses.submitBtn}
          type="submit"
          disabled={!isInputValid}
          data-button="multi-select-question-submit"
        >
          {t('multiSelect:buttonNext', 'Next')}
        </button>
      </div>
    </form>
  );
};

export default MultiSelectQuestion;
