import cn from 'classnames';
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { submitQuizAnswerClickAction } from '../../../../../../../redux/analytics/analytics.actions';
import { AnalyticQuestionType } from '../../../../../../../redux/analytics/analytics.types';
import { answerOptionHeightSelector } from '../../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  QuestionType,
} from '../../../../../../../redux/generated-quiz/generated-quiz.types';
import FixedSizeImage from '../../../../../../Generic/fixed-size-image/fixed-size-image';
import Checkbox from '../../../../../../Shared/Elements/checkbox/checkbox';
import SelectableCard from '../../../../../../Shared/Elements/selectable-card/selectable-card';
import classes from '../../../../quiz/quiz.module.scss';
import singleSelectClasses from './single-select-question.module.scss';

interface SingleSelectQuestionProps {
  title: string;
  answerOptions: GeneratedSingleSelectAnswerOption[];
  description?: string;
  onAnswerSelected: (e: Event) => void;
  selectedId: number | string;
  questionType: QuestionType;
  id: number;
}

const SingleSelectQuestion: React.FunctionComponent<SingleSelectQuestionProps> = (props) => {
  const { title, answerOptions, description, onAnswerSelected, selectedId, questionType, id } = props;
  const dispatch = useDispatch();
  const answerOptionHeight = useSelector(answerOptionHeightSelector);

  const handleClick = (e) => {
    const analyticQuestionType =
      questionType === QuestionType.SingleSelect ? AnalyticQuestionType.OPTIONAL : AnalyticQuestionType.REQUIRED;

    const answerId = e.currentTarget.dataset.cardId;

    dispatch(submitQuizAnswerClickAction(id, analyticQuestionType, answerId));
    onAnswerSelected(e);
  };
  return (
    <>
      <div className={singleSelectClasses.header}>
        <h1 className={singleSelectClasses.headerTitle}>{title}</h1>
        {description && <p className={singleSelectClasses.headerDescription}>{description}</p>}
      </div>
      <section className={classes.questionsSection}>
        {answerOptions.map(({ title, description, icon, id }) => {
          const isSelected = id === selectedId;

          return (
            <SelectableCard
              key={id}
              onClick={handleClick}
              dataCardId={id}
              isSelected={isSelected}
              className={classes.quizCardContainer}
            >
              <article className={classes.quizCard}>
                {icon && answerOptionHeight.imageSize && (
                  <div
                    className={classes.generatedQuizCardImage}
                    style={{
                      paddingLeft: answerOptionHeight.imageLeftPadding,
                      width: answerOptionHeight.imageSize,
                      height: answerOptionHeight.imageSize,
                    }}
                  >
                    <FixedSizeImage
                      imageName={icon}
                      width={answerOptionHeight.imageSize}
                      height={answerOptionHeight.imageSize}
                    />
                  </div>
                )}
                <div className={classes.quizCardContent} style={{ paddingLeft: answerOptionHeight.textLeftPadding }}>
                  <div className={classes.quizCardHeader}>{title}</div>
                  {description && <div className={classes.quizCardDescription}>{description}</div>}
                </div>
                <Checkbox
                  isChecked={isSelected}
                  className={cn({ [classes.isTransparent]: !isSelected })}
                  dataCheckbox="generated-single-select-question"
                />
              </article>
            </SelectableCard>
          );
        })}
      </section>
    </>
  );
};

export default SingleSelectQuestion;
