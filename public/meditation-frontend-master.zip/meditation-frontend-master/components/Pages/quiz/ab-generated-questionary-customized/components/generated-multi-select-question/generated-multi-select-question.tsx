import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { generatedMultiSelectSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  generatedQuestionSelectedValueSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import { GeneratedMultiSelectQuestion as GeneratedMultiSelectQuestionType } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { State } from '../../../../../../redux/store';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import MultiSelectQuestion from './components/multi-select-question';

const GeneratedMultiSelectQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const question = useSelector(currentStepElementSelector) as GeneratedMultiSelectQuestionType;
  const selectedValues =
    useSelector((state: State) => generatedQuestionSelectedValueSelector(state, question.id)) || [];

  const onAnswerClicked = (e): void => {
    const selectedId = Number(e.currentTarget.dataset.cardId);
    const isSelected = selectedValues.indexOf(selectedId) > -1;
    const getNewSelectedValuesWith = (newId) => [...selectedValues, newId];
    const getNewSelectedValuesWithout = (newId) => selectedValues.filter((id) => id !== newId);
    const newSelectedValues = isSelected
      ? getNewSelectedValuesWithout(selectedId)
      : getNewSelectedValuesWith(selectedId);

    dispatch(generatedMultiSelectSelected(question.id, newSelectedValues));

    const answers = question.answerOptions.filter((a) => newSelectedValues.includes(a.id));
    const answerForStore = { value: newSelectedValues };

    if (question.customizationKey) {
      Object.assign(answerForStore, {
        customizationKey: question.customizationKey,
        customizationValue: answers.map((a) => a.customizationValue || a.title),
      });
    }

    answersPersistentClientStore.setAnswer(question.id.toString(), answerForStore);
  };

  return <MultiSelectQuestion question={question} onAnswerClicked={onAnswerClicked} selectedValues={selectedValues} />;
};

export default GeneratedMultiSelectQuestion;
