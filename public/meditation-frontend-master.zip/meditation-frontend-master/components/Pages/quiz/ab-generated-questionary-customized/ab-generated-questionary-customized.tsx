import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';

import {
  generatedQuestionStepSelector,
  generatedStepSelector,
  questionsAmountSelector,
} from '../../../../redux/generated-quiz/generated-quiz.selectors';
import QuizIndicator from '../../../Pages/quiz/quiz/quiz-indicator';
import classes from '../quiz/quiz.module.scss';
import GeneratedQuizStep from './components/generated-quiz-step';

const useScrollToNextStepTop = () => {
  const step = useSelector(generatedStepSelector);

  useEffect(() => {
    if (window?.scrollTo) {
      window.scrollTo({
        top: 0,
        left: 0,
        behavior: 'smooth',
      });
    }
  }, [step]);
};

const GeneratedQuestionary: React.FC = () => {
  useScrollToNextStepTop();

  const step = useSelector(generatedQuestionStepSelector);
  const stepAmount = useSelector(questionsAmountSelector);
  const shouldShowIndicator = step && step < stepAmount;

  return (
    <div className={classes.quizContainer}>
      {shouldShowIndicator && <QuizIndicator stepsAmount={stepAmount} currentStep={step} />}
      <div className={classes.quizContent}>
        <GeneratedQuizStep />
      </div>
    </div>
  );
};

export default GeneratedQuestionary;
