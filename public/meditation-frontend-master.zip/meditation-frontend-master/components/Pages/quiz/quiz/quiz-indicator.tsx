import React from 'react';
import { useSelector } from 'react-redux';

import { generatedStepSelector } from '../../../../redux/generated-quiz/generated-quiz.selectors';
import classes from './quiz-indicator.module.scss';

interface QuizIndicatorProps {
  stepsAmount: number;
  currentStep?: number;
}

const QuizIndicator: React.FunctionComponent<QuizIndicatorProps> = ({ stepsAmount, currentStep }) => {
  const reduxCurrentStep = useSelector(generatedStepSelector);
  const step = currentStep || reduxCurrentStep;
  const width = (step / stepsAmount) * 100;

  return (
    <div className={classes.container}>
      <div className={classes.bar}>
        <div className={classes.barFilled} style={{ width: `${width}%` }} />
      </div>
    </div>
  );
};

export default QuizIndicator;
