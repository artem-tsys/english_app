export const GOOD_HEALTH_IMAGE = 'emojis/2.1health_f6nwdx';
export const STRESSED_IMAGE = 'emojis/2.2health_wmwfol';
export const SAD_IMAGE = 'emojis/2.3health_swr7jr';
export const INDIFFERENT_IMAGE = 'emojis/2.4health_tsq8rx';

export const IMPROVE_SLEEP_IMAGE = 'emojis/icon_11.1_ip4cra';
export const REDUCE_STRESS_IMAGE = 'emojis/1.2_g1zmba';
export const COPE_WITH_ANXIETY_IMAGE = 'emojis/1.3_kfiqqd';
export const FEEL_HAPPIER_IMAGE = 'emojis/1.4_ub8nwb';
export const BOOST_SELF_ESTEEM_IMAGE = 'emojis/1.5_zwidqq';
export const OVERCOME_DEPRESSION_IMAGE = 'emojis/1.6_wu4z9u';
export const FOCUS_BETTER_IMAGE = 'emojis/1.7_mhqzan';

export const GOOD_SLEEP_IMAGE = 'emojis/8.1_vzcbzp';
export const FINE_SLEEP_IMAGE = 'emojis/8.2_wgjbv6';
export const TOOK_A_WHILE_SLEEP_IMAGE = 'emojis/8.3_nm0hm1';
export const GROGGY_SLEEP_IMAGE = 'emojis/8.4_hjwmhi';

export const EXCESS_WEIGHT_IMAGE = 'emojis/5.1_vecnde';
export const RELATIONSHIPS_IMAGE = 'emojis/5.2_wtakn0';
export const FINANCIAL_DIFFICULTIES_IMAGE = 'emojis/5.3_difozu';
export const WORK_OR_SCHOOL_IMAGE = 'emojis/5.4_jvpg4v';
export const HEALTH_ISSUES_IMAGE = 'emojis/5.5_h4jrkg';
export const BAD_HABITS_IMAGE = 'emojis/5.6_mrt0gu';
export const LOW_SELF_ESTEEM_IMAGE = 'emojis/5.7_jyg36i';

export const FALL_ASLEEP_SOON_IMAGE = 'emojis/2.1health_f6nwdx';
export const UP_TO_15_ASLEEP_IMAGE = 'emojis/8.2_wgjbv6';
export const TURN_FOR_AN_HOUR_IMAGE = 'emojis/2.3health_swr7jr';
export const TROUBLE_FALLING_ASLEEP_IMAGE = 'emojis/2.4health_tsq8rx';

export const FOCUS_MASTER_IMAGE = 'ddgbl0xcmxvov0vpqkx7';
export const DISTRACTION_SOMETIMES_IMAGE = 'emojis/2.4health_tsq8rx';
export const DISTRACTION_OFTEN_IMAGE = 'h4haalbb7vl5gkeolown';
export const DISTRACTION_ALL_THE_TIME_IMAGE = 'ygml0pwnw3wkit6d9i5s';

export const PAST_TWO_WEEKS_IMAGE = 'guru07szjyxzj55xl1e6';
export const ANXIETY_ONCE_OR_TWICE_IMAGE = 'emojis/2.4health_tsq8rx';
export const ANXIETY_OFTEN_IMAGE = 'emojis/2.3health_swr7jr';
export const ANXIETY_ALWAYS_IMAGE = 'emojis/2.2health_wmwfol';

export const STRESSED_BARELY_EVER_IMAGE = 'emojis/2.1health_f6nwdx';
export const STRESSED_SOMETIMES_IMAGE = 'emojis/2.4health_tsq8rx';
export const STRESSED_OFTEN_IMAGE = 'mvjp7wekk0btgay3agah';
export const STRESSED_ALL_THE_TIME_IMAGE = 'ygml0pwnw3wkit6d9i5s';
