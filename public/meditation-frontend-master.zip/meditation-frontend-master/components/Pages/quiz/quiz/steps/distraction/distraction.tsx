import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Distraction } from '../../../../../../constants/quiz-options.constants';
import { distractionSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  distractionSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const DistractionQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = useSelector(distractionSelector);
  const answerOptions = [
    {
      title: t('focus:focusMaster', `No, I'm a focus master`),
      id: Distraction.FocusMaster,
    },
    {
      title: t('focus:sometimes', 'Sometimes'),
      id: Distraction.SometimesHardToFocus,
    },
    { title: t('focus:often', 'Yes, often'), id: Distraction.OftenHardToFocus },
    {
      title: t('focus:allTheTime', 'All the time'),
      id: Distraction.AllTheTimeHardToFocus,
    },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    dispatch(distractionSelected(e.currentTarget.dataset.cardId));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default DistractionQuestion;
