import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Insomnia } from '../../../../../../constants/quiz-options.constants';
import { insomniaSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  insomniaSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const InsomniaQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = useSelector(insomniaSelector);
  const answerOptions = [
    {
      title: t('insomnia:IFallAsleepAsSoonInBed', `I fall asleep as soon as I'm in bed`),
      id: Insomnia.FallAsleepSoon,
    },
    {
      title: t('health:itTakesUpTo15Minutes', 'It takes up to 15 minutes'),
      id: Insomnia.UpTo15MinutesAsleep,
    },
    {
      title: t('health:ITossAndTurnForAnHour', 'I toss and turn for an hour'),
      id: Insomnia.TurnForAnHour,
    },
    {
      title: t('health:IHaveRealTrouble', 'I have real trouble falling asleep '),
      id: Insomnia.TroubleFallingAsleep,
    },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    dispatch(insomniaSelected(e.currentTarget.dataset.cardId));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default InsomniaQuestion;
