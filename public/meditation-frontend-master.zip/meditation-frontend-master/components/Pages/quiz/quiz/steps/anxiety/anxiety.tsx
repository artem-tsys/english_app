import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Anxiety } from '../../../../../../constants/quiz-options.constants';
import { anxietySelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  anxietySelector,
  currentStepElementSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const AnxietyQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = useSelector(anxietySelector);
  const answerOptions = [
    { title: t('anxiety:notReally', 'Not really'), id: Anxiety.Never },
    { title: t('anxiety:onceOrTwice', 'Once or twice'), id: Anxiety.OnceOrTwice },
    {
      title: t('anxiety:yesOften', `Yes, often`),
      id: Anxiety.Often,
    },
    {
      title: t('anxiety:alwaysAnxious', `I'm always anxious`),
      id: Anxiety.Always,
    },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    dispatch(anxietySelected(e.currentTarget.dataset.cardId));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default AnxietyQuestion;
