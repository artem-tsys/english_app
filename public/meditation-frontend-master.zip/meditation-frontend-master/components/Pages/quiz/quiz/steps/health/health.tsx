import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { HEALTH } from '../../../../../../constants/quiz-options.constants';
import { healthSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  healthSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { State } from '../../../../../../redux/store';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const HealthQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = HEALTH.indexOf(useSelector((state: State) => healthSelector(state)));
  const answerOptions = [
    { title: t('health:good', 'Good'), id: 0 },
    { title: t('health:stressed', 'Stressed'), id: 1 },
    { title: t('health:sad', 'Sad'), id: 2 },
    { title: t('health:indifferent', 'Indifferent'), id: 3 },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    dispatch(healthSelected(HEALTH[e.currentTarget.dataset.cardId]));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default HealthQuestion;
