import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Stressed } from '../../../../../../constants/quiz-options.constants';
import { stressedSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  stressedSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const StressQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = useSelector(stressedSelector);
  const answerOptions = [
    { title: t('stress:Never', 'Never'), id: Stressed.Never },
    { title: t('stress:Rarely', 'Rarely'), id: Stressed.Rarely },
    {
      title: t('stress:PrettyOften', `Pretty often`),
      id: Stressed.PrettyOften,
    },
    {
      title: t('stress:AlmostAlways', `Almost Always`),
      id: Stressed.AlmostAlways,
    },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    dispatch(stressedSelected(e.currentTarget.dataset.cardId));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default StressQuestion;
