export { default } from './insomnia';
