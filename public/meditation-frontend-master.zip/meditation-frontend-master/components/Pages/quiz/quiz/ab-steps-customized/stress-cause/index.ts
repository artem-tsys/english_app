export { default } from './stress-cause';
