import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { SLEEP_QUALITY } from '../../../../../../constants/quiz-options.constants';
import { sleepQualitySelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  sleepQualitySelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { QuestionType } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { State } from '../../../../../../redux/store';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const SleepQuality: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = SLEEP_QUALITY.indexOf(useSelector((state: State) => sleepQualitySelector(state)));
  const answerOptions = [
    { title: t('sleepQuality:quick', 'Quick and effortless'), id: 0 },
    { title: t('sleepQuality:fine', 'Just fine'), id: 1 },
    { title: t('sleepQuality:took_a_while', 'Took me a while'), id: 2 },
    { title: t('sleepQuality:groggy', 'I felt groggy and had a slow start'), id: 3 },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    dispatch(sleepQualitySelected(SLEEP_QUALITY[e.currentTarget.dataset.cardId]));

    answersPersistentClientStore.setAnswer(
      QuestionType.SleepQuality,
      {
        value: SLEEP_QUALITY[e.currentTarget.dataset.cardId],
        // Will be done later
        // customizationKey: question.customizationKey
        // customizationValue: question.customizationValue
      },
      true,
    );
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default SleepQuality;
