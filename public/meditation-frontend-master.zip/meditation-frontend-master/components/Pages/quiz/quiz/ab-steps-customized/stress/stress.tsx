import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Stressed } from '../../../../../../constants/quiz-options.constants';
import { stressedSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  stressedSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { CustomizationKey, SymptomLevel } from '../../../../../../types/my-trauma-purchase';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const StressQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = useSelector(stressedSelector);
  const answerOptions = [
    {
      title: t('stress:Never', 'Never'),
      id: Stressed.Never,
      customizationValue: SymptomLevel.NOT_IDENTIFIED,
      icon: 'xmuam5yrmfu2n04cfnfh',
    },
    {
      title: t('stress:Rarely', 'Rarely'),
      id: Stressed.Rarely,
      customizationValue: SymptomLevel.MILD,
      icon: 'zpiohx8fvu7a9kax3u2a',
    },
    {
      title: t('stress:PrettyOften', `Pretty often`),
      id: Stressed.PrettyOften,
      customizationValue: SymptomLevel.HIGH,
      icon: 'xan1ikynqth2cztihpnl',
    },
    {
      title: t('stress:AlmostAlways', `Almost Always`),
      id: Stressed.AlmostAlways,
      customizationValue: SymptomLevel.SEVERE,
      icon: 'tndeojbufrdwfhpeig42',
    },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    const value = e.currentTarget.dataset.cardId;

    const answer = answerOptions.find((a) => a.id === value);

    answersPersistentClientStore.setAnswer(
      'stressed', // for some reason it's different from QuestionType.Stress,
      {
        value,
        customizationKey: CustomizationKey.STRESS_LEVEL,
        customizationValue: answer.customizationValue,
      },
      true,
    );

    dispatch(stressedSelected(value));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default StressQuestion;
