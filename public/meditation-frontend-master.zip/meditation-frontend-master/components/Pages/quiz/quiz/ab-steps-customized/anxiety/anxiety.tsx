import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Anxiety } from '../../../../../../constants/quiz-options.constants';
import { anxietySelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  anxietySelector,
  currentStepElementSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { QuestionType } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { CustomizationKey, SymptomLevel } from '../../../../../../types/my-trauma-purchase';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const AnxietyQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = useSelector(anxietySelector);
  const answerOptions = [
    {
      title: t('anxiety:notReally', 'Not really'),
      id: Anxiety.Never,
      customizationValue: SymptomLevel.NOT_IDENTIFIED,
      icon: 'iyf0uoqdb14n2zhqnbxb',
    },
    {
      title: t('anxiety:onceOrTwice', 'Once or twice'),
      id: Anxiety.OnceOrTwice,
      customizationValue: SymptomLevel.MILD,
      icon: 'uhinb0mntfpam80d6qro',
    },
    {
      title: t('anxiety:yesOften', `Yes, more than half of the time`),
      id: Anxiety.Often,
      customizationValue: SymptomLevel.HIGH,
      icon: 'dlmcxir5esqmoosvj6mt',
    },
    {
      title: t('anxiety:alwaysAnxious', `I'm always anxious`),
      id: Anxiety.Always,
      customizationValue: SymptomLevel.SEVERE,
      icon: 'tndeojbufrdwfhpeig42',
    },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    const value = e.currentTarget.dataset.cardId;

    const answer = answerOptions.find((a) => a.id === value);

    answersPersistentClientStore.setAnswer(
      QuestionType.Anxiety,
      {
        value,
        customizationKey: CustomizationKey.ANXIETY_LEVEL,
        customizationValue: answer.customizationValue,
      },
      true,
    );

    dispatch(anxietySelected(value));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default AnxietyQuestion;
