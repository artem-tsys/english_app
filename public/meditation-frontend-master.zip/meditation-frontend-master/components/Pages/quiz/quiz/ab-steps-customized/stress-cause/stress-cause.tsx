import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { STRESS_CAUSE } from '../../../../../../constants/quiz-options.constants';
import { stressCauseSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  stressCauseSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import { GeneratedMultiSelectQuestion } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { QuestionType } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { State } from '../../../../../../redux/store';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import MultiSelectQuestion from '../../../generated-questionary/components/generated-multi-select-question/components/multi-select-question';

const StressCauseQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const question = useSelector(currentStepElementSelector) as GeneratedMultiSelectQuestion;

  const answerOptions = [
    { title: t('stress_cause:excess_weight', 'Excess weight'), id: 0 },
    { title: t('stress_cause:relationships', 'Relationships'), id: 1 },
    {
      title: t('stress_cause:financial_difficulties', 'Financial difficulties'),
      id: 2,
    },
    { title: t('stress_cause:work_or_school', 'Work or school'), id: 3 },
    { title: t('stress_cause:health_issues', 'Health issues'), id: 4 },
    { title: t('stress_cause:bad_habits', 'Bad habits'), id: 5 },
    { title: t('stress_cause:low_self-esteem', 'Low self-esteem'), id: 6 },
  ];

  const selectedValues =
    useSelector((state: State) => stressCauseSelector(state)).map((value) => STRESS_CAUSE.indexOf(value)) || [];

  const onAnswerClicked = (e): void => {
    const selectedId = Number(e.currentTarget.dataset.cardId);
    const isSelected = selectedValues.indexOf(selectedId) > -1;
    const getNewSelectedValuesWith = (newId) => [...selectedValues, newId];
    const getNewSelectedValuesWithout = (newId) => selectedValues.filter((id) => id !== newId);
    const newSelectedValues = isSelected
      ? getNewSelectedValuesWithout(selectedId)
      : getNewSelectedValuesWith(selectedId);

    const answer = newSelectedValues.map((value) => STRESS_CAUSE[value]);
    dispatch(stressCauseSelected(answer));

    answersPersistentClientStore.setAnswer(
      QuestionType.StressCause,
      {
        value: answer,
        // Will be done later
        // customizationKey: question.customizationKey
        // customizationValue: question.customizationValue
      },
      true,
    );
  };

  return (
    <MultiSelectQuestion
      question={{
        ...question,
        description: t('stress_cause:select', 'Select all that apply'),
        answerOptions,
        analyticsEvent: '/stress-cause',
      }}
      onAnswerClicked={onAnswerClicked}
      selectedValues={selectedValues}
    />
  );
};

export default StressCauseQuestion;
