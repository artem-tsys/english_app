import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Insomnia } from '../../../../../../constants/quiz-options.constants';
import { insomniaSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  insomniaSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { QuestionType } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { CustomizationKey, SymptomLevel } from '../../../../../../types/my-trauma-purchase';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const InsomniaQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = useSelector(insomniaSelector);
  const answerOptions = [
    {
      title: t('insomnia:IFallAsleepAsSoonInBed', `I doze off as soon as I'm in bed`),
      id: Insomnia.FallAsleepSoon,
      customizationValue: SymptomLevel.NOT_IDENTIFIED,
      icon: 'yfurkwvb7pccj4ehxfgh',
    },
    {
      title: t('health:itTakesUpTo15Minutes', 'It takes up to 15 minutes'),
      id: Insomnia.UpTo15MinutesAsleep,
      customizationValue: SymptomLevel.MILD,
      icon: 'pdnuqwwzah7qhmbi30kl',
    },
    {
      title: t('health:ITossAndTurnForAnHour', 'I toss and turn for an hour'),
      id: Insomnia.TurnForAnHour,
      customizationValue: SymptomLevel.HIGH,
      icon: 'oeca7en2r3obamv5xbpk',
    },
    {
      title: t('health:IHaveRealTrouble', 'I only get a few hours of sleep each night'),
      id: Insomnia.TroubleFallingAsleep,
      customizationValue: SymptomLevel.SEVERE,
      icon: 'yevggyjeo0ksidbjcmx7',
    },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    const value = e.currentTarget.dataset.cardId;

    const answer = answerOptions.find((a) => a.id === value);

    answersPersistentClientStore.setAnswer(
      QuestionType.Insomnia,
      {
        value,
        customizationKey: CustomizationKey.INSUFFICIENT_SLEEP_LEVEL,
        customizationValue: answer.customizationValue,
      },
      true,
    );

    dispatch(insomniaSelected(value));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default InsomniaQuestion;
