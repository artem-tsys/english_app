import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { MAIN_GOALS } from '../../../../../../constants/quiz-options.constants';
import { mainGoalSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  mainGoalsSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import { GeneratedMultiSelectQuestion } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { QuestionType } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { State } from '../../../../../../redux/store';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import MultiSelectQuestion from '../../../generated-questionary/components/generated-multi-select-question/components/multi-select-question';

const MainGoalsQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const question = useSelector(currentStepElementSelector) as GeneratedMultiSelectQuestion;

  const answerOptions = [
    { title: t('main_goals:improve_sleep', 'Improve sleep'), id: 0 },
    { title: t('main_goals:reduce_stress', 'Reduce stress'), id: 1 },
    { title: t('main_goals:cope_with_anxiety', 'Cope with anxiety'), id: 2 },
    { title: t('main_goals:feel_happier', 'Feel happier'), id: 3 },
    { title: t('main_goals:boost_self_esteem', 'Boost self esteem'), id: 4 },
    {
      title: t('main_goals:overcome_depression', 'Overcome depression and anger'),
      id: 5,
    },
    { title: t('main_goals:focus_better', 'Focus better'), id: 6 },
  ];

  const selectedValues =
    useSelector((state: State) => mainGoalsSelector(state)).map((value) => MAIN_GOALS.indexOf(value)) || [];

  const onAnswerClicked = (e): void => {
    const selectedId = Number(e.currentTarget.dataset.cardId);
    const isSelected = selectedValues.indexOf(selectedId) > -1;
    const getNewSelectedValuesWith = (newId) => [...selectedValues, newId];
    const getNewSelectedValuesWithout = (newId) => selectedValues.filter((id) => id !== newId);
    const newSelectedValues = isSelected
      ? getNewSelectedValuesWithout(selectedId)
      : getNewSelectedValuesWith(selectedId);

    const answer = newSelectedValues.map((value) => MAIN_GOALS[value]);
    dispatch(mainGoalSelected(answer));

    answersPersistentClientStore.setAnswer(
      QuestionType.MainGoals,
      {
        value: answer,
        // Will be done later
        // customizationKey: question.customizationKey
        // customizationValue: question.customizationValue
      },
      true,
    );
  };

  return (
    <MultiSelectQuestion
      question={{
        description: t('main_goals:description', 'We’ll personalize recommendations based on your selection'),
        ...question,
        answerOptions,
        analyticsEvent: '/main-goals',
      }}
      onAnswerClicked={onAnswerClicked}
      selectedValues={selectedValues}
    />
  );
};

export default MainGoalsQuestion;
