export { default } from './main-goals';
