import React from 'react';
import { useDispatch, useSelector } from 'react-redux';

import { Distraction } from '../../../../../../constants/quiz-options.constants';
import { distractionSelected } from '../../../../../../redux/generated-quiz/generated-quiz.actions';
import {
  currentStepElementSelector,
  distractionSelector,
} from '../../../../../../redux/generated-quiz/generated-quiz.selectors';
import {
  GeneratedSingleSelectAnswerOption,
  GeneratedSingleSelectQuestion,
} from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { QuestionType } from '../../../../../../redux/generated-quiz/generated-quiz.types';
import { CustomizationKey, SymptomLevel } from '../../../../../../types/my-trauma-purchase';
import answersPersistentClientStore from '../../../../../../utils/answers-persistent-client-store';
import useTranslation from '../../../../../../utils/next-with-i18n/use-translation';
import SingleSelectQuestion from '../../../generated-questionary/components/generated-single-select-question/components/single-select';

const DistractionQuestion: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const question = useSelector(currentStepElementSelector) as GeneratedSingleSelectQuestion;
  const selectedId = useSelector(distractionSelector);
  const answerOptions = [
    {
      title: t('focus:focusMaster', `I'm a focus master`),
      id: Distraction.FocusMaster,
      customizationValue: SymptomLevel.NOT_IDENTIFIED,
      icon: 'yfurkwvb7pccj4ehxfgh',
    },
    {
      title: t('focus:sometimes', 'I manage most of the times'),
      id: Distraction.SometimesHardToFocus,
      customizationValue: SymptomLevel.MILD,
      icon: 'pdnuqwwzah7qhmbi30kl',
    },
    {
      title: t('focus:often', 'Quite difficult'),
      id: Distraction.OftenHardToFocus,
      customizationValue: SymptomLevel.HIGH,
      icon: 'ihrtstrtq0sqlow0szfm',
    },
    {
      title: t('focus:allTheTime', 'Amlost impossible'),
      id: Distraction.AllTheTimeHardToFocus,
      customizationValue: SymptomLevel.SEVERE,
      icon: 'obfmzamborwrem6cbr8q',
    },
  ] as GeneratedSingleSelectAnswerOption[];

  const onAnswerSelected = (e): void => {
    const value = e.currentTarget.dataset.cardId;

    const answer = answerOptions.find((a) => a.id === value);

    answersPersistentClientStore.setAnswer(
      QuestionType.Distraction,
      {
        value,
        customizationKey: CustomizationKey.LACK_OF_FOCUS_LEVEL,
        customizationValue: answer.customizationValue,
      },
      true,
    );

    dispatch(distractionSelected(value));
  };

  return (
    <SingleSelectQuestion
      {...question}
      answerOptions={answerOptions}
      onAnswerSelected={onAnswerSelected}
      selectedId={selectedId}
    />
  );
};

export default DistractionQuestion;
